# ASM Assistant Student Build

这是给学员安装的分发版。

特点：

1. 只保留正式 Cloud 能力
2. 不包含 `localhost` 本地调试权限
3. 订单同步只使用飞书授权码接入，不展示内部直写方式
4. 若学员更换电脑或浏览器，需要管理员在授权后台重置设备后重新激活
5. 核心脚本已经过压缩处理，降低被随手拷走后二次转卖的成本收益比

安装方式：

1. 打开 Chrome 扩展管理页
2. 开启开发者模式
3. 选择“加载已解压的扩展程序”
4. 选择当前这个目录

当前目录：

`/Users/bangyin/application/ai-ops/dist/asm-assistant-student-0.7.43-order-shop-binding-hardening`

压缩包：

`/Users/bangyin/application/ai-ops/dist/asm-assistant-student-0.7.43-order-shop-binding-hardening.zip`

构建元数据：

`/Users/bangyin/application/ai-ops/dist/asm-assistant-student-0.7.43-order-shop-binding-hardening.build.json`

版本：

`0.7.43`
