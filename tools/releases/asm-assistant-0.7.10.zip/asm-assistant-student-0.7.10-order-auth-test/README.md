# ASM Assistant Student Build

这是给学员安装的分发版。

特点：

1. 只保留正式 Cloud 能力
2. 不包含 `localhost` 本地调试权限
3. 首次输入授权码后，会绑定当前安装实例
4. 若学员更换电脑或浏览器，需要管理员在授权后台重置设备后重新激活
5. 核心脚本已经过压缩处理，降低被随手拷走后二次转卖的成本收益比

安装方式：

1. 打开 Chrome 扩展管理页
2. 开启开发者模式
3. 选择“加载已解压的扩展程序”
4. 选择当前这个目录

当前目录：

`/Users/bangyin/application/ai-ops/dist/asm-assistant-student-0.7.10-order-auth-test`

压缩包：

`/Users/bangyin/application/ai-ops/dist/asm-assistant-student-0.7.10-order-auth-test.zip`

构建元数据：

`/Users/bangyin/application/ai-ops/dist/asm-assistant-student-0.7.10-order-auth-test.build.json`

版本：

`0.7.10`
