const SHOP_ANALYTICS_URL_RE = /^https:\/\/www\.etsy\.com\/your\/(?!messages(?:\/|$|\?)|orders\/sold(?:\/|$|\?)).+/i;

let analyticsObserverInstalled = false;
let analyticsSignalTimer = null;
let lastAnalyticsSignalKey = '';

function normalizeAnalyticsText(text) {
  return String(text || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isShopAnalyticsPage() {
  const url = window.location.href;
  if (!SHOP_ANALYTICS_URL_RE.test(url)) return false;
  const title = normalizeAnalyticsText(document.title).toLowerCase();
  const bodyText = normalizeAnalyticsText(document.body?.innerText || '').toLowerCase();
  return /(stats|analytics|traffic|visits|views|conversion|revenue|dashboard|performance|ads|listing)/i.test(`${title} ${bodyText}`);
}

function extractShopName() {
  const directLink = Array.from(document.querySelectorAll('a[href*="/shop/"]'))
    .map((link) => {
      const href = link.getAttribute('href') || '';
      const match = href.match(/\/shop\/([^/?#]+)/i);
      return match ? decodeURIComponent(match[1]) : normalizeAnalyticsText(link.textContent);
    })
    .find(Boolean);
  if (directLink) return directLink;
  const contextName = window.Etsy?.Context?.data?.shop_name;
  return normalizeAnalyticsText(contextName || '');
}

function extractDateRangeLabel() {
  const lines = String(document.body?.innerText || '')
    .split('\n')
    .map((line) => normalizeAnalyticsText(line))
    .filter(Boolean);
  const candidate = lines.find((line) => /(today|yesterday|last \d+ days|this month|last month|custom range|date range)/i.test(line));
  return candidate || '';
}

function detectAnalyticsSubPageType() {
  const signature = `${window.location.href} ${document.title} ${document.body?.innerText || ''}`.toLowerCase();
  if (/(etsy ads| ad spend| ad sales| roas|marketing)/i.test(signature)) return 'ads';
  if (/(traffic source|traffic sources|etsy search|external|direct|social|visits)/i.test(signature)) return 'traffic';
  if (/(listing performance|listings|favorites|favorites|views by listing|orders by listing)/i.test(signature)) return 'listings';
  return 'overview';
}

function extractKnownMetricHints() {
  const raw = String(document.body?.innerText || '');
  const patterns = {
    impressions: /\bimpressions?\b/i,
    visits: /\bvisits?\b/i,
    orders: /\borders?\b/i,
    conversionRate: /\bconversion\b/i,
    revenue: /\b(revenue|sales)\b/i,
    adSpend: /\b(ad spend|spend)\b/i
  };
  const metrics = {};
  Object.entries(patterns).forEach(([key, pattern]) => {
    metrics[key] = pattern.test(raw);
  });
  return metrics;
}

function buildSummaryText() {
  const lines = String(document.body?.innerText || '')
    .split('\n')
    .map((line) => normalizeAnalyticsText(line))
    .filter(Boolean)
    .slice(0, 18);
  return lines.join('\n');
}

function extractAnalyticsSignalSignature() {
  const shopName = extractShopName();
  const dateRange = extractDateRangeLabel();
  const title = normalizeAnalyticsText(document.title);
  const summary = buildSummaryText();
  return [window.location.href, shopName, dateRange, title, summary].join(' ### ');
}

function notifyAnalyticsContextChanged(reason = 'context', options = {}) {
  if (!isShopAnalyticsPage()) return;
  const { force = false } = options;
  const signalKey = extractAnalyticsSignalSignature();
  if (!force && signalKey === lastAnalyticsSignalKey) return;
  lastAnalyticsSignalKey = signalKey;
  try {
    chrome.runtime.sendMessage({
      action: 'etsyContextChanged',
      pageType: 'shop_analytics',
      currentUrl: window.location.href,
      reason
    });
  } catch (e) {}
}

function scheduleAnalyticsContextSignal(reason = 'context', delay = 320, force = false) {
  if (analyticsSignalTimer) clearTimeout(analyticsSignalTimer);
  analyticsSignalTimer = setTimeout(() => {
    analyticsSignalTimer = null;
    notifyAnalyticsContextChanged(reason, { force });
  }, delay);
}

function installAnalyticsObserver() {
  if (analyticsObserverInstalled) return;
  analyticsObserverInstalled = true;

  let lastUrl = window.location.href;
  const handlePossibleRouteChange = (reason = 'url-change') => {
    if (window.location.href === lastUrl) return;
    lastUrl = window.location.href;
    lastAnalyticsSignalKey = '';
    scheduleAnalyticsContextSignal(reason, 240, true);
  };

  const observer = new MutationObserver(() => {
    if (!isShopAnalyticsPage()) {
      handlePossibleRouteChange('mutation');
      return;
    }
    scheduleAnalyticsContextSignal('analytics-mutation', 360, false);
    handlePossibleRouteChange('mutation');
  });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true });

  window.addEventListener('popstate', () => handlePossibleRouteChange('popstate'));
}

function buildAnalyticsPayload() {
  const isPage = isShopAnalyticsPage();
  const subPageType = isPage ? detectAnalyticsSubPageType() : '';
  const shopName = isPage ? extractShopName() : '';
  const dateRangeLabel = isPage ? extractDateRangeLabel() : '';
  const summaryText = isPage ? buildSummaryText() : '';
  const metricHints = isPage ? extractKnownMetricHints() : {};
  const metricCardsFound = Object.values(metricHints).filter(Boolean).length;
  return {
    ok: true,
    isResearchPage: isPage,
    pageType: isPage ? 'shop_analytics' : '',
    subPageType,
    pageUrl: window.location.href,
    pageTitle: normalizeAnalyticsText(document.title),
    shopId: shopName,
    shopName,
    dateRangeLabel,
    metrics: {},
    rows: [],
    summaryText,
    extractor: 'shop-analytics-v0',
    diagnostics: {
      metricCardsFound,
      rowsFound: 0,
      loadingDetected: /loading|please wait/i.test(summaryText),
      metricHints
    }
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'getResearchPageState') return false;
  sendResponse(buildAnalyticsPayload());
  return true;
});

function initShopAnalyticsObserver() {
  installAnalyticsObserver();
  if (isShopAnalyticsPage()) {
    scheduleAnalyticsContextSignal('analytics-init', 0, true);
  }
}

if (document.readyState === 'complete') {
  setTimeout(initShopAnalyticsObserver, 800);
} else {
  window.addEventListener('load', () => setTimeout(initShopAnalyticsObserver, 800));
}
