// Etsy Order Sync - Content Script
// Injected on https://www.etsy.com/your/orders/sold*

let API_BASE = 'https://etsy-msg-hub.bangyinchao.workers.dev';
const EXTENSION_LICENSE_KEY = 'emaExtensionLicenseKey';
const EXTENSION_INSTALL_ID_KEY = 'emaExtensionInstallId';
const EXTENSION_SESSION_TOKEN_KEY = 'emaExtensionSessionToken';
const EXTENSION_SESSION_EXPIRES_AT_KEY = 'emaExtensionSessionExpiresAt';
const EXTENSION_VERSION = chrome.runtime?.getManifest?.()?.version || '0.0.0';
const BUILD_FINGERPRINT = typeof __ASM_BUILD_FINGERPRINT__ !== 'undefined' ? __ASM_BUILD_FINGERPRINT__ : 'dev-generic';
const SESSION_EXPIRY_BUFFER_MS = 90 * 1000;
let LICENSE_KEY = '';
let INSTALL_ID = '';
let SESSION_TOKEN = '';
let SESSION_EXPIRES_AT = '';
try {
  chrome.storage.local.get(['apiBase', EXTENSION_LICENSE_KEY, EXTENSION_INSTALL_ID_KEY, EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY], (d) => {
    if (d.apiBase) API_BASE = d.apiBase;
    if (d[EXTENSION_LICENSE_KEY]) LICENSE_KEY = String(d[EXTENSION_LICENSE_KEY]).trim();
    if (d[EXTENSION_INSTALL_ID_KEY]) INSTALL_ID = String(d[EXTENSION_INSTALL_ID_KEY]).trim();
    if (d[EXTENSION_SESSION_TOKEN_KEY]) SESSION_TOKEN = String(d[EXTENSION_SESSION_TOKEN_KEY]).trim();
    if (d[EXTENSION_SESSION_EXPIRES_AT_KEY]) SESSION_EXPIRES_AT = String(d[EXTENSION_SESSION_EXPIRES_AT_KEY]).trim();
  });
} catch(e) {}
try {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.apiBase?.newValue) {
      API_BASE = changes.apiBase.newValue;
    }
    if (areaName === 'local' && changes[EXTENSION_LICENSE_KEY]) {
      LICENSE_KEY = String(changes[EXTENSION_LICENSE_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_INSTALL_ID_KEY]) {
      INSTALL_ID = String(changes[EXTENSION_INSTALL_ID_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_SESSION_TOKEN_KEY]) {
      SESSION_TOKEN = String(changes[EXTENSION_SESSION_TOKEN_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_SESSION_EXPIRES_AT_KEY]) {
      SESSION_EXPIRES_AT = String(changes[EXTENSION_SESSION_EXPIRES_AT_KEY].newValue || '').trim();
    }
  });
} catch (e) {}

let SHOP_ID = 'default';
let ordersUrlObserverInstalled = false;
let ordersContextSignalTimer = null;
let lastOrdersContextKey = '';

function generateInstallId() {
  if (typeof crypto?.randomUUID === 'function') {
    return `asm_${crypto.randomUUID().replace(/-/g, '')}`;
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return `asm_${Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('')}`;
}

async function ensureInstallId() {
  if (INSTALL_ID) return INSTALL_ID;
  try {
    const data = await chrome.storage.local.get(EXTENSION_INSTALL_ID_KEY);
    const saved = String(data[EXTENSION_INSTALL_ID_KEY] || '').trim();
    if (saved) {
      INSTALL_ID = saved;
      return INSTALL_ID;
    }
  } catch (e) {}
  INSTALL_ID = generateInstallId();
  try {
    await chrome.storage.local.set({ [EXTENSION_INSTALL_ID_KEY]: INSTALL_ID });
  } catch (e) {}
  return INSTALL_ID;
}

function hasUsableSessionToken() {
  if (!SESSION_TOKEN || !SESSION_EXPIRES_AT) return false;
  const expiresAtMs = Date.parse(String(SESSION_EXPIRES_AT || ''));
  return Number.isFinite(expiresAtMs) && expiresAtMs > Date.now() + SESSION_EXPIRY_BUFFER_MS;
}

async function saveSessionState(token = '', expiresAt = '') {
  SESSION_TOKEN = String(token || '').trim();
  SESSION_EXPIRES_AT = String(expiresAt || '').trim();
  try {
    await chrome.storage.local.set({
      [EXTENSION_SESSION_TOKEN_KEY]: SESSION_TOKEN,
      [EXTENSION_SESSION_EXPIRES_AT_KEY]: SESSION_EXPIRES_AT
    });
  } catch (e) {}
}

async function clearSessionState() {
  SESSION_TOKEN = '';
  SESSION_EXPIRES_AT = '';
  try {
    await chrome.storage.local.remove([EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY]);
  } catch (e) {}
}

async function activateLicenseSession() {
  try {
    const data = await chrome.storage.local.get([
      'apiBase',
      EXTENSION_LICENSE_KEY,
      EXTENSION_INSTALL_ID_KEY,
      EXTENSION_SESSION_TOKEN_KEY,
      EXTENSION_SESSION_EXPIRES_AT_KEY
    ]);
    API_BASE = data.apiBase || API_BASE;
    LICENSE_KEY = String(data[EXTENSION_LICENSE_KEY] || LICENSE_KEY || '').trim();
    INSTALL_ID = String(data[EXTENSION_INSTALL_ID_KEY] || INSTALL_ID || '').trim();
  } catch (e) {}
  await ensureInstallId();
  if (!LICENSE_KEY) return false;
  try {
    const res = await fetch(`${API_BASE}/api/extension/license/activate`, {
      method: 'POST',
      headers: {
        'X-ASM-License-Key': LICENSE_KEY,
        'X-ASM-Install-Id': INSTALL_ID,
        'X-ASM-Extension-Version': EXTENSION_VERSION,
        'X-ASM-Build-Fingerprint': BUILD_FINGERPRINT,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.ok || !data?.accessToken) {
      await clearSessionState();
      return false;
    }
    await saveSessionState(data.accessToken, data.sessionExpiresAt || '');
    return true;
  } catch (e) {
    await clearSessionState();
    return false;
  }
}

async function ensureSessionToken(options = {}) {
  const { force = false } = options;
  try {
    const data = await chrome.storage.local.get([
      'apiBase',
      EXTENSION_LICENSE_KEY,
      EXTENSION_INSTALL_ID_KEY,
      EXTENSION_SESSION_TOKEN_KEY,
      EXTENSION_SESSION_EXPIRES_AT_KEY
    ]);
    API_BASE = data.apiBase || API_BASE;
    LICENSE_KEY = String(data[EXTENSION_LICENSE_KEY] || LICENSE_KEY || '').trim();
    INSTALL_ID = String(data[EXTENSION_INSTALL_ID_KEY] || INSTALL_ID || '').trim();
    SESSION_TOKEN = String(data[EXTENSION_SESSION_TOKEN_KEY] || SESSION_TOKEN || '').trim();
    SESSION_EXPIRES_AT = String(data[EXTENSION_SESSION_EXPIRES_AT_KEY] || SESSION_EXPIRES_AT || '').trim();
  } catch (e) {}
  await ensureInstallId();
  if (!force && hasUsableSessionToken()) return true;
  return activateLicenseSession();
}

async function apiFetch(input, init = {}) {
  const retrying = !!init.__retrying;
  await ensureSessionToken({ force: false });
  await ensureInstallId();

  const headers = new Headers(init.headers || {});
  headers.set('X-ASM-Install-Id', INSTALL_ID);
  headers.set('X-ASM-Extension-Version', EXTENSION_VERSION);
  headers.set('X-ASM-Build-Fingerprint', BUILD_FINGERPRINT);
  if (SESSION_TOKEN) {
    headers.set('X-ASM-Session-Token', SESSION_TOKEN);
  }

  const nextInit = { ...init };
  delete nextInit.__retrying;

  const response = await fetch(input, {
    ...nextInit,
    headers
  });
  if (response.status === 401 || response.status === 403) {
    try {
      const payload = await response.clone().json();
      if (!retrying && (payload?.sessionRequired || payload?.sessionInvalid || payload?.sessionExpired || payload?.installMismatch || payload?.installInvalid)) {
        await clearSessionState();
        const refreshed = await activateLicenseSession();
        if (refreshed) {
          return apiFetch(input, { ...nextInit, __retrying: true });
        }
      }
    } catch (e) {}
  }
  return response;
}

function normalizeText(text) {
  return String(text || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function getTextLines(node) {
  return String(node?.innerText || node?.textContent || '')
    .split('\n')
    .map((line) => normalizeText(line))
    .filter(Boolean);
}

function extractOrderIdFromHref(href) {
  const match = String(href || '').match(/\/your\/orders\/sold\/(\d+)/);
  return match ? match[1] : '';
}

function extractOrderIdFromText(text) {
  const match = String(text || '').match(/#?\b(\d{8,})\b/);
  return match ? match[1] : '';
}

function distinctOrderIdsFromText(text) {
  return Array.from(new Set(
    (String(text || '').match(/#?\b\d{8,}\b/g) || [])
      .map((value) => extractOrderIdFromText(value))
      .filter(Boolean)
  ));
}

function parseCurrencyAmount(text) {
  const raw = String(text || '');
  const symbolMatch = raw.match(/(HK\$|US\$|CA\$|AU\$|NZ\$|SG\$|€|£|\$)\s*([\d,]+(?:\.\d{2})?)/i);
  if (symbolMatch) {
    const symbol = symbolMatch[1].toUpperCase();
    const amount = Number(symbolMatch[2].replace(/,/g, ''));
    const currencyMap = {
      'HK$': 'HKD',
      'US$': 'USD',
      'CA$': 'CAD',
      'AU$': 'AUD',
      'NZ$': 'NZD',
      'SG$': 'SGD',
      '€': 'EUR',
      '£': 'GBP',
      '$': 'USD'
    };
    return {
      amount: Number.isFinite(amount) ? amount : 0,
      currency: currencyMap[symbol] || 'USD'
    };
  }

  const isoMatch = raw.match(/\b(USD|HKD|CAD|AUD|NZD|SGD|EUR|GBP)\s*([\d,]+(?:\.\d{2})?)/i);
  if (isoMatch) {
    const amount = Number(isoMatch[2].replace(/,/g, ''));
    return {
      amount: Number.isFinite(amount) ? amount : 0,
      currency: isoMatch[1].toUpperCase()
    };
  }

  return { amount: 0, currency: 'USD' };
}

function parseDateLabel(text, label) {
  const match = String(text || '').match(new RegExp(`${label}\\s+([A-Z][a-z]{2,8}\\s+\\d{1,2},\\s+\\d{4})`, 'i'));
  if (!match) return 0;
  const ts = Date.parse(match[1]);
  return Number.isFinite(ts) ? ts : 0;
}

function parseLineValue(lines, label) {
  const index = lines.findIndex((line) => new RegExp(`^${label}\\b`, 'i').test(line));
  if (index === -1) return '';
  const sameLine = normalizeText(lines[index].replace(new RegExp(`^${label}\\b`, 'i'), ''));
  if (sameLine) return sameLine;
  return normalizeText(lines[index + 1] || '');
}

function detectStatus(text) {
  const raw = String(text || '');
  const statuses = [
    'Fully refunded',
    'Refunded',
    'Completed',
    'Shipped',
    'Paid',
    'New',
    'Open'
  ];
  return statuses.find((status) => new RegExp(status, 'i').test(raw)) || 'New';
}

function deriveOrderCard(anchor, orderId) {
  let fallback = null;
  for (let node = anchor; node && node !== document.body; node = node.parentElement) {
    if (!(node instanceof HTMLElement)) continue;
    const text = node.innerText || '';
    const orderIds = distinctOrderIdsFromText(text);
    if (!orderIds.includes(orderId)) continue;

    const orderLinks = Array.from(node.querySelectorAll('a[href]'))
      .map((link) => extractOrderIdFromHref(link.getAttribute('href')))
      .filter(Boolean);
    const distinctLinkIds = Array.from(new Set(orderLinks));

    if (orderIds.length === 1 && distinctLinkIds.length <= 1 && text.length > 40) {
      return node;
    }

    if (!fallback && orderIds.length <= 2 && text.length > 40 && text.length < 2200) {
      fallback = node;
    }
  }
  return fallback || anchor.closest('article, li, section, div') || anchor.parentElement;
}

function extractShopInfoFromDom() {
  const directLink = Array.from(document.querySelectorAll('a[href*="/shop/"]'))
    .map((link) => {
      const href = link.getAttribute('href') || '';
      const match = href.match(/\/shop\/([^/?#]+)/i);
      return {
        href,
        shopName: match ? decodeURIComponent(match[1]) : '',
        text: normalizeText(link.textContent)
      };
    })
    .find((item) => item.shopName || item.text);

  if (directLink?.shopName) {
    return directLink.shopName;
  }

  if (directLink?.text) {
    const lines = directLink.text.split(' ').filter(Boolean);
    return lines[lines.length - 1] || '';
  }

  const lines = getTextLines(document.body);
  const salesIndex = lines.findIndex((line) => /^Sales channels$/i.test(line));
  if (salesIndex >= 0) {
    const windowLines = lines.slice(salesIndex, salesIndex + 12);
    const etsyIndex = windowLines.findIndex((line) => /^Etsy$/i.test(line));
    if (etsyIndex >= 0) {
      const candidate = windowLines[etsyIndex + 1];
      if (candidate && !/^(Messages|Orders|Help|Settings)$/i.test(candidate)) {
        return candidate;
      }
    }
  }

  return '';
}

async function extractShopInfo() {
  const shopName = extractShopInfoFromDom();
  if (shopName) {
    SHOP_ID = shopName;
  }
  return SHOP_ID;
}

function extractOrdersFromDom() {
  const shopName = extractShopInfoFromDom() || SHOP_ID || 'default';
  const candidateLinks = Array.from(document.querySelectorAll('a[href]'))
    .map((anchor) => {
      const href = anchor.getAttribute('href') || '';
      const orderId = extractOrderIdFromHref(href) || extractOrderIdFromText(anchor.textContent || '');
      return { anchor, href, orderId };
    })
    .filter((item) => item.orderId);

  if (candidateLinks.length === 0) {
    return { error: 'No visible order cards found', orders: [] };
  }

  const seen = new Set();
  const orders = [];

  candidateLinks.forEach(({ anchor, href, orderId }) => {
    if (!orderId || seen.has(orderId)) return;
    const card = deriveOrderCard(anchor, orderId);
    if (!card) return;

    const lines = getTextLines(card);
    const text = lines.join('\n');
    if (!text) return;

    const { amount, currency } = parseCurrencyAmount(text);
    const buyer = parseLineValue(lines, 'Ship to');
    const quantityMatch = text.match(/Quantity\s+(\d+)/i);
    const sku = parseLineValue(lines, 'SKU');
    const personalization = parseLineValue(lines, 'Personalization');
    const orderUrl = href.startsWith('http')
      ? href
      : `https://www.etsy.com/your/orders/sold/${orderId}`;

    seen.add(orderId);
    orders.push({
      orderNumber: orderId,
      orderDate: parseDateLabel(text, 'Ordered'),
      shipBy: parseDateLabel(text, 'Ship by'),
      status: detectStatus(text),
      buyer,
      email: '',
      shipTo: buyer,
      sku,
      quantity: quantityMatch ? Number(quantityMatch[1]) : 1,
      amount,
      currency,
      v1: '',
      v2: '',
      personalization,
      shop: shopName,
      orderUrl
    });
  });

  if (orders.length === 0) {
    return { error: 'Visible orders detected but parsing failed', orders: [] };
  }

  return { orders };
}

async function extractOrders() {
  let lastResult = { error: 'No visible order cards found', orders: [] };

  for (let attempt = 0; attempt < 8; attempt += 1) {
    lastResult = extractOrdersFromDom();
    if (Array.isArray(lastResult.orders) && lastResult.orders.length > 0) {
      return lastResult;
    }
    await new Promise((resolve) => setTimeout(resolve, 350));
  }

  return lastResult;
}

async function syncOrders() {
  console.log('[EMA-Orders] Extracting orders...');
  const result = await extractOrders();
  if (result.error || !result.orders || result.orders.length === 0) {
    console.log('[EMA-Orders] No orders found:', result.error);
    return {
      ok: false,
      error: result.error || 'No orders',
      diagnostics: {
        extractor: 'dom-visible-v1',
        shopId: SHOP_ID,
        ordersFound: Array.isArray(result.orders) ? result.orders.length : 0
      }
    };
  }

  console.log('[EMA-Orders] Found ' + result.orders.length + ' orders, syncing...');
  try {
    const res = await apiFetch(API_BASE + '/api/orders/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orders: result.orders, shopId: SHOP_ID })
    });
    const data = await res.json();
    console.log('[EMA-Orders] Sync result:', data);
    return {
      ok: true,
      ...data,
      diagnostics: {
        extractor: 'dom-visible-v1',
        shopId: SHOP_ID,
        ordersFound: result.orders.length
      }
    };
  } catch (e) {
    console.log('[EMA-Orders] Sync failed:', e.message);
    return {
      ok: false,
      error: e.message,
      diagnostics: {
        extractor: 'dom-visible-v1',
        shopId: SHOP_ID,
        ordersFound: result.orders.length
      }
    };
  }
}

function createManualSyncButton() {
  if (document.getElementById('ema-orders-sync-btn')) return;

  const btn = document.createElement('button');
  btn.id = 'ema-orders-sync-btn';
  btn.textContent = 'Sync Orders';
  btn.style.cssText = [
    'position:fixed',
    'right:16px',
    'bottom:16px',
    'z-index:99999',
    'padding:10px 14px',
    'border:none',
    'border-radius:999px',
    'background:#f26b38',
    'color:#fff',
    'font:600 12px -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif',
    'box-shadow:0 6px 20px rgba(0,0,0,0.18)',
    'cursor:pointer'
  ].join(';');

  btn.addEventListener('click', async () => {
    btn.disabled = true;
    const prev = btn.textContent;
    btn.textContent = 'Syncing...';
    try {
      const result = await syncOrders();
      btn.textContent = result.ok ? 'Synced' : 'Sync Failed';
    } finally {
      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = 'Sync Orders';
      }, 2000);
    }
  });

  document.body.appendChild(btn);
}

function isOrdersPage() {
  return /^https:\/\/www\.etsy\.com\/your\/orders\/sold(?:\/|$|\?)/.test(window.location.href);
}

function notifyOrdersContextChanged(reason = 'context', options = {}) {
  const { force = false } = options;
  const currentUrl = window.location.href;
  const signalKey = `${currentUrl}::${SHOP_ID}`;
  if (!force && signalKey === lastOrdersContextKey) return;
  lastOrdersContextKey = signalKey;
  try {
    chrome.runtime.sendMessage({
      action: 'etsyContextChanged',
      pageType: isOrdersPage() ? 'orders' : '',
      shopId: SHOP_ID,
      currentUrl,
      reason
    });
  } catch (e) {}
}

function scheduleOrdersContextSignal(reason = 'context', delay = 450) {
  if (ordersContextSignalTimer) clearTimeout(ordersContextSignalTimer);
  ordersContextSignalTimer = setTimeout(async () => {
    ordersContextSignalTimer = null;
    await extractShopInfo();
    try {
      chrome.runtime.sendMessage({
        action: 'shopDetected',
        shopId: SHOP_ID,
        currentUrl: window.location.href
      });
    } catch (e) {}
    notifyOrdersContextChanged(reason, { force: true });
  }, delay);
}

function installOrdersUrlObserver() {
  if (ordersUrlObserverInstalled) return;
  ordersUrlObserverInstalled = true;

  let lastUrl = window.location.href;
  const handlePossibleRouteChange = (reason = 'url-change') => {
    if (window.location.href === lastUrl) return;
    lastUrl = window.location.href;
    scheduleOrdersContextSignal(reason);
  };

  const observer = new MutationObserver(() => {
    handlePossibleRouteChange('mutation');
  });
  observer.observe(document.body, { childList: true, subtree: true });

  window.addEventListener('popstate', () => handlePossibleRouteChange('popstate'));

  if (!window.__emaOrdersHistoryPatched) {
    window.__emaOrdersHistoryPatched = true;
    const rawPushState = history.pushState.bind(history);
    const rawReplaceState = history.replaceState.bind(history);

    history.pushState = function pushStatePatched(...args) {
      const result = rawPushState(...args);
      handlePossibleRouteChange('pushstate');
      return result;
    };

    history.replaceState = function replaceStatePatched(...args) {
      const result = rawReplaceState(...args);
      handlePossibleRouteChange('replacestate');
      return result;
    };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getOrdersPageState') {
    (async () => {
      if (!isOrdersPage()) {
        sendResponse({
          ok: true,
          safeMode: true,
          isOrdersPage: false,
          shopId: SHOP_ID,
          currentUrl: window.location.href,
          orderCount: 0
        });
        return;
      }

      await extractShopInfo();
      const result = await extractOrders();
      sendResponse({
        ok: true,
        safeMode: true,
        isOrdersPage: true,
        shopId: SHOP_ID,
        currentUrl: window.location.href,
        orderCount: Array.isArray(result.orders) ? result.orders.length : 0,
        error: result.error || null,
        diagnostics: {
          extractor: 'dom-visible-v1',
          shopId: SHOP_ID,
          ordersFound: Array.isArray(result.orders) ? result.orders.length : 0
        }
      });
    })();
    return true;
  }

  if (msg.action === 'syncOrdersManual') {
    (async () => {
      if (!isOrdersPage()) {
        sendResponse({ ok: false, error: 'Open Etsy Sold Orders first.' });
        return;
      }

      await extractShopInfo();
      const result = await syncOrders();
      sendResponse({
        ...result,
        safeMode: true,
        shopId: SHOP_ID,
        currentUrl: window.location.href
      });
    })();
    return true;
  }

  if (msg.action === 'syncOrders') {
    sendResponse({ ok: false, error: 'disabled in safe mode' });
    return true;
  }
});

// Safe mode: never background-crawl. Only the visible Etsy orders page can trigger a read/compare.
async function init() {
  console.log('[EMA-Orders] Order sync content script loaded');
  await extractShopInfo();
  console.log('[EMA-Orders] Safe mode shop: ' + SHOP_ID);
  try { chrome.runtime.sendMessage({ action: 'shopDetected', shopId: SHOP_ID, currentUrl: window.location.href }); } catch (e) {}
  installOrdersUrlObserver();
  scheduleOrdersContextSignal('init', 0);
}

if (document.readyState === 'complete') {
  setTimeout(init, 2000);
} else {
  window.addEventListener('load', () => setTimeout(init, 2000));
}
