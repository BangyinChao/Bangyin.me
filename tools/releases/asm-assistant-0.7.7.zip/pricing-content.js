const PRICING_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?listing\/\d+(?:\/|$|\?)/i;

let pricingObserverInstalled = false;
let pricingSignalTimer = null;
let lastPricingSignalKey = '';

function normalizePricingText(text) {
  return String(text || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isPricingPage() {
  return PRICING_URL_RE.test(window.location.href);
}

function getBuyBoxRoot() {
  return document.querySelector('[data-buy-box-region]') || document.body;
}

function extractPricingSignalSignature() {
  const root = getBuyBoxRoot();
  if (!root) return window.location.href;

  const selectedParts = [];

  root.querySelectorAll('select').forEach((select) => {
    const option = select.selectedOptions?.[0];
    const label = normalizePricingText(
      select.getAttribute('aria-label')
      || select.closest('label')?.innerText
      || select.closest('[data-selector*="variation"]')?.querySelector('label')?.innerText
      || ''
    );
    const value = normalizePricingText(option?.textContent || option?.value || '');
    if (label || value) {
      selectedParts.push(`${label}:${value}`);
    }
  });

  root.querySelectorAll('input[type="radio"]:checked').forEach((input) => {
    const label = normalizePricingText(
      input.closest('label')?.innerText
      || root.querySelector(`label[for="${input.id}"]`)?.innerText
      || input.value
      || ''
    );
    if (label) selectedParts.push(label);
  });

  root.querySelectorAll('[role="option"][aria-selected="true"], [role="radio"][aria-checked="true"], button[aria-pressed="true"], [aria-current="true"]').forEach((node) => {
    const text = normalizePricingText(node?.innerText || node?.textContent || node?.getAttribute?.('aria-label') || '');
    if (text) selectedParts.push(text);
  });

  const priceText = Array.from(root.querySelectorAll('[aria-label*="price" i], [data-selector*="price"], [data-test-id*="price"], s, .wt-text-strikethrough, .wt-text-title-larger, .wt-text-title-03'))
    .slice(0, 12)
    .map((node) => normalizePricingText(node?.innerText || node?.textContent || node?.getAttribute?.('aria-label') || ''))
    .filter(Boolean)
    .join(' | ');

  const shipText = Array.from(root.querySelectorAll('[aria-label*="ships from" i], [aria-label*="dispatches from" i], [data-selector*="ships-from"], [data-selector*="dispatch"]'))
    .slice(0, 8)
    .map((node) => normalizePricingText(node?.innerText || node?.textContent || node?.getAttribute?.('aria-label') || ''))
    .filter(Boolean)
    .join(' | ');

  return [
    window.location.href,
    selectedParts.join(' || '),
    priceText,
    shipText
  ].join(' ### ');
}

function notifyPricingContextChanged(reason = 'context', options = {}) {
  if (!isPricingPage()) return;
  const { force = false } = options;
  const currentUrl = window.location.href;
  const signalKey = extractPricingSignalSignature();
  if (!force && signalKey === lastPricingSignalKey) return;
  lastPricingSignalKey = signalKey;
  try {
    chrome.runtime.sendMessage({
      action: 'etsyContextChanged',
      pageType: 'pricing',
      currentUrl,
      reason
    });
  } catch (e) {}
}

function schedulePricingContextSignal(reason = 'context', delay = 280, force = false) {
  if (pricingSignalTimer) clearTimeout(pricingSignalTimer);
  pricingSignalTimer = setTimeout(() => {
    pricingSignalTimer = null;
    notifyPricingContextChanged(reason, { force });
  }, delay);
}

function installPricingObserver() {
  if (pricingObserverInstalled) return;
  pricingObserverInstalled = true;

  let lastUrl = window.location.href;
  const handlePossibleRouteChange = (reason = 'url-change') => {
    if (window.location.href === lastUrl) return;
    lastUrl = window.location.href;
    lastPricingSignalKey = '';
    schedulePricingContextSignal(reason, 240, true);
  };

  const observer = new MutationObserver((mutations) => {
    let hasPricingMutation = false;
    for (const mutation of mutations) {
      const target = mutation.target;
      if (!(target instanceof HTMLElement)) continue;
      if (target.closest?.('[data-buy-box-region]') || target.matches?.('[data-buy-box-region]')) {
        hasPricingMutation = true;
        break;
      }
    }
    if (hasPricingMutation) {
      schedulePricingContextSignal('pricing-mutation', 320, false);
    }
    handlePossibleRouteChange('mutation');
  });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: false });

  document.addEventListener('change', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (!target.closest('[data-buy-box-region]')) return;
    schedulePricingContextSignal('pricing-change', 180, true);
    setTimeout(() => schedulePricingContextSignal('pricing-change-follow-up', 850, true), 850);
  }, true);

  document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    if (!target.closest('[data-buy-box-region]')) return;
    schedulePricingContextSignal('pricing-click', 220, true);
    setTimeout(() => schedulePricingContextSignal('pricing-click-follow-up', 900, true), 900);
  }, true);

  window.addEventListener('popstate', () => handlePossibleRouteChange('popstate'));

  if (!window.__emaPricingHistoryPatched) {
    window.__emaPricingHistoryPatched = true;
    const rawPushState = history.pushState.bind(history);
    const rawReplaceState = history.replaceState.bind(history);

    history.pushState = function pushStatePatched(...args) {
      const result = rawPushState(...args);
      handlePossibleRouteChange('pushstate');
      return result;
    };

    history.replaceState = function replaceStatePatched(...args) {
      const result = rawReplaceState(...args);
      handlePossibleRouteChange('replacestate');
      return result;
    };
  }
}

function initPricingObserver() {
  if (!isPricingPage()) return;
  installPricingObserver();
  schedulePricingContextSignal('pricing-init', 0, true);
}

if (document.readyState === 'complete') {
  setTimeout(initPricingObserver, 600);
} else {
  window.addEventListener('load', () => setTimeout(initPricingObserver, 600));
}
