// Etsy Message Assistant - Background Service Worker
// Safe mode: never auto-refresh, auto-open, auto-navigate, or auto-sync Etsy pages.

let API_BASE = 'https://etsy-msg-hub.bangyinchao.workers.dev';
const EXTENSION_LICENSE_KEY = 'emaExtensionLicenseKey';
const EXTENSION_INSTALL_ID_KEY = 'emaExtensionInstallId';
const EXTENSION_SESSION_TOKEN_KEY = 'emaExtensionSessionToken';
const EXTENSION_SESSION_EXPIRES_AT_KEY = 'emaExtensionSessionExpiresAt';
const BUILD_FINGERPRINT = typeof __ASM_BUILD_FINGERPRINT__ !== 'undefined' ? __ASM_BUILD_FINGERPRINT__ : 'dev-generic';
let LICENSE_KEY = '';
let INSTALL_ID = '';
let SESSION_TOKEN = '';
let SESSION_EXPIRES_AT = '';
try {
  chrome.storage.local.get(['apiBase', EXTENSION_LICENSE_KEY, EXTENSION_INSTALL_ID_KEY, EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY], (d) => {
    if (d.apiBase) API_BASE = d.apiBase;
    if (d[EXTENSION_LICENSE_KEY]) LICENSE_KEY = String(d[EXTENSION_LICENSE_KEY]).trim();
    if (d[EXTENSION_INSTALL_ID_KEY]) INSTALL_ID = String(d[EXTENSION_INSTALL_ID_KEY]).trim();
    if (d[EXTENSION_SESSION_TOKEN_KEY]) SESSION_TOKEN = String(d[EXTENSION_SESSION_TOKEN_KEY]).trim();
    if (d[EXTENSION_SESSION_EXPIRES_AT_KEY]) SESSION_EXPIRES_AT = String(d[EXTENSION_SESSION_EXPIRES_AT_KEY]).trim();
  });
} catch (e) {}

const EXTENSION_VERSION = chrome.runtime?.getManifest?.()?.version || '0.0.0';
const SESSION_EXPIRY_BUFFER_MS = 90 * 1000;
let shopId = 'default';
let lastKnownUrl = '';

try {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.apiBase?.newValue) {
      API_BASE = changes.apiBase.newValue;
    }
    if (areaName === 'local' && changes[EXTENSION_LICENSE_KEY]) {
      LICENSE_KEY = String(changes[EXTENSION_LICENSE_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_INSTALL_ID_KEY]) {
      INSTALL_ID = String(changes[EXTENSION_INSTALL_ID_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_SESSION_TOKEN_KEY]) {
      SESSION_TOKEN = String(changes[EXTENSION_SESSION_TOKEN_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_SESSION_EXPIRES_AT_KEY]) {
      SESSION_EXPIRES_AT = String(changes[EXTENSION_SESSION_EXPIRES_AT_KEY].newValue || '').trim();
    }
  });
} catch (e) {}

function hasKnownShop() {
  return !!shopId && shopId !== 'default';
}

function generateInstallId() {
  if (typeof crypto?.randomUUID === 'function') {
    return `asm_${crypto.randomUUID().replace(/-/g, '')}`;
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return `asm_${Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('')}`;
}

async function ensureInstallId() {
  if (INSTALL_ID) return INSTALL_ID;
  try {
    const data = await chrome.storage.local.get(EXTENSION_INSTALL_ID_KEY);
    const saved = String(data[EXTENSION_INSTALL_ID_KEY] || '').trim();
    if (saved) {
      INSTALL_ID = saved;
      return INSTALL_ID;
    }
  } catch (e) {}
  INSTALL_ID = generateInstallId();
  try {
    await chrome.storage.local.set({ [EXTENSION_INSTALL_ID_KEY]: INSTALL_ID });
  } catch (e) {}
  return INSTALL_ID;
}

function hasUsableSessionToken() {
  if (!SESSION_TOKEN || !SESSION_EXPIRES_AT) return false;
  const expiresAtMs = Date.parse(String(SESSION_EXPIRES_AT || ''));
  return Number.isFinite(expiresAtMs) && expiresAtMs > Date.now() + SESSION_EXPIRY_BUFFER_MS;
}

async function saveSessionState(token = '', expiresAt = '') {
  SESSION_TOKEN = String(token || '').trim();
  SESSION_EXPIRES_AT = String(expiresAt || '').trim();
  try {
    await chrome.storage.local.set({
      [EXTENSION_SESSION_TOKEN_KEY]: SESSION_TOKEN,
      [EXTENSION_SESSION_EXPIRES_AT_KEY]: SESSION_EXPIRES_AT
    });
  } catch (e) {}
}

async function clearSessionState() {
  SESSION_TOKEN = '';
  SESSION_EXPIRES_AT = '';
  try {
    await chrome.storage.local.remove([EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY]);
  } catch (e) {}
}

async function loadAuthState() {
  try {
    const data = await chrome.storage.local.get([
      'apiBase',
      EXTENSION_LICENSE_KEY,
      EXTENSION_INSTALL_ID_KEY,
      EXTENSION_SESSION_TOKEN_KEY,
      EXTENSION_SESSION_EXPIRES_AT_KEY
    ]);
    API_BASE = data.apiBase || API_BASE;
    LICENSE_KEY = String(data[EXTENSION_LICENSE_KEY] || LICENSE_KEY || '').trim();
    INSTALL_ID = String(data[EXTENSION_INSTALL_ID_KEY] || INSTALL_ID || '').trim();
    SESSION_TOKEN = String(data[EXTENSION_SESSION_TOKEN_KEY] || SESSION_TOKEN || '').trim();
    SESSION_EXPIRES_AT = String(data[EXTENSION_SESSION_EXPIRES_AT_KEY] || SESSION_EXPIRES_AT || '').trim();
  } catch (e) {}
}

async function activateLicenseSession() {
  await loadAuthState();
  await ensureInstallId();
  if (!LICENSE_KEY) return false;
  try {
    const res = await fetch(`${API_BASE}/api/extension/license/activate`, {
      method: 'POST',
      headers: {
        'X-ASM-License-Key': LICENSE_KEY,
        'X-ASM-Install-Id': INSTALL_ID,
        'X-ASM-Extension-Version': EXTENSION_VERSION,
        'X-ASM-Build-Fingerprint': BUILD_FINGERPRINT,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.ok || !data?.accessToken) {
      await clearSessionState();
      return false;
    }
    await saveSessionState(data.accessToken, data.sessionExpiresAt || '');
    return true;
  } catch (e) {
    await clearSessionState();
    return false;
  }
}

async function ensureSessionToken(options = {}) {
  const { force = false } = options;
  await loadAuthState();
  await ensureInstallId();
  if (!force && hasUsableSessionToken()) return true;
  return activateLicenseSession();
}

async function sendHeartbeat() {
  if (!hasKnownShop()) return;
  try {
    const sessionReady = await ensureSessionToken({ force: false });
    const headers = {
      'Content-Type': 'application/json',
      'X-ASM-Install-Id': await ensureInstallId(),
      'X-ASM-Extension-Version': EXTENSION_VERSION,
      'X-ASM-Build-Fingerprint': BUILD_FINGERPRINT
    };
    if (sessionReady && SESSION_TOKEN) {
      headers['X-ASM-Session-Token'] = SESSION_TOKEN;
    }
    const response = await fetch(API_BASE + '/api/messages/extension-heartbeat', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        shopId,
        status: 'online',
        version: EXTENSION_VERSION,
        currentUrl: lastKnownUrl
      })
    });
    if ((response.status === 401 || response.status === 403) && sessionReady) {
      const payload = await response.clone().json().catch(() => ({}));
      if (payload?.sessionRequired || payload?.sessionInvalid || payload?.sessionExpired || payload?.installMismatch || payload?.installInvalid) {
        await clearSessionState();
      }
    }
  } catch (e) {}
}

async function clearLegacyAutomation() {
  try {
    await chrome.alarms.clearAll();
  } catch (e) {}
}

async function configureSidePanel() {
  if (!chrome.sidePanel?.setPanelBehavior) return;
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(() => {
  configureSidePanel().catch(() => {});
});

chrome.runtime.onStartup?.addListener(() => {
  configureSidePanel().catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'shopDetected') {
    shopId = msg.shopId || 'default';
    lastKnownUrl = msg.currentUrl || sender?.tab?.url || lastKnownUrl;
    console.log('[EMA-BG] Safe mode active for shop: ' + shopId);
    sendHeartbeat().catch(() => {});
    sendResponse({ ok: true, safeMode: true });
    return true;
  }

  if (msg.action === 'heartbeat') {
    sendHeartbeat().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.action === 'getSafeMode') {
    sendResponse({ safeMode: true, shopId, currentUrl: lastKnownUrl });
    return true;
  }

  return false;
});

clearLegacyAutomation().finally(() => {
  configureSidePanel().catch(() => {});
  console.log('[EMA-BG] Safe mode service worker started');
});
