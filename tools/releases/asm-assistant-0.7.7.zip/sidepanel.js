const CLOUD_URL = 'https://etsy-msg-hub.bangyinchao.workers.dev';
const LOCAL_URL = 'http://localhost:3000';
const SIDE_PANEL_COLLAPSE_KEY = 'emaSidePanelCollapsed';
const SIDE_PANEL_DRAFTS_KEY = 'emaSidePanelDrafts';
const SIDE_PANEL_ACTIVE_MODULE_KEY = 'emaSidePanelActiveModule';
const PRICING_DEFAULT_CONFIG_KEY = 'emaPricingDefaultConfig';
const EXTENSION_LICENSE_KEY = 'emaExtensionLicenseKey';
const EXTENSION_INSTALL_ID_KEY = 'emaExtensionInstallId';
const EXTENSION_SESSION_TOKEN_KEY = 'emaExtensionSessionToken';
const EXTENSION_SESSION_EXPIRES_AT_KEY = 'emaExtensionSessionExpiresAt';
const MESSAGES_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:your\/)?messages(?:\/|$|\?)/i;
const ORDERS_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?your\/orders\/sold(?:\/|$|\?)/i;
const PRICING_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?listing\/\d+(?:\/|$|\?)/i;
const MARKET_RESEARCH_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:search(?:\/|$|\?)|market\/)/i;
const AUTO_SYNC_DELAY_MS = 420;
const SESSION_EXPIRY_BUFFER_MS = 90 * 1000;
const EXTENSION_VERSION = chrome.runtime?.getManifest?.()?.version || '0.0.0';
const BUILD_FINGERPRINT = typeof __ASM_BUILD_FINGERPRINT__ !== 'undefined' ? __ASM_BUILD_FINGERPRINT__ : 'dev-generic';

const state = {
  apiBase: CLOUD_URL,
  activeModule: 'messages',
  convoId: '',
  shopId: '',
  messageCount: 0,
  pendingBuyerCount: 0,
  hasMessageAttachments: false,
  buyerName: '',
  currentUrl: '',
  lastDirection: '',
  latestBuyerMessage: '',
  latestBuyerMessageZh: '',
  buyerIntentZh: '',
  replyFocusZh: '',
  currentPendingBuyerText: '',
  currentThreadMessages: [],
  baseReply: '',
  baseReplyZh: '',
  lastSellerIntent: '',
  messageThreadCache: {},
  orderPageReady: false,
  orderCount: 0,
  orderShopId: '',
  orderDisplayName: '',
  orderCurrentUrl: '',
  orderVisibleOrderIds: [],
  orderKnownOrderIds: [],
  orderNewOrderIds: [],
  orderCompareState: 'idle',
  lastOrderSync: null,
  orderStats: null,
  orderFeishuLink: '',
  orderConfigReady: false,
  orderConfigSource: '',
  orderConfigWarnings: [],
  orderConfigEditorVisible: false,
  pricingPageReady: false,
  pricingCurrentUrl: '',
  pricingListingId: '',
  pricingTitle: '',
  pricingShopName: '',
  pricingExtractor: '',
  pricingDiagnostics: {},
  pricingCurrency: '',
  pricingCurrentPrice: 0,
  pricingOriginalPrice: 0,
  pricingShippingAmount: 0,
  pricingShippingCurrency: '',
  pricingShopLocation: '',
  pricingShipsFrom: '',
  pricingVariantSummary: '',
  pricingDetectedCountryCode: '',
  pricingFeeProfiles: [],
  pricingSellerShopId: '',
  pricingSellerCountryCode: '',
  pricingSellerCurrency: '',
  pricingDefaultAdRate: 15,
  pricingSnapshotId: null,
  pricingCollectionSummary: null,
  pricingReverseResult: null,
  pricingForwardResult: null,
  researchMode: 'shop',
  researchPageReady: false,
  researchPageType: '',
  researchSubPageType: '',
  researchCurrentUrl: '',
  researchPageTitle: '',
  researchKeyword: '',
  researchShopId: '',
  researchShopName: '',
  researchDateRangeLabel: '',
  researchSampleCount: 0,
  researchSummaryText: '',
  researchRawSignals: '',
  researchExtractor: '',
  researchDiagnostics: {},
  lastMessageAutoKey: '',
  lastOrderAutoKey: '',
  lastPricingAutoKey: '',
  lastResearchAutoKey: '',
  lastPricingPersistKey: '',
  threadSyncBusy: false,
  orderSyncBusy: false,
  currentTabId: null,
  collapsed: false,
  installId: '',
  licenseKey: '',
  sessionToken: '',
  sessionExpiresAt: '',
  licenseStatus: 'missing',
  licenseStatusText: '',
  licenseStatusKind: 'neutral',
  licensePlanLabel: '',
  licenseTenantName: '',
  licenseExpiresAt: ''
};

let draftPersistTimer = null;
let autoSyncTimer = null;
let pricingFollowUpTimer = null;
let tabContextWatchTimer = null;
let lastWatchedTabUrl = '';

function setStatus(id, text, kind = 'neutral') {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = `status ${kind}`;
}

function formatDateTime(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString();
}

function setLicenseStatus(text = '', kind = 'neutral') {
  state.licenseStatusText = text || '未配置授权码。';
  state.licenseStatusKind = kind || 'neutral';
  setStatus('license-status', text || '未配置授权码。', kind);
  renderLicenseHero();
}

function isStaleContentScript(info = {}) {
  if (String(info?.contextSource || '').trim() === 'main-world') return false;
  const remoteVersion = String(info?.extensionVersion || '').trim();
  const remoteFingerprint = String(info?.buildFingerprint || '').trim();
  if (!remoteVersion && !remoteFingerprint) return true;
  if (remoteFingerprint && remoteFingerprint !== BUILD_FINGERPRINT) return true;
  if (remoteVersion && remoteVersion !== EXTENSION_VERSION) return true;
  return false;
}

function handleStaleContentScript(info = {}) {
  const remoteVersion = String(info?.extensionVersion || '').trim() || 'unknown';
  setPill('page-pill', '当前页面仍在运行旧版脚本', 'err');
  setDraftStatus(`当前 Etsy 标签页里的脚本还是旧版本（页面脚本 ${remoteVersion}，侧栏 ${EXTENSION_VERSION}）。请刷新这个 Etsy 页面后再重试。`, 'err');
}

function renderLicenseMeta() {
  const el = document.getElementById('license-meta');
  if (!el) return;
  if (!state.licenseKey) {
    el.textContent = '未配置授权码时，消息/订单/定价请求会被后端拒绝。';
    return;
  }
  const parts = [];
  if (state.licenseTenantName) parts.push(`租户：${state.licenseTenantName}`);
  if (state.licensePlanLabel) parts.push(`周期：${state.licensePlanLabel}`);
  if (state.licenseExpiresAt) parts.push(`到期：${formatDateTime(state.licenseExpiresAt)}`);
  el.textContent = parts.join(' | ') || '授权已保存，按学员身份生效。';
}

function renderLicenseHero() {
  const chip = document.getElementById('hero-license-chip');
  const expiry = document.getElementById('hero-license-expiry');
  if (!chip || !expiry) return;

  const status = String(state.licenseStatus || '').trim().toLowerCase();
  const kind = state.licenseStatusKind === 'ok' || state.licenseStatusKind === 'err'
    ? state.licenseStatusKind
    : (
        status === 'active' || status === 'trial'
          ? 'ok'
          : (status === 'invalid' || status === 'expired' || status === 'revoked'
            ? 'err'
            : 'neutral')
      );

  let label = '未授权';
  let detail = '点击右上角“设置”输入授权码并完成激活。';

  if (kind === 'ok') {
    label = '已授权';
    const parts = [];
    if (state.licensePlanLabel) parts.push(state.licensePlanLabel);
    if (state.licenseExpiresAt) parts.push(`截止 ${formatDateTime(state.licenseExpiresAt)}`);
    detail = parts.join(' | ') || '当前设备授权有效。';
  } else if (String(state.licenseStatusText || '').includes('正在验证')) {
    label = '验证中';
    detail = state.licenseStatusText || '正在验证当前设备授权。';
  } else if (kind === 'err') {
    label = '授权异常';
    detail = state.licenseStatusText || '授权验证失败，请点击查看原因。';
  } else if (state.licenseKey) {
    label = '待激活';
    detail = state.licenseStatusText || '当前设备还没有完成授权验证。';
  }

  chip.textContent = label;
  chip.className = `hero-license-chip ${kind}`;
  expiry.textContent = detail;
}

function setLicenseState(payload = {}) {
  state.licenseStatus = payload.status || (state.licenseKey ? 'configured' : 'missing');
  state.licensePlanLabel = payload.planLabel || '';
  state.licenseTenantName = payload.tenantName || '';
  state.licenseExpiresAt = payload.expiresAt || '';
  renderLicenseMeta();
  renderLicenseHero();
}

function normalizeLicenseKeyInput(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const matched = raw.match(/ASM_[A-Za-z0-9_-]+/i);
  return String(matched ? matched[0] : raw).trim();
}

function generateInstallId() {
  if (typeof crypto?.randomUUID === 'function') {
    return `asm_${crypto.randomUUID().replace(/-/g, '')}`;
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return `asm_${Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('')}`;
}

async function ensureInstallId() {
  if (state.installId) return state.installId;
  const data = await chrome.storage.local.get(EXTENSION_INSTALL_ID_KEY);
  const saved = String(data[EXTENSION_INSTALL_ID_KEY] || '').trim();
  if (saved) {
    state.installId = saved;
    return state.installId;
  }
  state.installId = generateInstallId();
  await chrome.storage.local.set({ [EXTENSION_INSTALL_ID_KEY]: state.installId });
  return state.installId;
}

function hasUsableSessionToken() {
  if (!state.sessionToken || !state.sessionExpiresAt) return false;
  const expiresAtMs = Date.parse(String(state.sessionExpiresAt || ''));
  return Number.isFinite(expiresAtMs) && expiresAtMs > Date.now() + SESSION_EXPIRY_BUFFER_MS;
}

async function saveSessionState(token = '', expiresAt = '') {
  state.sessionToken = String(token || '').trim();
  state.sessionExpiresAt = String(expiresAt || '').trim();
  await chrome.storage.local.set({
    [EXTENSION_SESSION_TOKEN_KEY]: state.sessionToken,
    [EXTENSION_SESSION_EXPIRES_AT_KEY]: state.sessionExpiresAt
  });
}

async function clearSessionState() {
  state.sessionToken = '';
  state.sessionExpiresAt = '';
  await chrome.storage.local.remove([EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY]);
}

async function loadLicenseKey() {
  const data = await chrome.storage.local.get([
    EXTENSION_LICENSE_KEY,
    EXTENSION_INSTALL_ID_KEY,
    EXTENSION_SESSION_TOKEN_KEY,
    EXTENSION_SESSION_EXPIRES_AT_KEY
  ]);
  state.licenseKey = String(data[EXTENSION_LICENSE_KEY] || '').trim();
  state.installId = String(data[EXTENSION_INSTALL_ID_KEY] || '').trim();
  state.sessionToken = String(data[EXTENSION_SESSION_TOKEN_KEY] || '').trim();
  state.sessionExpiresAt = String(data[EXTENSION_SESSION_EXPIRES_AT_KEY] || '').trim();
  setInputValue('license-key', state.licenseKey);
  if (!state.licenseKey) {
    setLicenseState({ status: 'missing' });
    setLicenseStatus('未配置授权码。', 'neutral');
  }
}

async function activateLicenseSession(options = {}) {
  const { silent = false } = options;
  if (!state.licenseKey) {
    await loadLicenseKey();
  }
  if (!state.licenseKey) {
    if (!silent) {
      setLicenseState({ status: 'missing' });
      setLicenseStatus('未配置授权码。', 'neutral');
    }
    return false;
  }

  const installId = await ensureInstallId();
  try {
    const res = await fetch(`${state.apiBase}/api/extension/license/activate`, {
      method: 'POST',
      headers: {
        'X-ASM-License-Key': state.licenseKey,
        'X-ASM-Install-Id': installId,
        'X-ASM-Extension-Version': EXTENSION_VERSION,
        'X-ASM-Build-Fingerprint': BUILD_FINGERPRINT,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.ok || !data?.accessToken) {
      await clearSessionState();
      if (!silent) {
        setLicenseState({ status: 'invalid' });
        setLicenseStatus(data?.error || '授权激活失败。', 'err');
      }
      return false;
    }

    await saveSessionState(data.accessToken, data.sessionExpiresAt || '');
    const license = data.license || {};
    setLicenseState({
      status: license.status || 'active',
      tenantName: license.tenantName || '',
      planLabel: license.planLabel || '',
      expiresAt: license.expiresAt || ''
    });
    if (!silent) {
      setLicenseStatus('授权已激活。', 'ok');
    }
    return true;
  } catch (error) {
    await clearSessionState();
    if (!silent) {
      setLicenseStatus('授权激活失败，请检查服务连接。', 'err');
    }
    return false;
  }
}

async function ensureSessionToken(options = {}) {
  const { force = false, silent = true } = options;
  if (!state.licenseKey || !state.installId || !state.sessionToken) {
    await loadLicenseKey();
  }
  await ensureInstallId();
  if (!force && hasUsableSessionToken()) {
    return true;
  }
  return activateLicenseSession({ silent });
}

async function apiFetch(input, init = {}) {
  const retrying = !!init.__retrying;
  await ensureSessionToken({ silent: true });

  const headers = new Headers(init.headers || {});
  if (state.installId) {
    headers.set('X-ASM-Install-Id', state.installId);
  }
  headers.set('X-ASM-Extension-Version', EXTENSION_VERSION);
  headers.set('X-ASM-Build-Fingerprint', BUILD_FINGERPRINT);
  if (state.sessionToken) {
    headers.set('X-ASM-Session-Token', state.sessionToken);
  }

  const nextInit = { ...init };
  delete nextInit.__retrying;

  const response = await fetch(input, {
    ...nextInit,
    headers
  });

  if (response.status === 401 || response.status === 403) {
    try {
      const payload = await response.clone().json();
      if (!retrying && (payload?.sessionRequired || payload?.sessionInvalid || payload?.sessionExpired || payload?.installMismatch || payload?.installInvalid)) {
        await clearSessionState();
        const refreshed = await activateLicenseSession({ silent: true });
        if (refreshed) {
          return apiFetch(input, { ...nextInit, __retrying: true });
        }
      }
      if (payload?.licenseRequired || payload?.licenseInvalid || payload?.sessionInvalid) {
        setLicenseStatus(payload.error || '当前授权不可用。', 'err');
      }
    } catch (e) {}
  }

  return response;
}

function normalizeOrderId(value) {
  return String(value || '').replace(/[^\d]/g, '').trim();
}

function normalizeCurrency(value) {
  return String(value || '').trim().toUpperCase();
}

function normalizeNumber(value, fallback = 0) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function roundMoney(value) {
  return Math.round((normalizeNumber(value, 0) + Number.EPSILON) * 100) / 100;
}

function clampPercent(value) {
  const num = normalizeNumber(value, 0);
  return Math.max(-99, Math.min(99, num));
}

function setInputValue(id, value = '') {
  const el = document.getElementById(id);
  if (!el) return;
  el.value = value == null ? '' : String(value);
}

function getInputValue(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
}

function formatPercent(value) {
  const num = Number(value);
  return Number.isFinite(num) ? `${roundMoney(num)}%` : '-';
}

function formatMoneyValue(amount, currency = '') {
  const num = Number(amount);
  if (!Number.isFinite(num)) return '-';
  return `${roundMoney(num)}${currency ? ` ${normalizeCurrency(currency)}` : ''}`;
}

function formatMoneyLine(label, amount, currency = '') {
  return `${label}: ${formatMoneyValue(amount, currency)}`;
}

function formatSignedMoneyValue(amount, currency = '') {
  const num = Number(amount);
  if (!Number.isFinite(num)) return '-';
  const prefix = num > 0 ? '+' : '';
  return `${prefix}${roundMoney(num)}${currency ? ` ${normalizeCurrency(currency)}` : ''}`;
}

function formatSignedPercent(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) return '-';
  const prefix = num > 0 ? '+' : '';
  return `${prefix}${roundMoney(num)}%`;
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text || '-';
}

function setPill(id, text, kind = 'neutral') {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = `pill ${kind}`;
}

function setOrdersLogOpen(open = false) {
  const el = document.getElementById('orders-log-panel');
  if (!el || !open) return;
  el.open = true;
}

function setMessagesLogOpen(open = false) {
  const el = document.getElementById('messages-log-panel');
  if (!el || !open) return;
  el.open = true;
}

function setSystemPanelOpen(open = false) {
  const el = document.getElementById('system-panel');
  if (!el || !open) return;
  el.open = true;
}

function openSystemPanel(options = {}) {
  const { focusLicense = false } = options;
  setSystemPanelOpen(true);
  const el = document.getElementById('system-panel');
  el?.scrollIntoView?.({ block: 'start', behavior: 'smooth' });
  if (focusLicense) {
    setTimeout(() => {
      document.getElementById('license-key')?.focus();
    }, 80);
  }
}

function setOrdersConfigPanelOpen(open = false) {
  const el = document.getElementById('orders-config-panel');
  if (!el || !open) return;
  el.open = true;
}

function setPricingLogOpen(open = false) {
  const el = document.getElementById('pricing-log-panel');
  if (!el || !open) return;
  el.open = true;
}

function getReplyText() {
  return document.getElementById('reply-en').value.trim();
}

function getReplyZhText() {
  return document.getElementById('reply-zh').value.trim();
}

function getRewriteInstruction() {
  return document.getElementById('rewrite-input').value.trim();
}

function cleanReplyDraftText(text, kind = 'en') {
  let value = String(text || '').trim();
  value = value
    .replace(/\\r\\n/g, '\n')
    .replace(/\\n/g, '\n')
    .replace(/\\t/g, ' ')
    .replace(/\\"/g, '"')
    .replace(/\\\\/g, '\\')
    .trim();

  if (kind === 'en') {
    value = value.replace(/^(?:hi|hello|dear)\s+[A-Za-z][A-Za-z' -]{0,40}[!,:]\s*/i, '');
    value = value.replace(/^\s*(reply|english reply|english)\s*:\s*/i, '');
    value = value.replace(/\n?\s*"?(replyZh|reply_zh|zh|chinese)"?\s*:\s*[\s\S]*$/i, '');
  } else {
    value = value.replace(/^\s*"?(replyZh|reply_zh|zh|chinese)"?\s*:\s*/i, '');
    value = value.replace(/\n?\s*"?(reply|english|english reply)"?\s*:\s*[\s\S]*$/i, '');
  }

  return value.replace(/\n{3,}/g, '\n\n').trim();
}

function setReplyFields(reply = '', replyZh = '') {
  document.getElementById('reply-en').value = cleanReplyDraftText(reply, 'en');
  document.getElementById('reply-zh').value = cleanReplyDraftText(replyZh, 'zh');
  scheduleDraftPersist();
}

function clearReplyDraft() {
  setReplyFields('', '');
}

function setBaseDraftFields(reply = '', replyZh = '') {
  state.baseReply = cleanReplyDraftText(reply, 'en');
  state.baseReplyZh = cleanReplyDraftText(replyZh, 'zh');
  document.getElementById('base-reply-en').value = state.baseReply;
  document.getElementById('base-reply-zh').value = state.baseReplyZh;
  updateBaseDraftActions();
  scheduleDraftPersist();
}

function clearBaseDraft() {
  setBaseDraftFields('', '');
}

function updateBaseDraftActions() {
  const btn = document.getElementById('restore-base');
  if (!btn) return;
  btn.disabled = !state.baseReply;
}

function updateApiUrl() {
  const el = document.getElementById('api-url');
  if (el) el.textContent = state.apiBase;
}

function setDraftStatus(text = '', kind = 'neutral') {
  const el = document.getElementById('draft-status');
  if (!el) return;
  if (!text) {
    el.textContent = '';
    el.className = 'status neutral is-hidden';
    return;
  }
  el.textContent = text;
  el.className = `status ${kind}`;
  if (kind === 'err') setMessagesLogOpen(true);
}

function setBusy(buttonId, busy, busyText) {
  const btn = document.getElementById(buttonId);
  if (!btn) return;
  if (busy) {
    btn.dataset.label = btn.textContent;
  } else if (!btn.dataset.label) {
    btn.dataset.label = btn.textContent;
  }
  btn.disabled = busy;
  btn.textContent = busy ? busyText : (btn.dataset.label || btn.textContent);
}

function getCurrentDraftKey() {
  if (!state.shopId || !state.convoId) return '';
  return `${state.shopId}::${state.convoId}`;
}

function extractConvoIdFromUrl(url = '') {
  const match = String(url || '').match(/\/messages\/(\d+)/);
  return match ? match[1] : '';
}

function isMessagesUrl(url = '') {
  return MESSAGES_URL_RE.test(String(url || ''));
}

function isOrdersUrl(url = '') {
  return ORDERS_URL_RE.test(String(url || ''));
}

function isPricingUrl(url = '') {
  return PRICING_URL_RE.test(String(url || ''));
}

function isMarketResearchUrl(url = '') {
  return MARKET_RESEARCH_URL_RE.test(String(url || ''));
}

function isShopAnalyticsUrl(url = '') {
  const href = String(url || '');
  if (!/^https:\/\/www\.etsy\.com\/your\//.test(href)) return false;
  if (isMessagesUrl(href) || isOrdersUrl(href)) return false;
  return /(dashboard|stats|analytics|traffic|performance|ads|marketing|listing|search-analytics)/i.test(href);
}

function detectModuleFromUrl(url = '') {
  if (isMarketResearchUrl(url) || isShopAnalyticsUrl(url)) return 'research';
  if (isPricingUrl(url)) return 'pricing';
  if (isOrdersUrl(url)) return 'orders';
  if (isMessagesUrl(url)) return 'messages';
  return '';
}

function buildMessageThreadKey(payload = {}) {
  const shopId = payload.shopId || state.shopId || '';
  const convoId = payload.convoId || state.convoId || '';
  return shopId && convoId ? `${shopId}::${convoId}` : '';
}

function buildMessageAutoKey(payload = {}) {
  const threadKey = buildMessageThreadKey(payload);
  const messageCount = Number(payload.messageCount || state.messageCount || 0);
  return threadKey ? `${threadKey}::${messageCount}` : '';
}

function buildOrderAutoKey(payload = {}) {
  const shopId = payload.shopId || state.orderShopId || '';
  const currentUrl = payload.currentUrl || state.orderCurrentUrl || '';
  const orderIds = Array.isArray(payload.orderIds) ? payload.orderIds : state.orderVisibleOrderIds;
  const orderSignature = orderIds.map((value) => normalizeOrderId(value)).filter(Boolean).join('|');
  const orderCount = Number(payload.orderCount || state.orderCount || 0);
  return shopId && currentUrl ? `${shopId}::${currentUrl}::${orderSignature || orderCount}` : '';
}

function buildPricingAutoKey(payload = {}) {
  const listingId = payload.listingId || state.pricingListingId || '';
  const currentUrl = payload.currentUrl || state.pricingCurrentUrl || '';
  const currentPrice = roundMoney(payload.currentPrice ?? state.pricingCurrentPrice ?? 0);
  const originalPrice = roundMoney(payload.originalPrice ?? state.pricingOriginalPrice ?? 0);
  const shippingAmount = roundMoney(payload.shippingAmount ?? state.pricingShippingAmount ?? 0);
  const variantSummary = String(payload.variantSummary || state.pricingVariantSummary || '').trim();
  return listingId && currentUrl
    ? `${listingId}::${currentUrl}::${currentPrice}::${originalPrice}::${shippingAmount}::${variantSummary}`
    : '';
}

function buildResearchAutoKey(payload = {}) {
  const pageType = payload.pageType || state.researchPageType || '';
  const subPageType = payload.subPageType || state.researchSubPageType || '';
  const currentUrl = payload.pageUrl || payload.currentUrl || state.researchCurrentUrl || '';
  const keyword = payload.keyword || state.researchKeyword || '';
  const shopId = payload.shopId || state.researchShopId || '';
  const sampleCount = Number(
    Array.isArray(payload.cards)
      ? payload.cards.length
      : (payload.sampleCount ?? state.researchSampleCount ?? 0)
  );
  return currentUrl
    ? `${pageType}::${subPageType}::${currentUrl}::${keyword}::${shopId}::${sampleCount}`
    : '';
}

function updateCollapseUi() {
  document.body.classList.toggle('is-collapsed', !!state.collapsed);
  const btn = document.getElementById('toggle-collapse');
  if (!btn) return;
  btn.textContent = state.collapsed ? '展开' : '收起';
  btn.title = state.collapsed ? '展开侧栏内容' : '收起侧栏内容';
  btn.setAttribute('aria-expanded', String(!state.collapsed));
}

async function setCollapsed(collapsed, persist = true) {
  state.collapsed = !!collapsed;
  updateCollapseUi();
  if (!persist) return;
  await chrome.storage.local.set({ [SIDE_PANEL_COLLAPSE_KEY]: state.collapsed });
}

async function loadCollapseState() {
  const data = await chrome.storage.local.get(SIDE_PANEL_COLLAPSE_KEY);
  state.collapsed = !!data[SIDE_PANEL_COLLAPSE_KEY];
  updateCollapseUi();
}

function updateModuleUi() {
  const modules = ['messages', 'orders', 'pricing', 'research'];
  modules.forEach((module) => {
    const tab = document.querySelector(`.module-tab[data-module="${module}"]`);
    const panel = document.getElementById(`module-${module}`);
    const active = state.activeModule === module;
    if (tab) tab.classList.toggle('is-active', active);
    if (panel) panel.classList.toggle('is-active', active);
  });
  updatePrimarySyncButton();
}

async function setActiveModule(module, persist = true) {
  state.activeModule = ['messages', 'orders', 'pricing', 'research'].includes(module) ? module : 'messages';
  updateModuleUi();
  if (persist) {
    await chrome.storage.local.set({ [SIDE_PANEL_ACTIVE_MODULE_KEY]: state.activeModule });
  }
}

async function loadActiveModuleState() {
  const data = await chrome.storage.local.get(SIDE_PANEL_ACTIVE_MODULE_KEY);
  const savedModule = data[SIDE_PANEL_ACTIVE_MODULE_KEY];
  state.activeModule = ['messages', 'orders', 'pricing', 'research'].includes(savedModule) ? savedModule : 'messages';
  updateModuleUi();
}

function updatePrimarySyncButton() {
  const btn = document.getElementById('sync-current');
  if (!btn) return;
  const label = state.activeModule === 'orders'
    ? '立即同步'
    : ((state.activeModule === 'pricing' || state.activeModule === 'research') ? '读取当前页' : '同步并生成');
  if (!btn.disabled) {
    btn.textContent = label;
  }
  btn.dataset.label = label;
  btn.title = state.activeModule === 'orders'
    ? '把当前订单页同步到后台'
    : (state.activeModule === 'pricing'
      ? '读取当前 listing 页面并更新定价上下文'
      : (state.activeModule === 'research'
        ? (state.researchMode === 'market'
          ? '读取当前搜索结果页或研究页面'
          : '读取当前店铺统计页')
        : '同步当前对话并生成回复建议'));
}

function cacheCurrentThreadView(autoKey = '') {
  const threadKey = getCurrentDraftKey();
  if (!threadKey) return;
  state.messageThreadCache[threadKey] = {
    autoKey: autoKey || buildMessageAutoKey(),
    messageCount: state.messageCount || 0,
    pendingBuyerCount: state.pendingBuyerCount || 0,
    hasMessageAttachments: !!state.hasMessageAttachments,
    lastDirection: state.lastDirection || '',
    latestBuyerMessage: state.latestBuyerMessage || '',
    latestBuyerMessageZh: state.latestBuyerMessageZh || '',
    buyerIntentZh: state.buyerIntentZh || '',
    replyFocusZh: state.replyFocusZh || ''
  };
}

function restoreCachedThreadView(cache) {
  if (!cache) return;
  state.messageCount = Number(cache.messageCount || state.messageCount || 0);
  state.pendingBuyerCount = Number(cache.pendingBuyerCount || 0);
  state.hasMessageAttachments = !!cache.hasMessageAttachments;
  state.lastDirection = cache.lastDirection || state.lastDirection || '';
  state.latestBuyerMessage = cache.latestBuyerMessage || '';
  state.latestBuyerMessageZh = cache.latestBuyerMessageZh || '';
  state.buyerIntentZh = cache.buyerIntentZh || '';
  state.replyFocusZh = cache.replyFocusZh || '';
  renderBuyerAnalysis();
}

function renderOrderSyncButton() {
  const btn = document.getElementById('sync-orders-current');
  if (!btn) return;
  btn.classList.remove('is-idle', 'is-checking', 'is-known', 'is-new');

  let label = '立即同步';
  let title = '把当前订单页同步到后台';
  let modifier = 'is-idle';

  if (!state.orderPageReady || !state.orderCount) {
    modifier = 'is-idle';
    label = '读取当前订单页';
    title = '先打开 Etsy Sold Orders 页面并读取当前订单页';
  } else if (state.orderCompareState === 'checking') {
    modifier = 'is-checking';
    label = `当前页 ${state.orderCount} 单，比对中...`;
    title = '正在比对当前页订单与后台记录';
  } else if (state.orderCompareState === 'has-new') {
    modifier = 'is-new';
    const count = state.orderNewOrderIds.length;
    label = count > 0 ? `新订单 ${count} 单，立即同步` : '立即同步';
    title = count > 0
      ? `当前页发现 ${count} 条未入库订单，点击后再执行同步`
      : '当前页发现未入库订单，点击后再执行同步';
  } else if (state.orderCompareState === 'known') {
    modifier = 'is-known';
    label = `当前页 ${state.orderCount} 单，已全部入库`;
    title = '当前页订单都已存在于后台，如需校正仍可手动重同步';
  }

  btn.classList.add(modifier);
  btn.dataset.label = label;
  btn.title = title;
  if (!state.orderSyncBusy) {
    btn.textContent = label;
  }
}

function pruneDraftEntries(drafts, limit = 30) {
  const entries = Object.entries(drafts || {});
  if (entries.length <= limit) return drafts || {};

  entries.sort((a, b) => {
    const timeA = new Date(a[1]?.updatedAt || 0).getTime();
    const timeB = new Date(b[1]?.updatedAt || 0).getTime();
    return timeB - timeA;
  });

  return Object.fromEntries(entries.slice(0, limit));
}

function collectCurrentDraft() {
  return {
    baseReplyEn: state.baseReply || '',
    baseReplyZh: state.baseReplyZh || '',
    replyEn: cleanReplyDraftText(document.getElementById('reply-en').value, 'en'),
    replyZh: cleanReplyDraftText(document.getElementById('reply-zh').value, 'zh'),
    rewriteInput: document.getElementById('rewrite-input').value.trim(),
    lastSellerIntent: state.lastSellerIntent || '',
    buyerName: state.buyerName || '',
    updatedAt: new Date().toISOString()
  };
}

async function persistCurrentDraft() {
  const draftKey = getCurrentDraftKey();
  if (!draftKey) return;

  const draft = collectCurrentDraft();
  const hasContent = Boolean(draft.replyEn || draft.replyZh || draft.rewriteInput);
  const data = await chrome.storage.local.get(SIDE_PANEL_DRAFTS_KEY);
  const drafts = data[SIDE_PANEL_DRAFTS_KEY] || {};

  if (hasContent) {
    drafts[draftKey] = draft;
    await chrome.storage.local.set({ [SIDE_PANEL_DRAFTS_KEY]: pruneDraftEntries(drafts) });
    return;
  }

  if (drafts[draftKey]) {
    delete drafts[draftKey];
    await chrome.storage.local.set({ [SIDE_PANEL_DRAFTS_KEY]: drafts });
  }
}

function scheduleDraftPersist() {
  if (draftPersistTimer) clearTimeout(draftPersistTimer);
  draftPersistTimer = setTimeout(() => {
    persistCurrentDraft().catch(() => {});
  }, 180);
}

async function clearPersistedDraftForCurrentThread() {
  const draftKey = getCurrentDraftKey();
  if (!draftKey) return;
  const data = await chrome.storage.local.get(SIDE_PANEL_DRAFTS_KEY);
  const drafts = data[SIDE_PANEL_DRAFTS_KEY] || {};
  if (!drafts[draftKey]) return;
  delete drafts[draftKey];
  await chrome.storage.local.set({ [SIDE_PANEL_DRAFTS_KEY]: drafts });
}

async function restoreDraftForCurrentThread() {
  const draftKey = getCurrentDraftKey();
  if (!draftKey) return false;

  const data = await chrome.storage.local.get(SIDE_PANEL_DRAFTS_KEY);
  const draft = data[SIDE_PANEL_DRAFTS_KEY]?.[draftKey];
  if (!draft) return false;

  const currentReply = getReplyText();
  const currentInstruction = getRewriteInstruction();

  if (!state.baseReply && (draft.baseReplyEn || draft.baseReplyZh)) {
    setBaseDraftFields(draft.baseReplyEn || '', draft.baseReplyZh || '');
  }

  if (!currentReply) {
    setReplyFields(draft.replyEn || '', draft.replyZh || '');
  }
  if (!currentInstruction && draft.rewriteInput) {
    document.getElementById('rewrite-input').value = draft.rewriteInput;
  }
  if (!state.lastSellerIntent && draft.lastSellerIntent) {
    state.lastSellerIntent = String(draft.lastSellerIntent || '').trim();
  }

  if (draft.replyEn || draft.rewriteInput) {
    setDraftStatus('已恢复上次未完成草稿。', 'neutral');
  }
  return true;
}

async function loadApiMode() {
  const select = document.getElementById('api-mode');
  const data = await chrome.storage.local.get('apiBase');
  state.apiBase = select ? (data.apiBase || CLOUD_URL) : CLOUD_URL;
  if (!select && data.apiBase && data.apiBase !== CLOUD_URL) {
    await chrome.storage.local.set({ apiBase: CLOUD_URL });
  }
  if (select) {
    select.value = state.apiBase.includes('localhost') ? 'local' : 'cloud';
  }
  updateApiUrl();
}

async function saveApiMode() {
  const mode = document.getElementById('api-mode')?.value || 'cloud';
  state.apiBase = mode === 'local' ? LOCAL_URL : CLOUD_URL;
  await chrome.storage.local.set({ apiBase: state.apiBase });
  updateApiUrl();
  await clearSessionState();
  await testConnection();
  await refreshLicenseStatus({ silent: true });
  state.lastMessageAutoKey = '';
  state.lastOrderAutoKey = '';
  state.lastPricingAutoKey = '';
  await syncVisibleContext({ force: true, reason: 'api-mode-change' });
}

async function refreshLicenseStatus(options = {}) {
  const { silent = false } = options;
  if (!state.licenseKey) {
    setLicenseState({ status: 'missing' });
    setLicenseStatus('未配置授权码。', silent ? 'neutral' : 'err');
    return false;
  }

  if (!silent) {
    setLicenseStatus('正在验证授权...', 'neutral');
  }

  try {
    const activated = await ensureSessionToken({ silent: true });
    if (!activated) {
      setLicenseState({ status: 'invalid' });
      setLicenseStatus('授权验证失败。', 'err');
      return false;
    }
    const res = await apiFetch(`${state.apiBase}/api/extension/license/status`);
    const data = await res.json();
    if (!res.ok || !data?.ok || !data.license) {
      setLicenseState({ status: 'invalid' });
      setLicenseStatus(data?.error || '授权验证失败。', 'err');
      return false;
    }

    setLicenseState({
      status: data.license.status || 'active',
      tenantName: data.license.tenantName || '',
      planLabel: data.license.planLabel || '',
      expiresAt: data.license.expiresAt || ''
    });
    setLicenseStatus('授权有效。', 'ok');
    return true;
  } catch (e) {
    setLicenseStatus('授权验证失败，请检查服务连接。', 'err');
    return false;
  }
}

async function ensureCloudCapabilities(featureLabel = '中文理解 / AI 回复 / 飞书同步') {
  const ok = await refreshLicenseStatus({ silent: true });
  if (ok) return true;
  setSystemPanelOpen(true);
  setMessagesLogOpen(true);
  setDraftStatus(`当前设备还没有可用授权。页面读取可以继续使用，但 ${featureLabel} 需要先在“设置 / 授权 / 状态”里输入授权码，并确认显示“授权有效”。`, 'err');
  return false;
}

async function saveLicenseKey() {
  const licenseKey = normalizeLicenseKeyInput(getInputValue('license-key'));
  state.licenseKey = licenseKey;
  setInputValue('license-key', licenseKey);
  await clearSessionState();
  await chrome.storage.local.set({ [EXTENSION_LICENSE_KEY]: licenseKey });
  if (!licenseKey) {
    setLicenseState({ status: 'missing' });
    setLicenseStatus('授权码已清空。', 'neutral');
    return;
  }
  const activated = await activateLicenseSession({ silent: false });
  if (activated) {
    await refreshLicenseStatus({ silent: true });
  }
}

async function testConnection() {
  setStatus('connection-status', '服务检查中...', 'neutral');
  setPill('connection-pill', '服务检查中...', 'neutral');
  try {
    const res = await apiFetch(`${state.apiBase}/api/messages/health`);
    const data = await res.json();
    const text = `服务正常 | ${data.threadCount || 0} 条对话`;
    setStatus(
      'connection-status',
      `服务已连接 | ${data.threadCount || 0} 条对话 | ${data.pendingCount || 0} 条待处理`,
      'ok'
    );
    setPill('connection-pill', text, 'ok');
  } catch (e) {
    setStatus('connection-status', '服务连接失败', 'err');
    setPill('connection-pill', '服务连接失败', 'err');
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function etsyPricingExtractionMainWorld() {
  const LISTING_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?listing\/(\d+)(?:\/|$|\?)/i;
  const SYMBOL_CURRENCY_MAP = {
    'HK$': 'HKD',
    'US$': 'USD',
    'CA$': 'CAD',
    'AU$': 'AUD',
    'NZ$': 'NZD',
    'SG$': 'SGD',
    'MX$': 'MXN',
    '€': 'EUR',
    '£': 'GBP',
    '$': 'USD'
  };

  function normalizeText(text) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizeCurrencyLocal(value) {
    return normalizeText(value).toUpperCase();
  }

  function roundMoneyLocal(value) {
    const num = Number(value || 0);
    return Number.isFinite(num) ? Math.round((num + Number.EPSILON) * 100) / 100 : 0;
  }

  function uniqueTexts(values) {
    const seen = new Set();
    const result = [];
    (values || []).forEach((value) => {
      const text = normalizeText(value);
      if (!text || seen.has(text)) return;
      seen.add(text);
      result.push(text);
    });
    return result;
  }

  function getNodeLines(node) {
    return uniqueTexts(
      String(node?.innerText || node?.textContent || '')
        .split('\n')
        .map((line) => normalizeText(line))
        .filter(Boolean)
    );
  }

  function getPageLines() {
    return getNodeLines(document.body);
  }

  function safeQueryAll(rootNode, selector) {
    try {
      return Array.from((rootNode || document).querySelectorAll(selector));
    } catch (e) {
      return [];
    }
  }

  function textFromSelector(selectors, rootNode = document) {
    for (const selector of selectors) {
      const node = rootNode.querySelector(selector);
      const text = normalizeText(node?.innerText || node?.textContent || '');
      if (text) return text;
    }
    return '';
  }

  function extractTextAfterLabel(text, pattern) {
    const raw = normalizeText(text);
    if (!raw) return '';
    const match = raw.match(pattern);
    if (!match) return '';
    return normalizeText(match[1] || raw.replace(pattern, ''));
  }

  function parseMoneyFromText(text, fallbackCurrency = '') {
    const raw = normalizeText(text);
    if (!raw) return { amount: 0, currency: normalizeText(fallbackCurrency).toUpperCase() || '', text: raw };

    const symbolMatch = raw.match(/(HK\$|US\$|CA\$|AU\$|NZ\$|SG\$|MX\$|€|£|\$)\s*([\d,]+(?:\.\d{1,2})?)/i);
    if (symbolMatch) {
      const currency = SYMBOL_CURRENCY_MAP[symbolMatch[1].toUpperCase()] || fallbackCurrency || 'USD';
      return {
        amount: Number(symbolMatch[2].replace(/,/g, '')) || 0,
        currency,
        text: raw
      };
    }

    const isoMatch = raw.match(/\b(USD|HKD|CAD|AUD|NZD|SGD|EUR|GBP|MXN|JPY|CNY|RMB|TRY|VND|THB|MYR|PHP|IDR)\s*([\d,]+(?:\.\d{1,2})?)/i);
    if (isoMatch) {
      const currency = isoMatch[1].toUpperCase() === 'RMB' ? 'CNY' : isoMatch[1].toUpperCase();
      return {
        amount: Number(isoMatch[2].replace(/,/g, '')) || 0,
        currency,
        text: raw
      };
    }

    const bareAmountMatch = raw.match(/(?:^|[^\d])(\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?)(?![\d])/);
    const bareAmountText = bareAmountMatch?.[1]?.replace(/,/g, '') || '';
    if (bareAmountMatch && bareAmountText.length <= 7 && normalizeText(fallbackCurrency) && (/price|amount|shipping|cost|total|sale|discount|off/i.test(raw) || (/^\d/.test(raw) && bareAmountText.includes('.')))) {
      return {
        amount: Number(bareAmountText) || 0,
        currency: normalizeText(fallbackCurrency).toUpperCase(),
        text: raw
      };
    }

    return {
      amount: 0,
      currency: normalizeText(fallbackCurrency).toUpperCase() || '',
      text: raw
    };
  }

  function extractPercentOffFromText(text) {
    const raw = normalizeText(text);
    if (!raw) return 0;
    const matches = Array.from(raw.matchAll(/(\d{1,3}(?:\.\d+)?)\s*%\s*off\b/gi));
    if (!matches.length) return 0;
    const last = matches[matches.length - 1];
    return roundMoneyLocal(Number(last?.[1] || 0) || 0);
  }

  function parseMoneyFromAttributes(node, fallbackCurrency = '') {
    if (!node?.attributes) {
      return { amount: 0, currency: normalizeCurrencyLocal(fallbackCurrency), text: '' };
    }
    for (const attr of Array.from(node.attributes)) {
      const parsed = parseMoneyFromText(attr.value, fallbackCurrency);
      if (parsed.amount > 0) return parsed;
    }
    return { amount: 0, currency: normalizeCurrencyLocal(fallbackCurrency), text: '' };
  }

  function findMoneyFromSelectors(selectors, fallbackCurrency = '', rootNode = document) {
    for (const selector of selectors) {
      const nodes = safeQueryAll(rootNode, selector);
      for (const node of nodes) {
        const parsed = parseMoneyFromText(node?.innerText || node?.textContent || '', fallbackCurrency);
        if (parsed.amount > 0) return parsed;
        const attrParsed = parseMoneyFromAttributes(node, fallbackCurrency);
        if (attrParsed.amount > 0) return attrParsed;
      }
    }
    return { amount: 0, currency: normalizeText(fallbackCurrency).toUpperCase() || '', text: '' };
  }

  function collectTextsFromNode(node) {
    if (!node) return [];
    const texts = [];
    const push = (value) => {
      const text = normalizeText(value);
      if (!text || text.length > 220) return;
      texts.push(text);
    };

    push(node?.innerText || node?.textContent || '');
    push(node?.getAttribute?.('aria-label') || '');
    push(node?.getAttribute?.('title') || '');
    push(node?.getAttribute?.('content') || '');

    const parentText = normalizeText(node?.closest?.('section,div,li,p,span')?.innerText || '');
    if (parentText && parentText.length <= 220) {
      texts.push(parentText);
    }

    return uniqueTexts(texts);
  }

  function collectTextsFromSelectors(selectors, limit = 120, rootNode = document) {
    const texts = [];
    let inspected = 0;
    for (const selector of selectors) {
      const nodes = safeQueryAll(rootNode, selector);
      for (const node of nodes) {
        texts.push(...collectTextsFromNode(node));
        inspected += 1;
        if (inspected >= limit) {
          return uniqueTexts(texts);
        }
      }
    }
    return uniqueTexts(texts);
  }

  function extractMoneyNearLabel(text, labelPattern, fallbackCurrency = '') {
    const raw = normalizeText(text);
    if (!raw) {
      return { amount: 0, currency: normalizeCurrencyLocal(fallbackCurrency), text: '' };
    }

    const flags = labelPattern.flags.includes('g') ? labelPattern.flags : `${labelPattern.flags}g`;
    const regex = new RegExp(labelPattern.source, flags);
    let match;
    while ((match = regex.exec(raw))) {
      const tail = raw.slice(match.index + match[0].length);
      const parsed = parseMoneyFromText(tail, fallbackCurrency);
      if (parsed.amount > 0) return parsed;
    }

    return { amount: 0, currency: normalizeCurrencyLocal(fallbackCurrency), text: '' };
  }

  function findMoneyNearLabelInTexts(texts, labelPattern, fallbackCurrency = '') {
    for (const text of texts || []) {
      const parsed = extractMoneyNearLabel(text, labelPattern, fallbackCurrency);
      if (parsed.amount > 0) return parsed;
    }
    return { amount: 0, currency: normalizeCurrencyLocal(fallbackCurrency), text: '' };
  }

  function findPercentOffInTexts(texts) {
    for (const text of texts || []) {
      const percent = extractPercentOffFromText(text);
      if (percent > 0) return percent;
    }
    return 0;
  }

  function extractLabelValueFromSelectors(selectors, patterns = [], rootNode = document) {
    const texts = collectTextsFromSelectors(selectors, 80, rootNode);
    for (const text of texts) {
      const matchedPattern = patterns.find((pattern) => pattern.test(text));
      if (!matchedPattern) continue;
      const sameText = extractTextAfterLabel(text, matchedPattern);
      if (sameText) return sameText;
    }
    return '';
  }

  function parseJsonLd() {
    const offers = [];
    const titles = [];
    const shippingTexts = [];
    const locationTexts = [];
    const sellerCountryTexts = [];
    const destinationCountryTexts = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach((script) => {
      const raw = script.textContent || '';
      if (!raw.trim()) return;
      try {
        const parsed = JSON.parse(raw);
        const queue = Array.isArray(parsed) ? [...parsed] : [parsed];
        while (queue.length) {
          const item = queue.shift();
          if (!item || typeof item !== 'object') continue;
          if (Array.isArray(item['@graph'])) {
            queue.push(...item['@graph']);
          }
          if (item.name) titles.push(item.name);
          if (item.offers) {
            const offerItems = Array.isArray(item.offers) ? item.offers : [item.offers];
            offerItems.forEach((offer) => {
              offers.push(offer);
              if (offer?.shippingDetails) {
                const shippingDetails = Array.isArray(offer.shippingDetails) ? offer.shippingDetails : [offer.shippingDetails];
                shippingDetails.forEach((detail) => {
                  if (detail?.shippingRate) {
                    shippingTexts.push(
                      normalizeText(
                        [
                          detail.shippingRate.currency,
                          detail.shippingRate.value,
                          detail.shippingRate.price,
                          detail.shippingRate.name
                        ].filter(Boolean).join(' ')
                      )
                    );
                  }
                  if (detail?.shippingDestination?.addressCountry) {
                    destinationCountryTexts.push(String(detail.shippingDestination.addressCountry));
                  }
                });
              }
            });
          }
          if (item.address?.addressCountry) {
            sellerCountryTexts.push(String(item.address.addressCountry));
          }
          if (item.address?.addressLocality) {
            locationTexts.push(String(item.address.addressLocality));
          }
          if (item.location?.name) {
            locationTexts.push(String(item.location.name));
          }
        }
      } catch (e) {}
    });
    return {
      offers,
      titles: uniqueTexts(titles),
      shippingTexts: uniqueTexts(shippingTexts),
      locationTexts: uniqueTexts(locationTexts),
      sellerCountryTexts: uniqueTexts(sellerCountryTexts),
      destinationCountryTexts: uniqueTexts(destinationCountryTexts)
    };
  }

  function getObjectKeys(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return [];
    return Object.keys(value).map((key) => String(key || ''));
  }

  function collectStructuredTextCandidates(value) {
    if (!value || typeof value !== 'object') return [];
    const seen = new Set();
    const result = [];
    [
      value.text,
      value.label,
      value.name,
      value.title,
      value.display,
      value.displayValue,
      value.display_value,
      value.formatted,
      value.formattedValue,
      value.formatted_value,
      value.formattedShort,
      value.formatted_short,
      value.formattedLong,
      value.formatted_long,
      value.summary,
      value.description,
      value.location,
      value.country,
      value.countryName,
      value.country_name,
      value.region,
      value.locality,
      value.city,
      value.value
    ].forEach((candidate) => {
      const text = normalizeText(candidate);
      if (!text || text.length > 180 || seen.has(text)) return;
      if (/^\[object\s+/i.test(text)) return;
      if (!/[A-Za-z$€£¥]|HK\$|US\$|CA\$|AU\$|NZ\$|SG\$|\d/.test(text)) return;
      seen.add(text);
      result.push(text);
    });
    return result;
  }

  function extractStructuredAmount(value) {
    if (!value || typeof value !== 'object') {
      return { amount: 0, divisor: 1 };
    }

    const numericCandidates = [
      value.amount,
      value.price,
      value.value,
      value.rawAmount,
      value.raw_amount,
      value.priceAmount,
      value.price_amount,
      value.moneyAmount,
      value.money_amount,
      value.discountedPrice,
      value.discounted_price,
      value.originalPrice,
      value.original_price
    ];
    const divisor = Number(value.divisor || value.scale || value.base || 1);
    for (const candidate of numericCandidates) {
      const num = Number(candidate);
      if (!Number.isFinite(num)) continue;
      if (divisor > 1 && Math.abs(num) >= divisor) {
        return { amount: num / divisor, divisor };
      }
      return { amount: num, divisor: divisor > 0 ? divisor : 1 };
    }
    return { amount: 0, divisor: divisor > 0 ? divisor : 1 };
  }

  function extractStructuredCurrency(value, fallbackCurrency = '') {
    if (!value || typeof value !== 'object') {
      return normalizeCurrencyLocal(fallbackCurrency);
    }
    return normalizeCurrencyLocal(
      value.currency
      || value.currencyCode
      || value.currency_code
      || value.currencyIsoCode
      || value.currency_iso_code
      || value.priceCurrency
      || value.price_currency
      || fallbackCurrency
    );
  }

  function collectStructuredMoneyTexts(value, fallbackCurrency = '') {
    if (!value || typeof value !== 'object') return [];
    const result = [];
    const structuredTexts = collectStructuredTextCandidates(value);
    structuredTexts.forEach((text) => {
      if (parseMoneyFromText(text, fallbackCurrency).amount > 0 || /free shipping/i.test(text)) {
        result.push(text);
      }
    });

    const { amount } = extractStructuredAmount(value);
    const currency = extractStructuredCurrency(value, fallbackCurrency);
    if (amount > 0) {
      result.push(currency ? `${currency} ${roundMoneyLocal(amount)}` : String(roundMoneyLocal(amount)));
    }
    return uniqueTexts(result);
  }

  function isDestinationContext(keyPath = '', keys = []) {
    const haystack = `${keyPath} ${(keys || []).join(' ')}`.toLowerCase();
    return /(destination|buyer|postal|zip|ship_to|shipping_destination|delivery_destination|to_address|postal_code|country_to|country_from_to)/i.test(haystack);
  }

  function isSellerContext(keyPath = '', keys = []) {
    const haystack = `${keyPath} ${(keys || []).join(' ')}`.toLowerCase();
    return /(shop|seller|origin|ships?_from|dispatch|based|location|made_in|from_country|shop_location|seller_location)/i.test(haystack);
  }

  function collectVariationTexts(value, fallbackCurrency = '') {
    if (!value || typeof value !== 'object') return [];
    const texts = [
      ...collectStructuredTextCandidates(value),
      ...collectStructuredMoneyTexts(value, fallbackCurrency)
    ];
    return texts.filter((text) => {
      return /option|variation|attribute|property|size|color|colour|style|finish|material|pack|qty|quantity|set|personal/i.test(text)
        || parseMoneyFromText(text, fallbackCurrency).amount > 0
        || /(?:^|\s)\+\s*(?:HK\$|US\$|CA\$|AU\$|NZ\$|SG\$|€|£|\$|\d)/i.test(text);
    });
  }

  function scanContextHints() {
    const hints = {
      shopNames: [],
      shippingTexts: [],
      shipFromTexts: [],
      locationTexts: [],
      sellerCountryTexts: [],
      destinationCountryTexts: [],
      priceTexts: [],
      variationTexts: []
    };

    const roots = [
      window.Etsy?.Context?.data,
      window.Etsy?.Context?.data?.initial_data,
      window.__INITIAL_STATE__,
      window.__NEXT_DATA__
    ].filter(Boolean);
    const seen = new WeakSet();
    const queue = roots.map((root) => ({ value: root, depth: 0, keyPath: 'root' }));
    let scanned = 0;

    while (queue.length > 0 && scanned < 2500) {
      const current = queue.shift();
      const value = current?.value;
      const depth = Number(current?.depth || 0);
      const keyPath = String(current?.keyPath || '');
      if (!value || depth > 5) continue;

      if (typeof value === 'object') {
        if (seen.has(value)) continue;
        seen.add(value);
      }
      scanned += 1;

      if (value && typeof value === 'object' && !Array.isArray(value)) {
        const keys = getObjectKeys(value);
        const lowerKey = `${keyPath} ${keys.join(' ')}`.toLowerCase();
        const structuredTexts = collectStructuredTextCandidates(value);
        const moneyTexts = collectStructuredMoneyTexts(value);
        const variationTexts = collectVariationTexts(value);

        if (/shop_name|shop name|seller_name|seller name/i.test(lowerKey)) {
          hints.shopNames.push(...structuredTexts);
        }
        if (/(shipping|ship|delivery|dispatch)/i.test(lowerKey)) {
          hints.shippingTexts.push(
            ...moneyTexts,
            ...structuredTexts.filter((text) => /shipping|delivery|dispatch|free shipping/i.test(text))
          );
        }
        if (/(ships_from|ship_from|dispatch|origin|country_of_origin)/i.test(lowerKey)) {
          hints.shipFromTexts.push(...structuredTexts);
        }
        if (/price|amount|money|discount|sale_price|price_raw|price_value/i.test(lowerKey)) {
          hints.priceTexts.push(...moneyTexts, ...structuredTexts);
        }
        if (/variation|option|attribute|property|selection|personalization|personalisation/i.test(lowerKey)) {
          hints.variationTexts.push(...variationTexts);
        }
        if (/country|region|location|based|origin|locality/i.test(lowerKey)) {
          if (isDestinationContext(keyPath, keys)) {
            hints.destinationCountryTexts.push(...structuredTexts);
          } else if (isSellerContext(keyPath, keys)) {
            hints.locationTexts.push(...structuredTexts);
            hints.sellerCountryTexts.push(...structuredTexts);
          } else {
            hints.locationTexts.push(...structuredTexts.filter((text) => /(located in|based in|ships from|dispatches from)/i.test(text)));
          }
        }
      }

      if (typeof value === 'string') {
        const text = normalizeText(value);
        if (!text) continue;
        const lowerKey = keyPath.toLowerCase();
        if (lowerKey.includes('shop_name')) hints.shopNames.push(text);
        if (/(shipping|ship|delivery|dispatch)/i.test(lowerKey) && (/free shipping|shipping|\$|€|£|hk\$|usd|cad|aud/i.test(text) || parseMoneyFromText(text).amount > 0)) {
          hints.shippingTexts.push(text);
        }
        if (/(ships_from|ship_from|dispatch|origin)/i.test(lowerKey) || /^(ships? from|dispatches from)\b/i.test(text)) {
          hints.shipFromTexts.push(text);
        }
        if (/(location|region|based|origin)/i.test(lowerKey) || /(located in|based in)/i.test(text)) {
          if (!isDestinationContext(lowerKey)) {
            hints.locationTexts.push(text);
          }
        }
        if (/(country)/i.test(lowerKey)) {
          if (isDestinationContext(lowerKey)) {
            hints.destinationCountryTexts.push(text);
          } else if (isSellerContext(lowerKey)) {
            hints.sellerCountryTexts.push(text);
          }
        }
        if (/(price|amount|money|discount)/i.test(lowerKey) || parseMoneyFromText(text).amount > 0) {
          hints.priceTexts.push(text);
        }
        if (/(variation|option|attribute|property|selection)/i.test(lowerKey)) {
          hints.variationTexts.push(text);
        }
        continue;
      }

      if (typeof value === 'number') {
        if (/(price|amount|money|discount)/i.test(keyPath)) {
          hints.priceTexts.push(`${keyPath}: ${value}`);
        }
        continue;
      }

      if (Array.isArray(value)) {
        value.slice(0, 30).forEach((item, index) => {
          queue.push({ value: item, depth: depth + 1, keyPath: `${keyPath}[${index}]` });
        });
        continue;
      }

      if (value && typeof value === 'object') {
        Object.entries(value).slice(0, 80).forEach(([key, child]) => {
          queue.push({ value: child, depth: depth + 1, keyPath: `${keyPath}.${key}` });
        });
      }
    }

    Object.keys(hints).forEach((key) => {
      hints[key] = uniqueTexts(hints[key]);
    });
    return hints;
  }

  function extractTitle(jsonLdTitles, rootNode = document) {
    const direct = textFromSelector([
      'h1[data-buy-box-listing-title]',
      'h1',
      '[data-listing-id] h1'
    ], rootNode);
    if (direct) return direct;
    return jsonLdTitles[0] || document.title.replace(/\s*-\s*Etsy\s*$/i, '').trim();
  }

  function extractShopName(contextHints, rootNode = document) {
    const scopedLinks = safeQueryAll(rootNode, 'a[href*="/shop/"]');
    const links = scopedLinks.length ? scopedLinks : Array.from(document.querySelectorAll('a[href*="/shop/"]'));
    for (const link of links) {
      const href = link.getAttribute('href') || '';
      const match = href.match(/\/shop\/([^/?#]+)/i);
      if (match?.[1]) return decodeURIComponent(match[1]);
      const text = normalizeText(link.textContent || '');
      if (text && !/star seller|sales/i.test(text)) return text;
    }
    const contextShop = normalizeText(window.Etsy?.Context?.data?.shop_name || '');
    return contextShop || contextHints.shopNames[0] || '';
  }

  function extractShippingText(lines, jsonLd, contextHints, fallbackCurrency = '', rootNode = document) {
    const directCandidates = [];
    [
      '[data-selector*="shipping"]',
      '[data-selector*="cost-to-ship"]',
      '[data-selector*="price-shipping"]',
      '[data-test-id*="shipping"]',
      '[aria-label*="shipping" i]',
      '[data-buy-box-region] [class*="shipping"]',
      '[class*="shipping"]',
      '[class*="delivery"]',
      '[class*="dispatch"]'
    ].forEach((selector) => {
      safeQueryAll(rootNode, selector).forEach((node) => {
        const text = normalizeText(node?.innerText || node?.textContent || '');
        if (text) directCandidates.push(text);
        const ariaLabel = normalizeText(node?.getAttribute?.('aria-label') || '');
        if (ariaLabel) directCandidates.push(ariaLabel);
        const parentText = normalizeText(node?.closest?.('section,div,li,p')?.innerText || '');
        if (parentText) directCandidates.push(parentText);
      });
    });

    safeQueryAll(rootNode, '*').forEach((node) => {
      const text = normalizeText(node?.innerText || node?.textContent || '');
      if (text && /(shipping|delivery|dispatch|arrives|cost to ship)/i.test(text)) {
        directCandidates.push(text);
      }
      const ariaLabel = normalizeText(node?.getAttribute?.('aria-label') || '');
      if (ariaLabel && /(shipping|delivery|dispatch|arrives|cost to ship)/i.test(ariaLabel)) {
        directCandidates.push(ariaLabel);
      }
    });

    const textCandidates = [
      ...directCandidates,
      ...jsonLd.shippingTexts,
      ...contextHints.shippingTexts
    ];

    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      if (!/(free shipping|cost to ship|shipping|delivery)/i.test(line)) continue;
      textCandidates.push(normalizeText([line, lines[i + 1], lines[i + 2]].filter(Boolean).join(' ')));
    }

    const normalizedCandidates = uniqueTexts(textCandidates);
    for (const candidate of normalizedCandidates) {
      const parsed = parseMoneyFromText(candidate, fallbackCurrency);
      if (/free shipping/i.test(candidate) || parsed.amount > 0) {
        return candidate;
      }
    }

    return normalizedCandidates.find((candidate) => /(shipping|delivery)/i.test(candidate)) || '';
  }

  function extractLocationLine(lines, patterns = []) {
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      if (!patterns.some((pattern) => pattern.test(line))) continue;
      return normalizeText([line, lines[i + 1]].filter(Boolean).join(' '));
    }
    return '';
  }

  function extractOwnedByLocation(lines) {
    for (let i = 0; i < lines.length; i += 1) {
      const line = normalizeText(lines[i] || '');
      if (!/^owned by\b/i.test(line)) continue;

      const sameLineCountry = normalizeText(line.replace(/^owned by\b/i, '').replace(/^[:：-]\s*/, ''));
      const inMatch = sameLineCountry.match(/\b(?:in|from)\s+([A-Za-z][A-Za-z .'-]{1,60})$/i);
      if (inMatch?.[1]) return normalizeText(inMatch[1]);

      const nextLine = normalizeText(lines[i + 1] || '');
      if (nextLine && !/star seller|sales|reviews|since|shop|contact/i.test(nextLine)) {
        return nextLine;
      }
    }
    return '';
  }

  function extractLabelValueFromLines(lines, patterns = []) {
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      const matchedPattern = patterns.find((pattern) => pattern.test(line));
      if (!matchedPattern) continue;
      const sameLine = extractTextAfterLabel(line, matchedPattern);
      if (sameLine) return sameLine;
      const nextLine = normalizeText(lines[i + 1] || '');
      if (nextLine) return nextLine;
    }
    return '';
  }

  function extractSelectedVariations(rootNode = document) {
    const selected = [];
    const priceHints = [];

    safeQueryAll(rootNode, 'select').forEach((select) => {
      const selectedOption = select.selectedOptions?.[0];
      const label = normalizeText(
        select.closest('label')?.innerText
        || select.closest('[data-selector*="variation"]')?.querySelector('label')?.innerText
        || select.getAttribute('aria-label')
        || ''
      );
      const optionText = normalizeText(selectedOption?.textContent || '');
      const selectedOptionAttrPrice = parseMoneyFromAttributes(selectedOption, '');
      const selectedOptionPrice = selectedOptionAttrPrice.amount > 0 ? selectedOptionAttrPrice : parseMoneyFromText(optionText);
      if (label && optionText && !/select an option/i.test(optionText)) {
        selected.push(
          selectedOptionPrice.amount > 0
            ? `${label}: ${optionText} (${selectedOptionPrice.text})`
            : `${label}: ${optionText}`
        );
      }

      Array.from(select.options || []).forEach((option) => {
        const optionLabel = normalizeText(option.textContent || '');
        if (!optionLabel || /select an option/i.test(optionLabel)) return;
        const optionAttrPrice = parseMoneyFromAttributes(option, '');
        const optionPrice = optionAttrPrice.amount > 0 ? optionAttrPrice : parseMoneyFromText(optionLabel);
        if (optionPrice.amount > 0) {
          priceHints.push(label ? `${label}: ${optionLabel}` : optionLabel);
        }
      });
    });

    safeQueryAll(rootNode, 'fieldset').forEach((fieldset) => {
      const legend = normalizeText(fieldset.querySelector('legend')?.textContent || '');
      const checked = fieldset.querySelector('input[type="radio"]:checked');
      if (checked) {
        const labelText = normalizeText(
          checked.closest('label')?.innerText
          || fieldset.querySelector(`label[for="${checked.id}"]`)?.innerText
          || checked.value
        );
        const checkedAttrPrice = parseMoneyFromAttributes(checked.closest('label') || checked, '');
        const checkedPrice = checkedAttrPrice.amount > 0 ? checkedAttrPrice : parseMoneyFromText(labelText);
        if (legend && labelText) {
          selected.push(
            checkedPrice.amount > 0
              ? `${legend}: ${labelText} (${checkedPrice.text})`
              : `${legend}: ${labelText}`
          );
        }
      }

      fieldset.querySelectorAll('label').forEach((label) => {
        const optionLabel = normalizeText(label.innerText || label.textContent || '');
        const optionAttrPrice = parseMoneyFromAttributes(label, '');
        const optionPrice = optionAttrPrice.amount > 0 ? optionAttrPrice : parseMoneyFromText(optionLabel);
        if (optionPrice.amount > 0) {
          priceHints.push(legend ? `${legend}: ${optionLabel}` : optionLabel);
        }
      });
    });

    safeQueryAll(rootNode, '[role="radio"][aria-checked="true"], [role="option"][aria-selected="true"], button[aria-pressed="true"], [aria-current="true"]').forEach((node) => {
      if (!node.closest('[data-buy-box-region], fieldset, [role="radiogroup"], [role="listbox"]')) return;
      const text = normalizeText(node?.innerText || node?.textContent || node?.getAttribute?.('aria-label') || '');
      if (!text || text.length > 160) return;
      const container = node.closest('fieldset, section, div, li, ul');
      const label = normalizeText(
        container?.querySelector('legend')?.textContent
        || container?.querySelector('label')?.textContent
        || container?.getAttribute?.('aria-label')
        || container?.closest('[data-selector*="variation"], [data-test-id*="variation"]')?.getAttribute?.('aria-label')
        || ''
      );
      const parsed = parseMoneyFromAttributes(node, '')?.amount > 0 ? parseMoneyFromAttributes(node, '') : parseMoneyFromText(text);
      if (label && !/select an option/i.test(text)) {
        selected.push(parsed.amount > 0 ? `${label}: ${text} (${parsed.text})` : `${label}: ${text}`);
      } else if (!/select an option/i.test(text)) {
        selected.push(parsed.amount > 0 ? `${text} (${parsed.text})` : text);
      }
    });

    safeQueryAll(rootNode, '[data-selector*="variation"], [data-test-id*="variation"], [class*="variation"], [role="listbox"], [role="radiogroup"]').forEach((container) => {
      const label = normalizeText(
        container?.querySelector('legend')?.textContent
        || container?.querySelector('label')?.textContent
        || container?.getAttribute?.('aria-label')
        || ''
      );
      Array.from(container.querySelectorAll('button, [role="option"], [role="radio"], label, option')).slice(0, 40).forEach((node) => {
        const text = normalizeText(node?.innerText || node?.textContent || node?.getAttribute?.('aria-label') || '');
        if (!text || /select an option/i.test(text)) return;
        const parsed = parseMoneyFromAttributes(node, '')?.amount > 0 ? parseMoneyFromAttributes(node, '') : parseMoneyFromText(text);
        if (parsed.amount > 0 || /(?:^|\s)\+\s*(?:HK\$|US\$|CA\$|AU\$|NZ\$|SG\$|€|£|\$|\d)/i.test(text)) {
          priceHints.push(label ? `${label}: ${text}` : text);
        }
      });
    });

    return {
      selected: uniqueTexts(selected),
      priceHints: uniqueTexts(priceHints).slice(0, 12)
    };
  }

  const match = window.location.href.match(LISTING_URL_RE);
  const listingId = match?.[1] || '';
  const isListingPage = Boolean(listingId);
  const buyBoxRoot = document.querySelector('[data-buy-box-region]') || document.body;
  const lines = getPageLines();
  const buyBoxLines = getNodeLines(buyBoxRoot);
  const jsonLd = parseJsonLd();
  const contextHints = scanContextHints();
  const jsonLdOffer = jsonLd.offers.find((offer) => Number(offer?.price) > 0) || {};
  const currencyMeta = normalizeText(
    document.querySelector('meta[property="product:price:currency"]')?.getAttribute('content')
    || document.querySelector('meta[itemprop="priceCurrency"]')?.getAttribute('content')
    || jsonLdOffer.priceCurrency
    || ''
  ).toUpperCase();

  const priceTextCandidates = uniqueTexts([
    ...buyBoxLines,
    ...collectTextsFromSelectors([
      '[data-selector*="price"]',
      '[data-selector*="discount"]',
      '[data-test-id*="price"]',
      '[aria-label*="price" i]',
      '[aria-label*="off" i]',
      's',
      '.wt-text-strikethrough',
      '.wt-text-title-larger',
      '.wt-text-title-03'
    ], 140, buyBoxRoot),
    ...collectTextsFromSelectors([
      'meta[property="product:price:amount"]',
      'meta[itemprop="price"]'
    ], 20, document)
  ]).slice(0, 220);

  const currentPriceLabelCandidate = findMoneyNearLabelInTexts(
    priceTextCandidates,
    /(?:sale|discounted|current)\s*price\b[:：]*/i,
    currencyMeta
  );
  const originalPriceLabelCandidate = findMoneyNearLabelInTexts(
    priceTextCandidates,
    /(?:original|regular|list)\s*price\b[:：]*/i,
    currencyMeta
  );
  const explicitDiscountPercent = findPercentOffInTexts(priceTextCandidates);
  const priceAmountMeta = normalizeText(
    document.querySelector('meta[property="product:price:amount"]')?.getAttribute('content')
    || document.querySelector('meta[itemprop="price"]')?.getAttribute('content')
    || ''
  );
  const currentPriceMetaCandidate = priceAmountMeta
    ? parseMoneyFromText(`${currencyMeta || ''} ${priceAmountMeta}`.trim(), currencyMeta)
    : { amount: 0, currency: normalizeCurrencyLocal(currencyMeta), text: '' };

  const currentPriceDynamicCandidate = findMoneyFromSelectors([
    '[aria-label*="Sale price" i]',
    '[aria-label*="Discounted price" i]',
    '[aria-label*="Current price" i]',
    '[data-selector*="price"]',
    '[data-test-id*="price"]',
    '.wt-text-title-larger',
    '.wt-text-title-03'
  ], currencyMeta, buyBoxRoot);
  const currentPriceCandidate = currentPriceLabelCandidate.amount > 0
    ? currentPriceLabelCandidate
    : (currentPriceDynamicCandidate.amount > 0
      ? currentPriceDynamicCandidate
      : currentPriceMetaCandidate);
  const originalPriceCandidate = originalPriceLabelCandidate.amount > 0
    ? originalPriceLabelCandidate
    : findMoneyFromSelectors([
      '[aria-label*="Original price" i]',
      '[data-test-id*="original-price"]',
      's',
      '.wt-text-strikethrough'
    ], currencyMeta, buyBoxRoot);

  const currentPriceContextCandidate = findMoneyFromSelectors([
    '[data-selector*="price"]',
    '[data-test-id*="price"]',
    '.wt-text-title-larger',
    '.wt-text-title-03'
  ], currencyMeta, buyBoxRoot);

  const selectedVariations = extractSelectedVariations(buyBoxRoot);
  const shippingText = extractShippingText(buyBoxLines, jsonLd, contextHints, currencyMeta || currentPriceCandidate.currency || '', buyBoxRoot);
  const shippingParsed = /free shipping/i.test(shippingText)
    ? { amount: 0, currency: currencyMeta || currentPriceCandidate.currency || '', text: shippingText }
    : parseMoneyFromText(shippingText, currencyMeta || currentPriceCandidate.currency || '');

  const contextPriceCandidate = contextHints.priceTexts
    .map((text) => parseMoneyFromText(text, currencyMeta))
    .find((parsed) => parsed.amount > 0) || { amount: 0, currency: '', text: '' };
  const selectedVariationPriceCandidate = selectedVariations.selected
    .map((text) => parseMoneyFromText(text, currencyMeta))
    .find((parsed) => parsed.amount > 0) || { amount: 0, currency: '', text: '' };
  let currentPrice = currentPriceLabelCandidate.amount
    || selectedVariationPriceCandidate.amount
    || currentPriceDynamicCandidate.amount
    || currentPriceContextCandidate.amount
    || contextPriceCandidate.amount
    || Number(jsonLdOffer.price || 0)
    || currentPriceMetaCandidate.amount
    || 0;
  let originalPrice = originalPriceLabelCandidate.amount || (originalPriceCandidate.amount > currentPrice ? originalPriceCandidate.amount : 0);
  if (originalPrice > 0 && explicitDiscountPercent > 0 && (!currentPrice || currentPrice >= originalPrice) && explicitDiscountPercent < 100) {
    currentPrice = roundMoneyLocal(originalPrice * (1 - (explicitDiscountPercent / 100)));
  }
  const derivedOriginalFromDiscount = explicitDiscountPercent > 0 && currentPrice > 0 && explicitDiscountPercent < 100
    ? roundMoneyLocal(currentPrice / (1 - (explicitDiscountPercent / 100)))
    : 0;
  const impliedDiscountFromPair = originalPrice > currentPrice && currentPrice > 0
    ? Math.round(((1 - (currentPrice / originalPrice)) * 100) * 100) / 100
    : 0;
  if (!originalPrice && derivedOriginalFromDiscount > 0) {
    originalPrice = derivedOriginalFromDiscount;
  } else if (derivedOriginalFromDiscount > 0 && (!impliedDiscountFromPair || Math.abs(impliedDiscountFromPair - explicitDiscountPercent) > 1.2)) {
    originalPrice = derivedOriginalFromDiscount;
  }
  if (!originalPrice && explicitDiscountPercent > 0 && currentPrice > 0 && explicitDiscountPercent < 100) {
    originalPrice = roundMoneyLocal(currentPrice / (1 - (explicitDiscountPercent / 100)));
  }
  if (!originalPrice) {
    originalPrice = currentPrice;
  }
  const currency = normalizeCurrencyLocal(
    currentPriceCandidate.currency
    || currencyMeta
    || jsonLdOffer.priceCurrency
    || contextPriceCandidate.currency
    || ''
  );
  const shippingCurrency = normalizeCurrencyLocal(shippingParsed.currency || currency);
  const discountPercent = explicitDiscountPercent > 0
    ? explicitDiscountPercent
    : (currentPrice > 0 && originalPrice > currentPrice
      ? Math.round(((1 - (currentPrice / originalPrice)) * 100) * 100) / 100
      : 0);
  const ownedByLocationText = extractOwnedByLocation(lines);
  const shopLocationText = extractLabelValueFromSelectors([
    '[aria-label*="Seller based in" i]',
    '[aria-label*="Located in" i]',
    '[aria-label*="Based in" i]',
    '[data-selector*="location"]',
    '[data-selector*="based"]'
  ], [
    /^shop location\b[:：]?\s*(.*)$/i,
    /^seller based in\b[:：]?\s*(.*)$/i,
    /^located in\b[:：]?\s*(.*)$/i,
    /^based in\b[:：]?\s*(.*)$/i
  ], buyBoxRoot) || extractLabelValueFromLines(buyBoxLines, [
    /^shop location\b[:：]?\s*(.*)$/i,
    /^seller based in\b[:：]?\s*(.*)$/i,
    /^located in\b[:：]?\s*(.*)$/i,
    /^based in\b[:：]?\s*(.*)$/i
  ]) || extractLocationLine(buyBoxLines, [/located in/i, /based in/i]) || ownedByLocationText || contextHints.locationTexts[0] || contextHints.sellerCountryTexts[0] || jsonLd.locationTexts[0] || jsonLd.sellerCountryTexts[0] || '';
  const shipsFromText = extractLabelValueFromSelectors([
    '[aria-label*="Ships from" i]',
    '[aria-label*="Dispatches from" i]',
    '[aria-label*="Ship from" i]',
    '[data-selector*="ships-from"]',
    '[data-selector*="ship-from"]',
    '[data-selector*="dispatch"]',
    '[data-test-id*="ships-from"]',
    '[data-test-id*="dispatch"]'
  ], [
    /^ships? from\b[:：]?\s*(.*)$/i,
    /^dispatches from\b[:：]?\s*(.*)$/i,
    /^ship from\b[:：]?\s*(.*)$/i
  ], buyBoxRoot) || extractLabelValueFromLines(buyBoxLines, [
    /^ships? from\b[:：]?\s*(.*)$/i,
    /^dispatches from\b[:：]?\s*(.*)$/i,
    /^ship from\b[:：]?\s*(.*)$/i
  ]) || extractLocationLine(buyBoxLines, [/^ships? from\b/i, /^dispatches from\b/i, /^ship from\b/i]) || contextHints.shipFromTexts[0] || '';

  const variantSummaryParts = [];
  if (selectedVariations.selected.length > 0) {
    variantSummaryParts.push(`当前选择: ${selectedVariations.selected.join(' | ')}`);
  }
  if (selectedVariations.priceHints.length > 0) {
    variantSummaryParts.push(`可见价格提示: ${selectedVariations.priceHints.join(' | ')}`);
  }
  if (contextHints.variationTexts.length > 0) {
    variantSummaryParts.push(`上下文变体提示: ${contextHints.variationTexts.slice(0, 8).join(' | ')}`);
  }

  return {
    extractor: 'pricing-main-v2',
    isListingPage,
    currentUrl: window.location.href,
    listingId,
    title: extractTitle(jsonLd.titles),
    shopName: extractShopName(contextHints, buyBoxRoot),
    shopLocationText,
    shipsFromText,
    currency,
    currentPrice: roundMoneyLocal(currentPrice),
    originalPrice: roundMoneyLocal(originalPrice),
    discountPercent,
    shippingAmount: roundMoneyLocal(shippingParsed.amount || 0),
    shippingCurrency,
    shippingText: shippingText || shippingParsed.text || '',
    variantSummary: variantSummaryParts.join('\n'),
    selectedVariations: selectedVariations.selected,
    variantPriceHints: selectedVariations.priceHints,
      diagnostics: {
        jsonLdOffers: jsonLd.offers.length,
        hasCurrencyMeta: Boolean(currencyMeta),
        currentPriceCandidate: currentPriceCandidate.text || '',
        selectedVariationPriceCandidate: selectedVariationPriceCandidate.text || '',
        currentPriceDynamicCandidate: currentPriceDynamicCandidate.text || '',
        currentPriceMetaCandidate: currentPriceMetaCandidate.text || '',
        originalPriceCandidate: originalPriceCandidate.text || '',
        contextPriceCandidate: contextPriceCandidate.text || '',
        explicitDiscountPercent,
        shippingText,
        shopLocationText,
        ownedByLocationText,
      shipsFromText
    }
  };
}

async function extractPricingFromTab(tabId, retries = 3) {
  let lastResult = {
    error: 'Listing data unavailable',
    extractor: 'pricing-main-v1',
    isListingPage: false,
    currentUrl: '',
    listingId: '',
    title: '',
    shopName: '',
    currency: '',
    currentPrice: 0,
    originalPrice: 0,
    shippingAmount: 0,
    shippingCurrency: '',
    shopLocationText: '',
    shipsFromText: '',
    variantSummary: ''
  };

  for (let attempt = 1; attempt <= retries; attempt += 1) {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: etsyPricingExtractionMainWorld
    });
    const result = results?.[0]?.result || null;
    if (result) {
      lastResult = {
        ...lastResult,
        ...result
      };
    }

    if (!lastResult.isListingPage) {
      return lastResult;
    }

    if (lastResult.listingId && (lastResult.currentPrice > 0 || lastResult.title)) {
      return lastResult;
    }

    if (attempt < retries) {
      await sleep(900);
    }
  }

  return lastResult;
}

function etsyOrdersExtractionMainWorld() {
  try {
    const data = window.Etsy?.Context?.data?.initial_data;
    const ordersSearch = data?.orders?.orders_search;
    const rawShop = document.querySelector('a[href*="/shop/"]')?.innerText || '';
    const contextShop = window.Etsy?.Context?.data?.shop_name || '';
    const shopName = rawShop.split('\n').pop().trim() || String(contextShop || '').trim() || 'default';

    if (!ordersSearch || !ordersSearch.orders) {
      return { error: '数据未就绪，请稍后重试', shopName, extractor: 'main-world-v2' };
    }

    const buyerMap = {};
    if (ordersSearch.buyers) {
      ordersSearch.buyers.forEach((buyer) => {
        buyerMap[buyer.buyer_id] = buyer.email;
      });
    }

    const stateMap = {};
    if (ordersSearch.order_states) {
      ordersSearch.order_states.forEach((item) => {
        stateMap[item.order_state_id] = item.name;
      });
    }

    const uniqueOrders = new Map();
    ordersSearch.orders.forEach((order) => {
      const orderId = String(order.order_id || '').trim();
      if (!orderId || uniqueOrders.has(orderId)) return;

      const fulfillment = order.fulfillment || {};
      const address = fulfillment.to_address || {};
      const payment = order.payment?.cost_breakdown?.total_cost || {};
      const transaction = order.transactions?.[0] || {};

      let personalization = transaction.personalization || '';
      const realVariants = [];
      if (Array.isArray(transaction.variations)) {
        transaction.variations.forEach((variation) => {
          const propertyName = String(variation.property || variation.property_name || '').toLowerCase();
          if (
            propertyName.includes('personalization')
            || propertyName.includes('add your')
            || propertyName.includes('custom')
          ) {
            personalization = variation.value || personalization;
          } else {
            realVariants.push(variation.value || '');
          }
        });
      }

      uniqueOrders.set(orderId, {
        orderNumber: orderId,
        orderDate: Number(order.order_date || 0) * 1000,
        shipBy: Number(fulfillment.expected_ship_date || 0) * 1000,
        status: stateMap[order.order_state_id] || 'New',
        buyer: address.name || '',
        email: buyerMap[order.buyer_id] || '',
        phone: address.phone || '',
        shipTo: [address.first_line, address.city, address.state, address.zip, address.country].filter(Boolean).join(', '),
        sku: transaction.product?.product_identifier || '',
        quantity: String(transaction.quantity || '1'),
        amount: Number((Number(payment.value || 0) / 100).toFixed(2)) || 0,
        currency: payment.currency_code || 'USD',
        v1: realVariants[0] || '',
        v2: realVariants[1] || '',
        personalization,
        shop: shopName,
        orderUrl: transaction.listing_id ? `https://www.etsy.com/listing/${transaction.listing_id}` : ''
      });
    });

    return {
      extractor: 'main-world-v2',
      shopName,
      orders: Array.from(uniqueOrders.values())
    };
  } catch (error) {
    return {
      error: error?.message || '订单提取失败',
      shopName: window.Etsy?.Context?.data?.shop_name || 'default',
      extractor: 'main-world-v2'
    };
  }
}

async function extractOrdersFromMainWorld(tabId, retries = 3) {
  let lastResult = {
    error: '订单数据未就绪',
    shopName: '',
    extractor: 'main-world-v2',
    orders: []
  };

  for (let attempt = 1; attempt <= retries; attempt += 1) {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: etsyOrdersExtractionMainWorld
    });
    const result = results?.[0]?.result || null;
    if (result) {
      lastResult = {
        error: result.error || '',
        shopName: result.shopName || '',
        extractor: result.extractor || 'main-world-v2',
        orders: Array.isArray(result.orders) ? result.orders : []
      };
    }

    if (!lastResult.error && Array.isArray(lastResult.orders) && lastResult.orders.length > 0) {
      return lastResult;
    }
    if (!lastResult.error && Array.isArray(lastResult.orders)) {
      return lastResult;
    }

    if (attempt < retries) {
      await sleep(1200);
    }
  }

  return lastResult;
}

function etsyMessagesExtractionMainWorld() {
  function normalizeText(text) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function toAbsoluteUrl(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    try {
      return new URL(raw, window.location.href).href;
    } catch (error) {
      return raw;
    }
  }

  function parseBestSrcFromSrcset(srcset) {
    const entries = String(srcset || '')
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean);
    if (!entries.length) return '';
    const last = entries[entries.length - 1].split(/\s+/)[0];
    return toAbsoluteUrl(last);
  }

  function dedupeBy(items, keyFn) {
    const seen = new Set();
    const result = [];
    (items || []).forEach((item) => {
      const key = keyFn(item);
      if (!key || seen.has(key)) return;
      seen.add(key);
      result.push(item);
    });
    return result;
  }

  function isLikelyMessageImage(img) {
    if (!(img instanceof HTMLImageElement)) return false;
    if (img.closest('[aria-label*="emoji" i], [data-selector*="emoji"]')) return false;
    const marker = `${img.className || ''} ${img.alt || ''} ${img.src || ''} ${img.currentSrc || ''}`.toLowerCase();
    if (marker.includes('avatar') || marker.includes('icon') || marker.includes('emoji') || marker.includes('spinner')) {
      return false;
    }
    const width = Number(img.naturalWidth || img.width || 0);
    const height = Number(img.naturalHeight || img.height || 0);
    if (width > 0 && height > 0 && Math.max(width, height) < 48 && !img.closest('a[href]')) {
      return false;
    }
    return true;
  }

  function extractImagePayloads(scope) {
    const images = [];
    scope.querySelectorAll('img').forEach((img) => {
      if (!isLikelyMessageImage(img)) return;
      const anchorHref = toAbsoluteUrl(img.closest('a[href]')?.getAttribute('href') || img.closest('a[href]')?.href);
      const datasetHref = toAbsoluteUrl(
        img.dataset.fullsize
        || img.dataset.fullSrc
        || img.dataset.zoomSrc
        || img.dataset.src
        || img.dataset.imageUrl
      );
      const pictureSrc = parseBestSrcFromSrcset(img.closest('picture')?.querySelector('source[srcset]')?.getAttribute('srcset') || '');
      const directSrc = toAbsoluteUrl(img.currentSrc || img.src);
      const bestSrc = [anchorHref, datasetHref, pictureSrc, parseBestSrcFromSrcset(img.srcset), directSrc]
        .find((value) => value && !value.startsWith('data:')) || '';
      if (!bestSrc) return;
      images.push({
        src: bestSrc,
        alt: normalizeText(img.alt || '')
      });
    });
    return dedupeBy(images, (item) => item.src);
  }

  function extractLinkPayloads(scope, knownImageUrls = []) {
    const imageUrlSet = new Set((knownImageUrls || []).map((url) => toAbsoluteUrl(url)));
    const links = [];
    scope.querySelectorAll('a[href]').forEach((anchor) => {
      const href = toAbsoluteUrl(anchor.getAttribute('href') || anchor.href);
      if (!href || href.startsWith('javascript:') || imageUrlSet.has(href)) return;
      const text = normalizeText(anchor.textContent || '');
      links.push({ href, text: text || href });
    });
    return dedupeBy(links, (item) => item.href);
  }

  function collectLeafTexts(scope, timestamp = '') {
    const pieces = [];
    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (parent.closest('script, style, button, svg, video, audio, textarea, input, select, option')) {
          return NodeFilter.FILTER_REJECT;
        }
        if (parent.closest('.screen-reader-only, [aria-hidden="true"]')) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    let current = walker.nextNode();
    while (current) {
      const text = normalizeText(current.textContent || '');
      if (
        text
        && text !== timestamp
        && !/^(date:|message:|private note|labels?|mark unread|mark read|trash)$/i.test(text)
      ) {
        pieces.push(text);
      }
      current = walker.nextNode();
    }

    const unique = [];
    pieces.forEach((text) => {
      if (unique.some((existing) => existing === text || existing.includes(text) || text.includes(existing))) return;
      unique.push(text);
    });
    return unique;
  }

  function formatMessageForDrafting(message) {
    const parts = [];
    const text = normalizeText(message?.text || '');
    if (text) parts.push(text);
    const linkUrls = Array.isArray(message?.links)
      ? message.links.map((item) => toAbsoluteUrl(item?.href || item?.text || '')).filter(Boolean)
      : [];
    const imageUrls = Array.isArray(message?.images)
      ? message.images.map((item) => toAbsoluteUrl(item?.src || '')).filter(Boolean)
      : [];
    if (linkUrls.length) parts.push(`Links: ${linkUrls.join(' | ')}`);
    if (imageUrls.length) parts.push(`Images: ${imageUrls.join(' | ')}`);
    return parts.join('\n').trim();
  }

  function getPendingBuyerMessages(messages) {
    const list = Array.isArray(messages) ? messages : [];
    const pending = [];
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const message = list[i];
      if (!message) continue;
      const hasContent = Boolean(
        normalizeText(message.text || '')
        || (Array.isArray(message.links) && message.links.length > 0)
        || (Array.isArray(message.images) && message.images.length > 0)
      );
      if (!hasContent) continue;
      if (message.direction === 'out') break;
      if (message.direction === 'in') pending.push(message);
    }
    return pending.reverse();
  }

  function getPendingBuyerText(messages) {
    const pending = getPendingBuyerMessages(messages);
    if (pending.length > 0) {
      return pending.map((message) => formatMessageForDrafting(message)).filter(Boolean).join('\n\n');
    }
    const latestBuyer = [...(messages || [])].reverse().find((message) => {
      if (message?.direction !== 'in') return false;
      return Boolean(
        normalizeText(message.text || '')
        || (Array.isArray(message.links) && message.links.length > 0)
        || (Array.isArray(message.images) && message.images.length > 0)
      );
    });
    return latestBuyer ? formatMessageForDrafting(latestBuyer) : '';
  }

  function extractBuyerName() {
    const selectors = [
      '.scrolling-message-list p.wt-text-title',
      '.scrolling-message-list h1',
      '.scrolling-message-list h2',
      '[data-test-id="conversation-header"] h1',
      '[data-test-id="conversation-header"] h2',
      'aside p.wt-text-title',
      'aside h2'
    ];
    for (const selector of selectors) {
      const text = normalizeText(document.querySelector(selector)?.textContent || '');
      if (text && !/^(messages|private note|labels?)$/i.test(text)) return text;
    }
    return '';
  }

  function extractShopId() {
    const contextShop = String(window.Etsy?.Context?.data?.shop_name || '').trim();
    if (contextShop) return contextShop;

    const shopLinkMatch = Array.from(document.querySelectorAll('a[href*="/shop/"]'))
      .map((link) => {
        const href = String(link.getAttribute('href') || '');
        const match = href.match(/\/shop\/([^/?#]+)/i);
        return match ? decodeURIComponent(match[1]) : '';
      })
      .find(Boolean);
    if (shopLinkMatch) return shopLinkMatch;

    const salesChannelNode = Array.from(document.querySelectorAll('nav, aside, [role="navigation"], [data-ui="left-nav"]'))
      .flatMap((root) => Array.from(root.querySelectorAll('a, button, div, span')))
      .map((node) => normalizeText(node.textContent || ''))
      .find((text) => text && !/^(sales channels|etsy|dashboard|messages|orders|listings|search|stats|marketing|settings|help)$/i.test(text) && text.length <= 48);
    if (salesChannelNode) return salesChannelNode;

    return '';
  }

  const root = document.querySelector('.scrolling-message-list')
    || document.querySelector('[data-message-list]')
    || document.querySelector('[data-test-id="messages-list"]');
  const isMessagesPage = /\/messages(\/|$|\?)/.test(window.location.pathname);
  const convoIdMatch = window.location.href.match(/\/messages\/(\d+)/);
  const convoId = convoIdMatch ? convoIdMatch[1] : '';
  const shopId = extractShopId();

  if (!root) {
    return {
      ok: true,
      contextSource: 'main-world',
      extensionVersion: EXTENSION_VERSION,
      buildFingerprint: BUILD_FINGERPRINT,
      extractor: 'messages-main-v1',
      isMessagesPage,
      convoId,
      shopId,
      buyerName: extractBuyerName(),
      currentUrl: window.location.href,
      messageCount: 0,
      pendingBuyerCount: 0,
      pendingBuyerText: '',
      hasAttachments: false,
      lastDirection: '',
      messages: []
    };
  }

  const messages = Array.from(root.children).map((child) => {
    if (!(child instanceof HTMLElement)) return null;
    const directionNode = child.matches('.wt-justify-content-flex-end, .wt-justify-content-flex-start')
      ? child
      : child.querySelector('.wt-justify-content-flex-end, .wt-justify-content-flex-start, [class*="justify-content-flex-end"], [class*="justify-content-flex-start"]');
    const directionClass = `${directionNode?.className || ''}`.toLowerCase();
    const direction = directionClass.includes('flex-end') ? 'out' : (directionClass.includes('flex-start') ? 'in' : '');

    const timestamp = normalizeText(
      child.querySelector('time')?.textContent
      || child.querySelector('.wt-text-caption.wt-sem-text-secondary')?.textContent
      || child.querySelector('.timestamp-color')?.textContent
      || ''
    );

    const textScopes = child.querySelectorAll('.wt-rounded, [data-message-text], [data-test-id="message-body"], p');
    const segments = [];
    textScopes.forEach((scope) => {
      collectLeafTexts(scope, timestamp).forEach((text) => segments.push(text));
    });
    if (!segments.length) {
      collectLeafTexts(directionNode || child, timestamp).forEach((text) => segments.push(text));
    }
    const uniqueSegments = [];
    segments.forEach((text) => {
      if (uniqueSegments.some((existing) => existing === text || existing.includes(text) || text.includes(existing))) return;
      uniqueSegments.push(text);
    });

    const images = extractImagePayloads(child);
    const links = extractLinkPayloads(child, images.map((item) => item.src));
    const text = uniqueSegments.join('\n\n').trim();
    if (!direction && !text && !images.length && !links.length) return null;

    return {
      direction: direction || 'in',
      text,
      links: links.length ? links : undefined,
      images: images.length ? images : undefined,
      timestamp
    };
  }).filter(Boolean);

  const pendingBuyerText = getPendingBuyerText(messages);
  return {
    ok: true,
    contextSource: 'main-world',
    extensionVersion: EXTENSION_VERSION,
    buildFingerprint: BUILD_FINGERPRINT,
    extractor: 'messages-main-v1',
    isMessagesPage,
    convoId,
    shopId,
    buyerName: extractBuyerName(),
    currentUrl: window.location.href,
    messageCount: messages.length,
    pendingBuyerCount: getPendingBuyerMessages(messages).length,
    pendingBuyerText,
    hasAttachments: messages.some((message) => (message.links && message.links.length > 0) || (message.images && message.images.length > 0)),
    lastDirection: messages.length ? messages[messages.length - 1].direction : '',
    messages
  };
}

async function extractMessagesFromMainWorld(tabId, retries = 2) {
  let lastResult = {
    ok: false,
    contextSource: 'main-world',
    extensionVersion: EXTENSION_VERSION,
    buildFingerprint: BUILD_FINGERPRINT,
    extractor: 'messages-main-v1',
    isMessagesPage: false,
    convoId: '',
    shopId: '',
    buyerName: '',
    currentUrl: '',
    messageCount: 0,
    pendingBuyerCount: 0,
    pendingBuyerText: '',
    hasAttachments: false,
    lastDirection: '',
    messages: []
  };

  for (let attempt = 1; attempt <= retries; attempt += 1) {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: etsyMessagesExtractionMainWorld
    });
    const result = results?.[0]?.result || null;
    if (result) {
      lastResult = {
        ...lastResult,
        ...result,
        messages: Array.isArray(result.messages) ? result.messages : []
      };
    }
    if (!lastResult.isMessagesPage) return lastResult;
    if (lastResult.convoId || lastResult.messageCount > 0 || lastResult.buyerName) return lastResult;
    if (attempt < retries) {
      await sleep(500);
    }
  }

  return lastResult;
}

function isReceiverMissingError(error) {
  const message = String(error?.message || error || '');
  return message.includes('Receiving end does not exist')
    || message.includes('Could not establish connection')
    || message.includes('The message port closed');
}

function getInjectionFileForTab(tab) {
  const url = tab?.url || '';
  if (isMessagesUrl(url)) {
    return 'content.js';
  }
  if (isOrdersUrl(url)) {
    return 'orders-content.js';
  }
  if (isMarketResearchUrl(url)) {
    return 'market-research-content.js';
  }
  if (/^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?your\//i.test(url) && !isMessagesUrl(url) && !isOrdersUrl(url)) {
    return 'shop-analytics-content.js';
  }
  return null;
}

async function ensureTabReceiver(tab) {
  const file = getInjectionFileForTab(tab);
  if (!file) return false;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: [file]
  });
  await new Promise((resolve) => setTimeout(resolve, 180));
  return true;
}

async function sendToActiveTab(message) {
  const tab = await getActiveTab();
  if (!tab?.id) throw new Error('No active tab.');
  state.currentTabId = tab.id;
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch (error) {
    if (!isReceiverMissingError(error)) throw error;
    const injected = await ensureTabReceiver(tab);
    if (!injected) throw error;
    return await chrome.tabs.sendMessage(tab.id, message);
  }
}

function resetConversationMeta() {
  state.convoId = '';
  state.shopId = '';
  state.messageCount = 0;
  state.pendingBuyerCount = 0;
  state.hasMessageAttachments = false;
  state.buyerName = '';
  state.currentUrl = '';
  state.lastDirection = '';
  state.latestBuyerMessage = '';
  state.latestBuyerMessageZh = '';
  state.buyerIntentZh = '';
  state.replyFocusZh = '';
  state.currentPendingBuyerText = '';
  state.currentThreadMessages = [];
  state.baseReply = '';
  state.baseReplyZh = '';
  state.lastSellerIntent = '';
  setText('meta-shop', '店铺 -');
  setText('meta-convo', '对话 -');
  setText('meta-buyer', '买家 -');
  setText('meta-msg-total', '记录 -');
  setText('meta-msg-pending', '待回复 -');
  setText('meta-url', '-');
  document.getElementById('buyer-message-en').value = '';
  document.getElementById('buyer-message-zh').value = '';
  document.getElementById('rewrite-input').value = '';
  clearBaseDraft();
  clearReplyDraft();
  setText('buyer-intent', '同步后这里会解释客户真正想表达什么。');
  setText('reply-focus', '同步后这里会提示回复应该先解决什么。');
  setDraftStatus('');
}

function renderConversationMeta() {
  setText('meta-shop', state.shopId ? `店铺 ${state.shopId}` : '店铺 -');
  setText('meta-convo', state.convoId ? `对话 #${state.convoId}` : '对话 -');
  setText('meta-buyer', state.buyerName ? `买家 ${state.buyerName}` : '买家 -');
  setText('meta-msg-total', state.messageCount ? `已读取 ${state.messageCount} 条` : '记录 -');
  setText(
    'meta-msg-pending',
    state.pendingBuyerCount >= 0 && state.convoId
      ? `待回复 ${state.pendingBuyerCount} 条${state.hasMessageAttachments ? ' | 含图片/链接' : ''}`
      : '待回复 -'
  );
  setText('meta-url', state.currentUrl);
}

function renderBuyerAnalysis() {
  document.getElementById('buyer-message-en').value = state.latestBuyerMessage || '';
  document.getElementById('buyer-message-zh').value = state.latestBuyerMessageZh || '';
  setText('buyer-intent', state.buyerIntentZh || '还没有分析结果。');
  setText('reply-focus', state.replyFocusZh || '还没有建议重点。');
}

function hydrateBuyerMessageFromContext(options = {}) {
  const { force = false } = options;
  const nextText = String(state.currentPendingBuyerText || '').trim();
  if (!nextText) return false;
  if (!force && String(state.latestBuyerMessage || '').trim()) return false;
  state.latestBuyerMessage = nextText;
  renderBuyerAnalysis();
  return true;
}

function setResearchStatus(text = '', kind = 'neutral') {
  setStatus('research-status', text || '还没有研究页上下文。', kind);
  setStatus(
    'research-status-inline',
    text || '打开 Etsy 店铺统计页或搜索结果页后，插件会自动识别当前页面并读取可用研究信号。',
    kind
  );
}

function updateResearchModeUi() {
  document.querySelectorAll('[data-research-mode]').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.researchMode === state.researchMode);
  });
}

function setResearchMode(mode = 'shop') {
  state.researchMode = mode === 'market' ? 'market' : 'shop';
  updateResearchModeUi();
  updatePrimarySyncButton();
}

function resetResearchState() {
  state.researchPageReady = false;
  state.researchPageType = '';
  state.researchSubPageType = '';
  state.researchCurrentUrl = '';
  state.researchPageTitle = '';
  state.researchKeyword = '';
  state.researchShopId = '';
  state.researchShopName = '';
  state.researchDateRangeLabel = '';
  state.researchSampleCount = 0;
  state.researchSummaryText = '';
  state.researchRawSignals = '';
  state.researchExtractor = '';
  state.researchDiagnostics = {};
  setText('research-meta-page', '页面 -');
  setText('research-meta-focus', '对象 -');
  setText('research-meta-samples', '样本 -');
  setText('research-meta-range', '范围 -');
  setText('research-guidance', '先采第 1 页、第 2 页、第 3 页，再去后台排除无关产品并生成结论。');
  setResearchCollectionStatus('');
  setText('meta-url', '-');
  setInputValue('research-summary', '');
  setInputValue('research-raw-signals', '');
  setResearchStatus('');
}

function renderResearchMeta() {
  const pageLabel = state.researchPageType === 'shop_analytics'
    ? `店铺页 ${state.researchSubPageType || 'overview'}`
    : (state.researchPageType === 'market_search' ? '搜索页' : '页面 -');
  const focusLabel = state.researchPageType === 'shop_analytics'
    ? (state.researchShopName ? `店铺 ${state.researchShopName}` : '店铺 -')
    : (state.researchKeyword ? `关键词 ${state.researchKeyword}` : '关键词 -');
  const sampleLabel = state.researchPageType === 'market_search'
    ? (state.researchSampleCount ? `样本 ${state.researchSampleCount} 个` : '样本 -')
    : (state.researchPageReady ? '样本 当前页快照' : '样本 -');
  const rangeLabel = state.researchDateRangeLabel
    ? `范围 ${state.researchDateRangeLabel}`
    : (state.researchPageTitle ? state.researchPageTitle : '范围 -');

  setText('research-meta-page', pageLabel);
  setText('research-meta-focus', focusLabel);
  setText('research-meta-samples', sampleLabel);
  setText('research-meta-range', rangeLabel);
  setText('meta-url', state.researchCurrentUrl || state.currentUrl || '-');
}

function renderResearchContext(info = null) {
  const guidance = state.researchPageType === 'shop_analytics'
    ? '继续打开 listing / 流量来源 / 广告页，后面可以把多个当前页快照合并成一次完整诊断。'
    : (state.researchPageType === 'market_search'
      ? '先继续采第 2 页、第 3 页，再到后台排除无关产品；保留下来的样本才是真正的市场判断基础。'
      : '先采集页面，再去后台做筛选、汇总和结论。');
  setInputValue('research-summary', state.researchSummaryText || '');
  setInputValue('research-raw-signals', state.researchRawSignals || '');
  setText('research-guidance', guidance);
  renderResearchMeta();
  if (!info) return;
}

function getResearchSnapshotPayload(info = null) {
  if (!info || info.pageType !== 'market_search') return null;
  return {
    keyword: info.keyword || state.researchKeyword || '',
    pageUrl: info.pageUrl || state.researchCurrentUrl || state.currentUrl || '',
    sortModeHint: info.sortModeHint || '',
    resultCountHint: info.resultCountHint || '',
    cards: Array.isArray(info.cards) ? info.cards : []
  };
}

async function persistMarketResearchSnapshot(info = null, options = {}) {
  const { quiet = true } = options;
  const payload = getResearchSnapshotPayload(info);
  if (!payload?.keyword || !payload.pageUrl || !Array.isArray(payload.cards) || !payload.cards.length) {
    return null;
  }

  if (!quiet) {
    setResearchCollectionStatus('正在把当前搜索页样本写入后台研究库...');
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/research/market/search-snapshot`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || !data?.ok) {
      throw new Error(data?.error || 'market research snapshot unavailable');
    }

    const summary = data.summary || {};
    setResearchCollectionStatus(
      summary.sampleCount > 0
        ? `当前关键词已沉淀 ${summary.sampleCount} 个样本 / ${summary.listingCount || 0} 个 listing / ${summary.pageCount || 0} 个搜索页。去后台排除无关产品后再看结论。`
        : '当前搜索页样本已写入后台研究库。'
    );
    return data;
  } catch (e) {
    const message = String(e?.message || e || 'unknown error');
    setResearchCollectionStatus(`后台研究库入库失败：${message}`);
    return null;
  }
}

function setOrdersStatus(text = '', kind = 'neutral') {
  setStatus('orders-status', text || '打开 Etsy Sold Orders 页面后，侧边栏会自动读取当前页并比对是否有新单。', kind);
  if (kind === 'err') setOrdersLogOpen(true);
}

function setOrdersConfigStatus(text = '', kind = 'neutral') {
  setStatus('orders-config-status', text || '识别到当前店铺后，可以为这个店铺保存飞书表配置。', kind);
  if (kind === 'err') setOrdersConfigPanelOpen(true);
}

function resetOrdersState() {
  state.orderPageReady = false;
  state.orderCount = 0;
  state.orderShopId = '';
  state.orderDisplayName = '';
  state.orderCurrentUrl = '';
  state.orderVisibleOrderIds = [];
  state.orderKnownOrderIds = [];
  state.orderNewOrderIds = [];
  state.orderCompareState = 'idle';
  state.orderStats = null;
  state.orderFeishuLink = '';
  state.orderConfigReady = false;
  state.orderConfigSource = '';
  state.orderConfigWarnings = [];
  state.orderConfigEditorVisible = false;
  renderOrdersMeta();
  renderOrderSyncResult(null);
  renderOrderStats(null);
  renderOrderSyncButton();
  renderOrderConfig();
}

function renderOrdersMeta() {
  setText('orders-meta-shop', state.orderShopId ? `店铺 ${state.orderShopId}` : '店铺 -');
  setText('orders-meta-page', state.orderPageReady ? '订单页已就绪' : '订单页 -');
  const total = Number(state.orderCount || 0);
  const newCount = Number(state.orderNewOrderIds.length || 0);
  const knownCount = total > 0 ? Math.max(total - newCount, 0) : 0;

  setText('orders-meta-total', total ? `当前页 ${total} 单` : '当前页 -');

  if (state.orderCompareState === 'checking') {
    setText('orders-meta-new', '新订单 比对中');
    setText('orders-meta-known', '已入库 比对中');
    return;
  }

  setText('orders-meta-new', total ? `新订单 ${newCount} 单` : '新订单 -');
  setText('orders-meta-known', total ? `已入库 ${knownCount} 单` : '已入库 -');
}

function renderOrderConfig() {
  const linkInput = document.getElementById('orders-feishu-link');
  const editor = document.getElementById('orders-config-editor');
  const editBtn = document.getElementById('edit-orders-config');
  const openBtn = document.getElementById('open-orders-link');
  if (linkInput) linkInput.value = state.orderFeishuLink || '';

  const showEditor = !!state.orderShopId && (!state.orderConfigReady || state.orderConfigEditorVisible);
  if (editor) editor.classList.toggle('is-hidden', !showEditor);
  if (editBtn) {
    editBtn.classList.toggle('is-hidden', !(state.orderShopId && state.orderConfigReady && !showEditor));
  }
  if (openBtn) {
    openBtn.classList.toggle('is-hidden', !state.orderFeishuLink);
  }

  const meta = document.getElementById('orders-config-meta');
  if (!meta) return;

  if (!state.orderShopId) {
    meta.textContent = '每个 Etsy 店铺独立保存，不会和别的店铺共用。';
    setOrdersConfigStatus('识别到当前店铺后，可以为这个店铺保存飞书表配置。', 'neutral');
    return;
  }

  const warnings = (state.orderConfigWarnings || []).filter(Boolean);
  const sourceLabel = state.orderConfigSource === 'shop'
    ? '按店铺配置'
    : (state.orderConfigSource === 'global' ? '回退到全局配置' : '未配置');

  meta.textContent = `当前店铺：${state.orderDisplayName || state.orderShopId} | 来源：${sourceLabel}`;

  if (state.orderConfigReady) {
    setOrdersConfigStatus('当前店铺的飞书表格已就绪。需要同步时，会写入这个表格。', 'ok');
    return;
  }

  if (warnings.length > 0) {
    setOrdersConfigStatus(warnings[0], 'neutral');
    return;
  }

  setOrdersConfigStatus('当前店铺还没有完整的飞书配置。手动同步时，会先继续进入后台总表。', 'neutral');
}

function renderOrderSyncResult(result = null) {
  state.lastOrderSync = result || null;
  document.getElementById('orders-sync-total').textContent = result?.total ?? '-';
  document.getElementById('orders-sync-added').textContent = result?.added ?? '-';
  document.getElementById('orders-sync-updated').textContent = result?.updated ?? '-';
  document.getElementById('orders-sync-time').textContent = result?.syncedAt
    ? new Date(result.syncedAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : '-';

  const detail = result
    ? `最近一次同步：抓取 ${result.total ?? 0} 单，新增 ${result.added ?? 0} 单，更新 ${result.updated ?? 0} 单。`
    : '还没有订单同步记录。';
  document.getElementById('orders-last-result').textContent = detail;
}

function renderOrderStats(stats = null) {
  state.orderStats = stats;
  document.getElementById('orders-stat-total').textContent = stats?.total ?? '-';
  document.getElementById('orders-stat-pending').textContent = stats?.pending ?? '-';
  document.getElementById('orders-stat-shipped').textContent = stats?.shipped ?? '-';
  document.getElementById('orders-stat-completed').textContent = stats?.completed ?? '-';
  const summaryEl = document.getElementById('orders-backend-summary');
  if (!summaryEl) return;

  if (!stats) {
    summaryEl.textContent = '识别到当前店铺后，这里会显示当前店铺自己的后台统计。';
    return;
  }

  const todayTotal = Number(stats.today?.total || 0);
  const lastSyncedAt = Array.isArray(stats.byShop) && stats.byShop[0]?.lastSyncedAt
    ? new Date(stats.byShop[0].lastSyncedAt).toLocaleString('zh-CN', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
    : '';
  summaryEl.textContent = lastSyncedAt
    ? `当前店铺累计 ${stats.total ?? 0} 单，今日 ${todayTotal} 单，最近同步 ${lastSyncedAt}。`
    : `当前店铺累计 ${stats.total ?? 0} 单，今日 ${todayTotal} 单。`;
}

function setPricingStatus(text = '', kind = 'neutral') {
  const nextText = text || '打开 Etsy listing 页面后，插件会自动读取当前页面的定价上下文。';
  setStatus('pricing-status-inline', nextText, kind);
  setStatus('pricing-status', nextText, kind);
  if (kind === 'err') setPricingLogOpen(true);
}

function setPricingMetaFeedback(pageText = '', listingText = '', currencyText = '') {
  if (pageText) setText('pricing-meta-page', pageText);
  if (listingText) setText('pricing-meta-listing', listingText);
  if (currencyText) setText('pricing-meta-currency', currencyText);
}

function setPricingConfigStatus(text = '', kind = 'neutral') {
  setStatus('pricing-config-status', text || '会优先读取当前插件已识别的店铺上下文。若没识别到，可手动填写后保存。', kind);
}

function setPricingCollectionStatus(text = '') {
  const el = document.getElementById('pricing-collection-status');
  if (!el) return;
  el.textContent = text || '读取到的竞品样本会自动沉淀到后台定价库，供后续筛选和分析。';
}

function setResearchCollectionStatus(text = '') {
  const el = document.getElementById('research-collection-status');
  if (!el) return;
  el.textContent = text || '插件负责采集当前页，筛选无关样本和生成结论要去后台研究库完成。';
}

function buildPricingPersistKey(payload = null) {
  const baseKey = buildPricingAutoKey(payload || {});
  const reverse = state.pricingReverseResult
    ? `${roundMoney(state.pricingReverseResult.marginPercent || 0)}::${roundMoney(state.pricingReverseResult.profitUsd || 0)}::${roundMoney(state.pricingReverseResult.totalFeeRatePercent || 0)}`
    : 'no-reverse';
  const forward = state.pricingForwardResult
    ? `${roundMoney(state.pricingForwardResult.targetMarginPercent || 0)}::${roundMoney(state.pricingForwardResult.listingPrice || 0)}::${roundMoney(state.pricingForwardResult.profitUsd || 0)}`
    : 'no-forward';
  const sellerShopId = getInputValue('pricing-seller-shop-id') || state.pricingSellerShopId || 'default';
  return baseKey ? `${baseKey}::${sellerShopId}::${reverse}::${forward}` : '';
}

function getPricingSnapshotPayload() {
  const payload = getPricingPagePayload();
  return {
    ...payload,
    sellerShopId: getInputValue('pricing-seller-shop-id') || state.pricingSellerShopId || '',
    currentUrl: state.pricingCurrentUrl || payload.currentUrl || '',
    listingUrl: state.pricingCurrentUrl || payload.currentUrl || '',
    extractor: state.pricingExtractor || '',
    diagnostics: state.pricingDiagnostics || {},
    source: 'extension-sidepanel',
    reverseResult: state.pricingReverseResult || null,
    forwardResult: state.pricingForwardResult || null
  };
}

async function persistPricingSnapshot(options = {}) {
  const { force = false, quiet = true } = options;
  const payload = getPricingSnapshotPayload();
  const persistKey = buildPricingPersistKey(payload);
  if (!payload.currentPrice || !payload.currency || !persistKey) return null;
  if (!force && persistKey === state.lastPricingPersistKey) return null;

  if (!quiet) {
    setPricingCollectionStatus('正在把当前竞品样本写入后台...');
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/pricing/snapshots`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || !data?.snapshot) {
      throw new Error(data?.error || 'pricing snapshot unavailable');
    }

    state.lastPricingPersistKey = persistKey;
    state.pricingSnapshotId = data.snapshot.id || null;
    state.pricingCollectionSummary = data.summary || null;
    const sampleCount = Number(data.summary?.sampleCount || 0);
    const listingCount = Number(data.summary?.listingCount || 0);
    setPricingCollectionStatus(
      sampleCount > 0
        ? `已沉淀 ${sampleCount} 个样本 / ${listingCount} 个 listing。当前读取到的变体和测算结果会自动更新到后台定价库。`
        : '当前样本已写入后台定价库。'
    );
    return data.snapshot;
  } catch (e) {
    const message = String(e?.message || e || 'unknown error');
    setPricingCollectionStatus(
      /404|pricing snapshot unavailable/i.test(message)
        ? '当前 API 还没有开启后台样本库接口。切回云端 API 后，样本会自动沉淀到后台。'
        : `后台样本入库失败：${message}`
    );
    if (!quiet) setPricingLogOpen(true);
    return null;
  }
}

function getPricingProfileByCode(code = '') {
  const normalizedCode = String(code || '').trim().toUpperCase();
  return (state.pricingFeeProfiles || []).find((profile) => {
    return String(profile.countryCode || '').trim().toUpperCase() === normalizedCode
      || String(profile.profileCode || '').trim().toUpperCase() === normalizedCode;
  }) || null;
}

function profileHasMarketSplit(profile = null) {
  if (!profile) return false;
  const domestic = Number(profile.paymentRateDomestic);
  const international = Number(profile.paymentRateInternational);
  if (!Number.isFinite(domestic) || !Number.isFinite(international)) return false;
  return Math.abs(domestic - international) > 0.00001;
}

function buildInheritedShippingText(source = null) {
  if (!source) {
    return state.pricingShippingCurrency || state.pricingShippingAmount
      ? formatMoneyValue(state.pricingShippingAmount, state.pricingShippingCurrency || state.pricingCurrency)
      : '';
  }

  const originalAmount = normalizeNumber(source.shippingChargeOriginalAmount, state.pricingShippingAmount || 0);
  const originalCurrency = normalizeCurrency(source.shippingChargeOriginalCurrency || state.pricingShippingCurrency || state.pricingCurrency || '');
  const convertedAmount = normalizeNumber(source.shippingChargeAmount, originalAmount);
  const convertedCurrency = normalizeCurrency(source.shippingChargeCurrency || source.currency || originalCurrency);
  const originalText = formatMoneyValue(originalAmount, originalCurrency);
  const convertedText = formatMoneyValue(convertedAmount, convertedCurrency);

  if (!originalText || originalText === '-') return convertedText;
  if (!convertedText || convertedText === '-' || (originalCurrency === convertedCurrency && roundMoney(originalAmount) === roundMoney(convertedAmount))) {
    return originalText;
  }
  return `${originalText} -> ${convertedText}`;
}

function getCurrentPricingDiscountPercent() {
  if (state.pricingOriginalPrice > state.pricingCurrentPrice && state.pricingCurrentPrice > 0) {
    return roundMoney((1 - (state.pricingCurrentPrice / state.pricingOriginalPrice)) * 100);
  }
  return 0;
}

function syncForwardTargetInputs(options = {}) {
  const { forceTargets = false } = options;
  const hasPricingBase = !!state.pricingReverseResult || !!state.pricingPageReady;
  if (!hasPricingBase) {
    setInputValue('pricing-inherited-discount', '');
    setInputValue('pricing-inherited-shipping', '');
    if (forceTargets) {
      setInputValue('pricing-target-discount', '');
      setInputValue('pricing-target-shipping-amount', '');
      setInputValue('pricing-target-shipping-currency', '');
    }
    return;
  }

  const baselineDiscount = normalizeNumber(state.pricingReverseResult?.discountPercent, getCurrentPricingDiscountPercent());
  const baselineShippingAmount = normalizeNumber(state.pricingReverseResult?.shippingChargeOriginalAmount, state.pricingShippingAmount || 0);
  const baselineShippingCurrency = normalizeCurrency(
    state.pricingReverseResult?.shippingChargeOriginalCurrency
    || state.pricingShippingCurrency
    || state.pricingCurrency
    || state.pricingSellerCurrency
    || ''
  );

  setInputValue('pricing-inherited-discount', formatPercent(baselineDiscount));
  setInputValue('pricing-inherited-shipping', buildInheritedShippingText(state.pricingReverseResult || null));

  if (forceTargets || !getInputValue('pricing-target-discount')) {
    setInputValue('pricing-target-discount', roundMoney(baselineDiscount));
  }
  if (forceTargets || !getInputValue('pricing-target-shipping-amount')) {
    setInputValue('pricing-target-shipping-amount', roundMoney(baselineShippingAmount));
  }
  if (forceTargets || !getInputValue('pricing-target-shipping-currency')) {
    setInputValue('pricing-target-shipping-currency', baselineShippingCurrency || state.pricingSellerCurrency || state.pricingCurrency || '');
  }
}

function renderPricingTargetMarketField() {
  const wrapper = document.getElementById('pricing-target-market-field');
  const note = document.getElementById('pricing-target-market-note');
  const competitorCode = (getInputValue('pricing-competitor-country') || state.pricingDetectedCountryCode || '').toUpperCase();
  const sellerCode = (getInputValue('pricing-seller-country') || state.pricingSellerCountryCode || '').toUpperCase();
  const competitorProfile = getPricingProfileByCode(competitorCode);
  const sellerProfile = getPricingProfileByCode(sellerCode);
  const effectiveProfiles = [];

  if (profileHasMarketSplit(competitorProfile)) {
    effectiveProfiles.push(`竞对 ${competitorProfile.displayName || competitorCode}`);
  }
  if (profileHasMarketSplit(sellerProfile)) {
    const label = `我的店铺 ${sellerProfile.displayName || sellerCode}`;
    if (!effectiveProfiles.includes(label)) effectiveProfiles.push(label);
  }

  if (!wrapper) return;

  if (!effectiveProfiles.length) {
    wrapper.classList.add('is-hidden');
    setInputValue('pricing-target-market', 'international');
    if (note) note.textContent = '当前所选国家没有国内 / 国际市场费率差异，已按统一费率处理。';
    return;
  }

  wrapper.classList.remove('is-hidden');
  if (note) {
    note.textContent = `当前“买家市场”只对 ${effectiveProfiles.join('、')} 生效。`;
  }
}

function guessPricingCountryCode(text = '') {
  const raw = String(text || '').trim().toLowerCase();
  if (!raw) return '';
  const tokenized = raw
    .replace(/[^a-z0-9]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
  const directCode = raw.toUpperCase();
  const directProfile = getPricingProfileByCode(directCode);
  if (directProfile) return String(directProfile.countryCode || directProfile.profileCode || '').trim().toUpperCase();

  for (const profile of state.pricingFeeProfiles || []) {
    const aliases = [
      profile.countryCode,
      profile.profileCode,
      profile.displayName,
      ...(Array.isArray(profile.aliases) ? profile.aliases : [])
    ]
      .map((value) => String(value || '').trim().toLowerCase())
      .filter(Boolean);
    if (aliases.some((alias) => {
      if (alias.length <= 3) {
        return tokenized.includes(alias);
      }
      return raw.includes(alias);
    })) {
      return String(profile.countryCode || profile.profileCode || '').trim().toUpperCase();
    }
  }
  return '';
}

function populatePricingCountrySelects() {
  const selects = ['pricing-competitor-country', 'pricing-seller-country'];
  const options = (state.pricingFeeProfiles || []).map((profile) => ({
    value: String(profile.countryCode || profile.profileCode || '').trim().toUpperCase(),
    label: `${profile.displayName || profile.countryCode} (${profile.settlementCurrency || ''})`
  }));

  selects.forEach((selectId) => {
    const select = document.getElementById(selectId);
    if (!select) return;
    const currentValue = select.value;
    select.innerHTML = '<option value="">自动识别 / 请选择</option>';
    options.forEach((option) => {
      const node = document.createElement('option');
      node.value = option.value;
      node.textContent = option.label;
      select.appendChild(node);
    });
    if (currentValue) {
      select.value = currentValue;
    }
  });
  renderPricingTargetMarketField();
}

function syncPricingSellerCurrency() {
  const selectedCountry = getInputValue('pricing-seller-country') || state.pricingSellerCountryCode;
  const profile = getPricingProfileByCode(selectedCountry);
  const currency = profile?.settlementCurrency || '';
  state.pricingSellerCountryCode = selectedCountry ? selectedCountry.toUpperCase() : '';
  state.pricingSellerCurrency = currency;
  setInputValue('pricing-seller-currency', currency);
  renderPricingTargetMarketField();
}

function buildReverseBreakdownText(result) {
  if (!result) return '还没有逆向定价详情。';
  const fee = result.feeBreakdown || {};
  return [
    formatMoneyLine('当前成交价', result.currentPriceAmount, result.originalCurrency || result.currency),
    formatMoneyLine('原价', result.originalPriceAmount, result.originalCurrency || result.currency),
    `折扣: ${formatPercent(result.discountPercent)}`,
    formatMoneyLine('运费收入', result.shippingChargeOriginalAmount, result.shippingChargeOriginalCurrency || result.originalCurrency || result.currency),
    formatMoneyLine('运费收入(结算币种)', result.shippingChargeAmount, result.shippingChargeCurrency || result.currency),
    '',
    `换算币种: ${result.currency}`,
    formatMoneyLine('折后商品收入', result.discountedPriceAmount, result.currency),
    formatMoneyLine('总收入', result.revenueAmount, result.currency),
    formatMoneyLine('产品成本', result.costAmount, result.currency),
    formatMoneyLine('国际运费成本', result.shipCostAmount, result.currency),
    formatMoneyLine('总成本', result.totalCostAmount, result.currency),
    '',
    `交易手续费: ${formatPercent(fee.transactionRatePercent)} / ${formatMoneyValue(fee.transactionFeeAmount, result.currency)}`,
    `支付处理费: ${formatPercent(fee.paymentRatePercent)} / ${formatMoneyValue(fee.paymentFeeAmount, result.currency)}`,
    `广告费: ${formatPercent(result.adRatePercent)} / ${formatMoneyValue(fee.adFeeAmount, result.currency)}`,
    `监管费: ${formatPercent(fee.regulatoryFeeRatePercent)} / ${formatMoneyValue(fee.regulatoryFeeAmount, result.currency)}`,
    `费率税/VAT: ${formatPercent(fee.vatRatePercent)} / ${formatMoneyValue(fee.vatFeeAmount, result.currency)}`,
    formatMoneyLine('上架费', fee.listingFee, result.currency),
    formatMoneyLine('支付固定费', fee.paymentFixedFee, result.currency),
    formatMoneyLine('固定费用合计', result.fixedFeeAmount, result.currency),
    '',
    `总费率: ${formatPercent(result.totalFeeRatePercent)}`,
    formatMoneyLine('毛利额', result.profitAmount, result.currency),
    `毛利率: ${formatPercent(result.marginPercent)}`
  ].join('\n');
}

function buildForwardBreakdownText(result) {
  if (!result) return '还没有正向定价详情。';
  const fee = result.feeBreakdown || {};
  return [
    `目标国家: ${result.countryCode}`,
    `目标毛利率: ${formatPercent(result.targetMarginPercent)}`,
    `折扣: ${formatPercent(result.discountPercent)}`,
    formatMoneyLine('目标运费', result.shippingChargeOriginalAmount, result.shippingChargeOriginalCurrency || result.originalCurrency || result.currency),
    formatMoneyLine('目标运费(结算币种)', result.shippingChargeAmount, result.currency),
    '',
    `计算币种: ${result.currency}`,
    formatMoneyLine('建议标价', result.listingPrice, result.currency),
    formatMoneyLine('折后售价', result.discountedPrice, result.currency),
    formatMoneyLine('USD 对照', result.listingPriceUsd, 'USD'),
    formatMoneyLine('保本标价', result.breakEvenPrice, result.currency),
    formatMoneyLine('扣费后利润', result.profitUsd, 'USD'),
    '',
    formatMoneyLine('产品成本', result.costAmount, result.currency),
    formatMoneyLine('国际运费成本', result.shipCostAmount, result.currency),
    formatMoneyLine('总成本', result.totalCostAmount, result.currency),
    formatMoneyLine('总收入', result.revenueAmount, result.currency),
    formatMoneyLine('总费用', result.totalFeeAmount, result.currency),
    formatMoneyLine('利润额', result.profitAmount, result.currency),
    `实际毛利率: ${formatPercent(result.marginPercent)}`,
    '',
    `交易手续费: ${formatPercent(fee.transactionRatePercent)}`,
    `支付处理费: ${formatPercent(fee.paymentRatePercent)}`,
    `广告费: ${formatPercent(result.adRatePercent)}`,
    `监管费: ${formatPercent(fee.regulatoryFeeRatePercent)}`,
    `费率税/VAT: ${formatPercent(fee.vatRatePercent)}`,
    formatMoneyLine('上架费', fee.listingFee, result.currency),
    formatMoneyLine('支付固定费', fee.paymentFixedFee, result.currency)
  ].join('\n');
}

function buildPricingComparison(reverse = null, forward = null) {
  if (!reverse || !forward) return null;

  const competitorTotalUsd = normalizeNumber(reverse.totalPayableUsd, normalizeNumber(reverse.currentPriceUsd, 0) + normalizeNumber(reverse.shippingChargeUsd, 0));
  const competitorItemUsd = normalizeNumber(reverse.currentPriceUsd, 0);
  const competitorShippingUsd = normalizeNumber(reverse.shippingChargeUsd, 0);
  const competitorProfitUsd = normalizeNumber(reverse.profitUsd, 0);
  const competitorMarginPercent = normalizeNumber(reverse.marginPercent, 0);

  const myTotalUsd = normalizeNumber(forward.totalPayableUsd, normalizeNumber(forward.discountedPriceUsd, 0) + normalizeNumber(forward.shippingChargeUsd, 0));
  const myItemUsd = normalizeNumber(forward.discountedPriceUsd, 0);
  const myShippingUsd = normalizeNumber(forward.shippingChargeUsd, 0);
  const myProfitUsd = normalizeNumber(forward.profitUsd, 0);
  const myMarginPercent = normalizeNumber(forward.marginPercent, normalizeNumber(forward.targetMarginPercent, 0));

  const totalGapUsd = roundMoney(myTotalUsd - competitorTotalUsd);
  const itemGapUsd = roundMoney(myItemUsd - competitorItemUsd);
  const shippingGapUsd = roundMoney(myShippingUsd - competitorShippingUsd);
  const profitGapUsd = roundMoney(myProfitUsd - competitorProfitUsd);
  const marginGapPercent = roundMoney(myMarginPercent - competitorMarginPercent);
  const cheaperPercent = competitorTotalUsd > 0 ? roundMoney((Math.abs(totalGapUsd) / competitorTotalUsd) * 100) : 0;
  const pricingMode = (
    Math.abs(normalizeNumber(forward.discountPercent, 0) - normalizeNumber(reverse.discountPercent, 0)) > 0.01
    || Math.abs(myShippingUsd - competitorShippingUsd) > 0.01
    || Math.abs(normalizeNumber(forward.targetMarginPercent, myMarginPercent) - competitorMarginPercent) > 0.01
  ) ? 'custom' : 'matched';

  let summary = '当前还没有足够的对比数据。';
  if (totalGapUsd < -0.01) {
    summary = `按 USD 拉平后，你的买家总到手价比竞对低 ${formatMoneyValue(Math.abs(totalGapUsd), 'USD')}，约便宜 ${formatPercent(cheaperPercent)}。`;
  } else if (totalGapUsd > 0.01) {
    summary = `按 USD 拉平后，你的买家总到手价比竞对高 ${formatMoneyValue(Math.abs(totalGapUsd), 'USD')}，约高 ${formatPercent(cheaperPercent)}。`;
  } else {
    summary = '按 USD 拉平后，你的买家总到手价与竞对基本持平。';
  }

  if (pricingMode === 'custom') {
    summary += ' 当前方案已经脱离竞对原始毛利 / 折扣基线，属于你的自定义入场价格。';
  } else {
    summary += ' 当前方案基本沿用了竞对的毛利、折扣和运费基线。';
  }

  const breakdown = [
    '对比基准: 全部折算为 USD',
    '',
    `竞对折后商品价: ${formatMoneyValue(competitorItemUsd, 'USD')}`,
    `我的折后商品价: ${formatMoneyValue(myItemUsd, 'USD')}`,
    `商品价差: ${formatSignedMoneyValue(itemGapUsd, 'USD')}`,
    '',
    `竞对运费: ${formatMoneyValue(competitorShippingUsd, 'USD')}`,
    `我的运费: ${formatMoneyValue(myShippingUsd, 'USD')}`,
    `运费差: ${formatSignedMoneyValue(shippingGapUsd, 'USD')}`,
    '',
    `竞对买家总到手价: ${formatMoneyValue(competitorTotalUsd, 'USD')}`,
    `我的买家总到手价: ${formatMoneyValue(myTotalUsd, 'USD')}`,
    `总到手差价: ${formatSignedMoneyValue(totalGapUsd, 'USD')}`,
    '',
    `竞对毛利率: ${formatPercent(competitorMarginPercent)}`,
    `我的毛利率: ${formatPercent(myMarginPercent)}`,
    `毛利率差: ${formatSignedPercent(marginGapPercent)}`,
    '',
    `竞对利润额: ${formatMoneyValue(competitorProfitUsd, 'USD')}`,
    `我的利润额: ${formatMoneyValue(myProfitUsd, 'USD')}`,
    `利润额差: ${formatSignedMoneyValue(profitGapUsd, 'USD')}`
  ].join('\n');

  return {
    totalGapUsd,
    itemGapUsd,
    shippingGapUsd,
    profitGapUsd,
    marginGapPercent,
    summary,
    breakdown
  };
}

function renderPricingComparison(reverse = null, forward = null) {
  const comparison = buildPricingComparison(reverse, forward);
  setText('pricing-compare-total-gap', comparison ? formatSignedMoneyValue(comparison.totalGapUsd, 'USD') : '-');
  setText('pricing-compare-item-gap', comparison ? formatSignedMoneyValue(comparison.itemGapUsd, 'USD') : '-');
  setText('pricing-compare-shipping-gap', comparison ? formatSignedMoneyValue(comparison.shippingGapUsd, 'USD') : '-');
  setText('pricing-compare-margin-gap', comparison ? formatSignedPercent(comparison.marginGapPercent) : '-');
  setText('pricing-compare-profit-gap', comparison ? formatSignedMoneyValue(comparison.profitGapUsd, 'USD') : '-');
  setText(
    'pricing-compare-summary',
    comparison
      ? comparison.summary
      : '完成“计算我的定价”后，这里会告诉你与竞对相比是更便宜还是更贵，以及让利空间有多大。'
  );
  setText('pricing-compare-breakdown', comparison ? comparison.breakdown : '还没有对比结果。');
}

function buildPricingExtractionStatus(info = {}) {
  const parts = [];
  if (info.currentPrice > 0) {
    parts.push(`成交价 ${formatMoneyValue(info.currentPrice, info.currency || '')}`);
  }
  if (info.originalPrice > 0) {
    parts.push(`原价 ${formatMoneyValue(info.originalPrice, info.currency || '')}`);
  }
  if (info.shippingAmount > 0) {
    parts.push(`运费 ${formatMoneyValue(info.shippingAmount, info.shippingCurrency || info.currency || '')}`);
  } else if (/free shipping/i.test(info?.diagnostics?.shippingText || '')) {
    parts.push('运费 Free shipping');
  } else {
    parts.push('运费待确认');
  }
  parts.push(info.shopLocationText ? `店铺位置 ${info.shopLocationText}` : '店铺位置待确认');
  parts.push(info.shipsFromText ? `发货地 ${info.shipsFromText}` : '发货地待确认');
  if (info.variantSummary) {
    parts.push('已识别变体提示');
  }
  return parts.join('；');
}

function renderPricingMeta() {
  setText('pricing-meta-page', state.pricingPageReady ? 'Listing 页已就绪' : '页面 -');
  setText('pricing-meta-listing', state.pricingListingId ? `Listing #${state.pricingListingId}` : 'Listing -');
  setText('pricing-meta-shop', state.pricingShopName ? `店铺 ${state.pricingShopName}` : '店铺 -');
  setText(
    'pricing-meta-currency',
    state.pricingCurrency
      ? `价格 ${formatMoneyValue(state.pricingCurrentPrice, state.pricingCurrency)}`
      : '币种 -'
  );
}

function renderPricingResults() {
  const reverse = state.pricingReverseResult;
  const forward = state.pricingForwardResult;
  const isCustomPricing = !!(reverse && forward && (
    Math.abs(normalizeNumber(forward.discountPercent, 0) - normalizeNumber(reverse.discountPercent, 0)) > 0.01
    || Math.abs(normalizeNumber(forward.shippingChargeUsd, 0) - normalizeNumber(reverse.shippingChargeUsd, 0)) > 0.01
    || Math.abs(normalizeNumber(forward.targetMarginPercent, 0) - normalizeNumber(reverse.marginPercent, 0)) > 0.01
  ));

  setText('pricing-reverse-margin', reverse ? formatPercent(reverse.marginPercent) : '-');
  setText('pricing-reverse-profit', reverse ? formatMoneyValue(reverse.profitAmount, reverse.currency) : '-');
  setText('pricing-reverse-discount', reverse ? formatPercent(reverse.discountPercent) : '-');
  setText('pricing-reverse-fees', reverse ? formatPercent(reverse.totalFeeRatePercent) : '-');
  setText(
    'pricing-reverse-summary',
    reverse
      ? `竞对店铺国家 ${reverse.countryCode}，收入 ${formatMoneyValue(reverse.revenueAmount, reverse.currency)}，总成本 ${formatMoneyValue(reverse.totalCostAmount, reverse.currency)}，固定费用 ${formatMoneyValue(reverse.fixedFeeAmount, reverse.currency)}。`
      : '读取当前 listing 后，填入产品成本和国际运输成本，即可反推竞对毛利。'
  );

  setText('pricing-forward-price', forward ? formatMoneyValue(forward.listingPrice, forward.currency) : '-');
  setText('pricing-forward-final', forward ? formatMoneyValue(forward.discountedPrice, forward.currency) : '-');
  setText('pricing-forward-usd', forward ? formatMoneyValue(forward.listingPriceUsd, 'USD') : '-');
  setText('pricing-forward-break-even', forward ? formatMoneyValue(forward.breakEvenPrice, forward.currency) : '-');
  setText('pricing-forward-profit', forward ? formatMoneyValue(forward.profitUsd, 'USD') : '-');
  setText('pricing-forward-fees', forward ? formatMoneyValue(forward.totalFeeAmount, forward.currency) : '-');
  setText(
    'pricing-forward-summary',
    forward
      ? `${isCustomPricing ? '已按你的自定义毛利 / 折扣 / 运费' : '已按竞对基线'} 计算 ${forward.countryCode} 店铺定价。建议标价 ${formatMoneyValue(forward.listingPrice, forward.currency)}，保本价 ${formatMoneyValue(forward.breakEvenPrice, forward.currency)}，扣费后利润约 ${formatMoneyValue(forward.profitUsd, 'USD')}。费用结构可在下方详情展开查看。`
      : '先完成竞对拆解，系统会继承竞对折扣和运费基线；你也可以手动改毛利率、目标折扣和目标运费，再计算我的定价。'
  );
  setText('pricing-reverse-breakdown', buildReverseBreakdownText(reverse));
  setText('pricing-forward-breakdown', buildForwardBreakdownText(forward));
  renderPricingComparison(reverse, forward);
}

function renderPricingContext() {
  renderPricingMeta();
  setInputValue('pricing-title', state.pricingTitle || '');
  setInputValue('pricing-variant-summary', state.pricingVariantSummary || '');
  syncForwardTargetInputs();
  renderPricingResults();
  renderPricingTargetMarketField();
}

function resetPricingState() {
  state.pricingPageReady = false;
  state.pricingCurrentUrl = '';
  state.pricingListingId = '';
  state.pricingTitle = '';
  state.pricingShopName = '';
  state.pricingExtractor = '';
  state.pricingDiagnostics = {};
  state.pricingCurrency = '';
  state.pricingCurrentPrice = 0;
  state.pricingOriginalPrice = 0;
  state.pricingShippingAmount = 0;
  state.pricingShippingCurrency = '';
  state.pricingShopLocation = '';
  state.pricingShipsFrom = '';
  state.pricingVariantSummary = '';
  state.pricingDetectedCountryCode = '';
  state.pricingSnapshotId = null;
  state.pricingReverseResult = null;
  state.pricingForwardResult = null;
  setInputValue('pricing-title', '');
  setInputValue('pricing-current-price', '');
  setInputValue('pricing-original-price', '');
  setInputValue('pricing-currency', '');
  setInputValue('pricing-discount-percent', '');
  setInputValue('pricing-shipping-amount', '');
  setInputValue('pricing-shipping-currency', '');
  setInputValue('pricing-shop-location', '');
  setInputValue('pricing-ships-from', '');
  setInputValue('pricing-variant-summary', '');
  setInputValue('pricing-inherited-discount', '');
  setInputValue('pricing-inherited-shipping', '');
  setInputValue('pricing-target-discount', '');
  setInputValue('pricing-target-shipping-amount', '');
  setInputValue('pricing-target-shipping-currency', '');
  setText('pricing-reverse-breakdown', '还没有逆向定价详情。');
  setText('pricing-forward-breakdown', '还没有正向定价详情。');
  setPricingCollectionStatus();
  renderPricingContext();
}

async function loadPricingLocalDefaultConfig() {
  try {
    const data = await chrome.storage.local.get(PRICING_DEFAULT_CONFIG_KEY);
    const config = data[PRICING_DEFAULT_CONFIG_KEY] || {};
    const countryCode = String(config.countryCode || '').trim().toUpperCase();
    const defaultAdRate = normalizeNumber(config.defaultAdRate, 15);
    if (countryCode && !getInputValue('pricing-seller-country')) {
      setInputValue('pricing-seller-country', countryCode);
      state.pricingSellerCountryCode = countryCode;
    }
    if (!getInputValue('pricing-default-ad-rate')) {
      setInputValue('pricing-default-ad-rate', roundMoney(defaultAdRate));
    }
    if (!getInputValue('pricing-ad-rate')) {
      setInputValue('pricing-ad-rate', roundMoney(defaultAdRate));
    }
    if (config.shopId && !getInputValue('pricing-seller-shop-id')) {
      setInputValue('pricing-seller-shop-id', config.shopId);
      state.pricingSellerShopId = config.shopId;
    }
    syncPricingSellerCurrency();
    return config;
  } catch (e) {
    return null;
  }
}

async function savePricingLocalDefaultConfig(config = {}) {
  const payload = {
    shopId: String(config.shopId || '').trim(),
    countryCode: String(config.countryCode || '').trim().toUpperCase(),
    defaultAdRate: normalizeNumber(config.defaultAdRate, 15)
  };
  await chrome.storage.local.set({ [PRICING_DEFAULT_CONFIG_KEY]: payload });
}

async function loadPricingFeeProfiles() {
  if (Array.isArray(state.pricingFeeProfiles) && state.pricingFeeProfiles.length > 0) {
    populatePricingCountrySelects();
    return state.pricingFeeProfiles;
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/pricing/fee-profiles`);
    const data = await res.json();
    if (!res.ok || !Array.isArray(data?.profiles)) {
      throw new Error(data?.error || 'pricing profiles unavailable');
    }
    state.pricingFeeProfiles = data.profiles;
    populatePricingCountrySelects();
    await loadPricingLocalDefaultConfig();
    syncPricingSellerCurrency();
    return state.pricingFeeProfiles;
  } catch (e) {
    state.pricingFeeProfiles = [];
    populatePricingCountrySelects();
    setPricingStatus('定价费率配置读取失败。', 'err');
    return [];
  }
}

async function loadPricingSellerContext() {
  try {
    const context = await chrome.runtime.sendMessage({ action: 'getSafeMode' });
    const shopId = String(context?.shopId || '').trim();
    if (shopId && shopId !== 'default') {
      state.pricingSellerShopId = shopId;
      if (!getInputValue('pricing-seller-shop-id')) {
        setInputValue('pricing-seller-shop-id', shopId);
      }
    }
  } catch (e) {}
}

async function loadPricingShopConfig() {
  const shopId = getInputValue('pricing-seller-shop-id') || state.pricingSellerShopId;
  if (!shopId) {
    syncPricingSellerCurrency();
    const selectedCountry = getInputValue('pricing-seller-country') || state.pricingSellerCountryCode;
    if (selectedCountry) {
      setPricingConfigStatus(`当前没有店铺 ID，先按 ${selectedCountry} 的国家费率做计算。`, 'ok');
    } else {
      setPricingConfigStatus('当前还没有识别到你的店铺上下文，可直接选择国家后使用。', 'neutral');
    }
    return null;
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/pricing/shop-config?shopId=${encodeURIComponent(shopId)}`);
    const data = await res.json();
    if (!res.ok || !data?.config) {
      throw new Error(data?.error || 'pricing config unavailable');
    }
    const config = data.config;
    state.pricingSellerShopId = config.shopId || shopId;
    state.pricingSellerCountryCode = String(config.countryCode || '').trim().toUpperCase();
    state.pricingSellerCurrency = config.settlementCurrency || '';
    state.pricingDefaultAdRate = Number(config.defaultAdRate ?? 15);
    setInputValue('pricing-seller-shop-id', state.pricingSellerShopId);
    setInputValue('pricing-seller-country', state.pricingSellerCountryCode);
    setInputValue('pricing-seller-currency', state.pricingSellerCurrency);
    if (!getInputValue('pricing-default-ad-rate')) {
      setInputValue('pricing-default-ad-rate', roundMoney(state.pricingDefaultAdRate));
    }
    if (!getInputValue('pricing-ad-rate')) {
      setInputValue('pricing-ad-rate', roundMoney(state.pricingDefaultAdRate));
    }
    setPricingConfigStatus(
      config.countryCode
        ? `当前店铺 ${state.pricingSellerShopId} 已绑定 ${config.countryCode} / ${config.settlementCurrency} 费率配置。`
        : `当前店铺 ${state.pricingSellerShopId} 还没有保存定价配置。`,
      config.countryCode ? 'ok' : 'neutral'
    );
    renderPricingTargetMarketField();
    return config;
  } catch (e) {
    syncPricingSellerCurrency();
    setPricingConfigStatus('店铺定价配置读取失败，可手动填写后保存。', 'neutral');
    return null;
  }
}

function hydratePricingInputsFromContext(info = {}, options = {}) {
  const { force = false } = options;
  const previousContextKey = buildPricingAutoKey();
  const nextContextKey = buildPricingAutoKey({
    listingId: info.listingId || state.pricingListingId || '',
    currentUrl: info.currentUrl || state.pricingCurrentUrl || '',
    currentPrice: info.currentPrice ?? state.pricingCurrentPrice ?? 0,
    originalPrice: info.originalPrice ?? state.pricingOriginalPrice ?? 0,
    shippingAmount: info.shippingAmount ?? state.pricingShippingAmount ?? 0,
    variantSummary: info.variantSummary || state.pricingVariantSummary || ''
  });
  const contextChanged = Boolean(nextContextKey) && previousContextKey !== nextContextKey;
  const shouldOverwrite = force || contextChanged;
  const previousReverseMargin = normalizeNumber(state.pricingReverseResult?.marginPercent, NaN);
  const currentTargetMargin = normalizeNumber(getInputValue('pricing-target-margin'), NaN);

  state.pricingCurrentUrl = info.currentUrl || state.pricingCurrentUrl || '';
  state.pricingListingId = info.listingId || state.pricingListingId || '';
  state.pricingTitle = info.title || state.pricingTitle || '';
  state.pricingShopName = info.shopName || state.pricingShopName || '';
  state.pricingExtractor = info.extractor || state.pricingExtractor || '';
  state.pricingDiagnostics = info.diagnostics || state.pricingDiagnostics || {};
  if (shouldOverwrite) {
    state.pricingCurrency = normalizeCurrency(info.currency || '');
    state.pricingCurrentPrice = normalizeNumber(info.currentPrice, 0);
    state.pricingOriginalPrice = normalizeNumber(info.originalPrice, 0);
    state.pricingShippingAmount = normalizeNumber(info.shippingAmount, 0);
    state.pricingShippingCurrency = normalizeCurrency(info.shippingCurrency || info.currency || '');
    state.pricingShopLocation = String(info.shopLocationText || '').trim();
    state.pricingShipsFrom = String(info.shipsFromText || '').trim();
    state.pricingVariantSummary = String(info.variantSummary || '').trim();
  } else {
    state.pricingCurrency = normalizeCurrency(info.currency || state.pricingCurrency || '');
    state.pricingCurrentPrice = normalizeNumber(info.currentPrice, state.pricingCurrentPrice || 0);
    state.pricingOriginalPrice = normalizeNumber(info.originalPrice, state.pricingOriginalPrice || 0);
    state.pricingShippingAmount = normalizeNumber(info.shippingAmount, state.pricingShippingAmount || 0);
    state.pricingShippingCurrency = normalizeCurrency(info.shippingCurrency || state.pricingShippingCurrency || state.pricingCurrency || '');
    state.pricingShopLocation = info.shopLocationText || state.pricingShopLocation || '';
    state.pricingShipsFrom = info.shipsFromText || state.pricingShipsFrom || '';
    state.pricingVariantSummary = info.variantSummary || state.pricingVariantSummary || '';
  }
  state.pricingDetectedCountryCode = guessPricingCountryCode(state.pricingShopLocation)
    || guessPricingCountryCode(state.pricingShipsFrom)
    || '';

  if (contextChanged) {
    state.pricingReverseResult = null;
    state.pricingForwardResult = null;
    if (Number.isFinite(previousReverseMargin) && Number.isFinite(currentTargetMargin) && Math.abs(currentTargetMargin - previousReverseMargin) < 0.01) {
      setInputValue('pricing-target-margin', '');
    }
    setInputValue('pricing-target-discount', '');
    setInputValue('pricing-target-shipping-amount', '');
    setInputValue('pricing-target-shipping-currency', '');
  }

  if (shouldOverwrite || !getInputValue('pricing-current-price')) setInputValue('pricing-current-price', state.pricingCurrentPrice || '');
  if (shouldOverwrite || !getInputValue('pricing-original-price')) setInputValue('pricing-original-price', state.pricingOriginalPrice || '');
  if (shouldOverwrite || !getInputValue('pricing-discount-percent')) {
    setInputValue(
      'pricing-discount-percent',
      state.pricingOriginalPrice > state.pricingCurrentPrice && state.pricingCurrentPrice > 0
        ? roundMoney((1 - (state.pricingCurrentPrice / state.pricingOriginalPrice)) * 100)
        : 0
    );
  }
  if (shouldOverwrite || !getInputValue('pricing-currency')) setInputValue('pricing-currency', state.pricingCurrency || '');
  if (shouldOverwrite || !getInputValue('pricing-shipping-amount')) setInputValue('pricing-shipping-amount', state.pricingShippingAmount || '');
  if (shouldOverwrite || !getInputValue('pricing-shipping-currency')) setInputValue('pricing-shipping-currency', state.pricingShippingCurrency || state.pricingCurrency || '');
  if (shouldOverwrite || !getInputValue('pricing-shop-location')) setInputValue('pricing-shop-location', state.pricingShopLocation || '');
  if (shouldOverwrite || !getInputValue('pricing-ships-from')) setInputValue('pricing-ships-from', state.pricingShipsFrom || '');
  if (shouldOverwrite || !getInputValue('pricing-variant-summary')) setInputValue('pricing-variant-summary', state.pricingVariantSummary || '');
  if (shouldOverwrite) {
    setInputValue('pricing-competitor-country', state.pricingDetectedCountryCode || '');
  } else if (!getInputValue('pricing-competitor-country') && state.pricingDetectedCountryCode) {
    setInputValue('pricing-competitor-country', state.pricingDetectedCountryCode);
  }
  renderPricingContext();
}

function getPricingPagePayload() {
  const currentPrice = normalizeNumber(getInputValue('pricing-current-price'), 0);
  const originalPriceInput = normalizeNumber(getInputValue('pricing-original-price'), 0);
  const originalPrice = originalPriceInput > currentPrice ? originalPriceInput : currentPrice;
  const discountPercentInput = normalizeNumber(getInputValue('pricing-discount-percent'), 0);
  const discountPercent = discountPercentInput > 0
    ? discountPercentInput
    : (originalPrice > currentPrice && currentPrice > 0 ? roundMoney((1 - (currentPrice / originalPrice)) * 100) : 0);
  const shippingAmount = normalizeNumber(getInputValue('pricing-shipping-amount'), 0);
  const adRateValue = getInputValue('pricing-ad-rate') || getInputValue('pricing-default-ad-rate');
  return {
    listingId: state.pricingListingId || '',
    currentUrl: state.pricingCurrentUrl || '',
    title: getInputValue('pricing-title') || state.pricingTitle || '',
    shopName: state.pricingShopName || '',
    shopLocationText: getInputValue('pricing-shop-location') || state.pricingShopLocation || '',
    shipsFromText: getInputValue('pricing-ships-from') || state.pricingShipsFrom || '',
    competitorCountryCode: (getInputValue('pricing-competitor-country') || state.pricingDetectedCountryCode || '').toUpperCase(),
    currency: normalizeCurrency(getInputValue('pricing-currency') || state.pricingCurrency || ''),
    currentPrice,
    originalPrice,
    discountPercent,
    shippingAmount,
    shippingCurrency: normalizeCurrency(getInputValue('pricing-shipping-currency') || state.pricingShippingCurrency || state.pricingCurrency || ''),
    targetMarket: getInputValue('pricing-target-market') || 'international',
    costCny: normalizeNumber(getInputValue('pricing-cost-cny'), 0),
    shipCostCny: normalizeNumber(getInputValue('pricing-ship-cost-cny'), 0),
    adRatePercent: clampPercent(adRateValue || state.pricingDefaultAdRate || 15)
  };
}

async function refreshPricingContext(options = {}) {
  const { preserveStatus = false, forceHydrate = false } = options;
  if (!preserveStatus) {
    setPricingMetaFeedback('读取中...', 'Listing 读取中', '正在读取价格 / 运费...');
    setPill('page-pill', 'Listing 读取中...', 'neutral');
    setPricingStatus('正在读取当前 listing 页面...', 'neutral');
  }
  const tab = await getActiveTab();
  if (!tab) {
    resetPricingState();
    setPricingMetaFeedback('未找到活动标签页', '请切回 Etsy 页面', '价格 -');
    setPill('page-pill', '没有活动标签页', 'err');
    setPricingStatus('没有活动标签页。', 'err');
    return null;
  }

  state.currentTabId = tab.id;
  state.currentUrl = tab.url || '';
  setText('meta-url', state.currentUrl);

  if (!/^https:\/\/www\.etsy\.com\//.test(state.currentUrl)) {
    resetPricingState();
    setPricingMetaFeedback('当前不是 Etsy', '请切到 Etsy Listing', '价格 -');
    setPill('page-pill', '请先打开 Etsy 页面', 'err');
    setPricingStatus('先打开 Etsy listing 页面。', 'err');
    return null;
  }

  if (!isPricingUrl(state.currentUrl)) {
    resetPricingState();
    setPricingMetaFeedback('当前不是 Listing', '请打开 Etsy listing', '价格 -');
    setPill('page-pill', '请先打开 Listing 页面', 'neutral');
    if (!preserveStatus) setPricingStatus('当前不是 Etsy listing 页面。', 'neutral');
    return {
      ok: true,
      isPricingPage: false,
      currentUrl: state.currentUrl
    };
  }

  try {
    await loadPricingFeeProfiles();
    await loadPricingLocalDefaultConfig();
    await loadPricingSellerContext();
    const extracted = await extractPricingFromTab(tab.id, 3);
    const info = {
      ok: extracted.isListingPage && !!extracted.listingId,
      isPricingPage: extracted.isListingPage,
      currentUrl: extracted.currentUrl || tab.url || '',
      listingId: extracted.listingId || '',
      title: extracted.title || '',
      shopName: extracted.shopName || '',
      shopLocationText: extracted.shopLocationText || '',
      shipsFromText: extracted.shipsFromText || '',
      currency: extracted.currency || '',
      currentPrice: extracted.currentPrice || 0,
      originalPrice: extracted.originalPrice || 0,
      shippingAmount: extracted.shippingAmount || 0,
      shippingCurrency: extracted.shippingCurrency || extracted.currency || '',
      variantSummary: extracted.variantSummary || '',
      diagnostics: extracted.diagnostics || {},
      extractor: extracted.extractor || 'pricing-main-v1'
    };

    state.pricingPageReady = !!info.isPricingPage;
    hydratePricingInputsFromContext(info, { force: forceHydrate });
    await loadPricingShopConfig();

    const currentDiscountPercent = state.pricingOriginalPrice > state.pricingCurrentPrice && state.pricingCurrentPrice > 0
      ? ((1 - (state.pricingCurrentPrice / state.pricingOriginalPrice)) * 100)
      : 0;
    setInputValue('pricing-inherited-discount', formatPercent(currentDiscountPercent));
    setInputValue(
      'pricing-inherited-shipping',
      formatMoneyValue(
        normalizeNumber(getInputValue('pricing-shipping-amount'), state.pricingShippingAmount || 0),
        normalizeCurrency(getInputValue('pricing-shipping-currency') || state.pricingShippingCurrency || state.pricingCurrency || '')
      )
    );

    setPill(
      'page-pill',
      `Listing 已就绪 | ${info.currentPrice ? formatMoneyValue(info.currentPrice, info.currency) : '价格待确认'} | ${info.extractor}`,
      'ok'
    );
    if (!preserveStatus) {
      setPricingStatus(
        info.currentPrice > 0
          ? `已读取当前 listing：${info.title || info.listingId}。${buildPricingExtractionStatus(info)}。若你刚切换了商品，旧计算会自动失效。`
          : `当前 listing 已读取，但价格还未完全识别。${buildPricingExtractionStatus(info)}。必要时可手动修正后再计算。若你刚切换了商品，旧计算会自动失效。`,
        info.currentPrice > 0 ? 'ok' : 'neutral'
      );
    }
    persistPricingSnapshot({ quiet: true }).catch(() => {});
    return info;
  } catch (e) {
    const errorText = String(e?.message || e || '未知错误');
    resetPricingState();
    setPricingMetaFeedback('读取失败', '请重试当前页', '价格 -');
    setPill('page-pill', 'Listing 上下文不可用', 'err');
    setPricingStatus(`当前 listing 页面读取失败：${errorText}`, 'err');
    return null;
  }
}

async function savePricingConfig() {
  await loadPricingFeeProfiles();
  const shopId = getInputValue('pricing-seller-shop-id');
  const countryCode = getInputValue('pricing-seller-country').toUpperCase();
  const defaultAdRate = clampPercent(getInputValue('pricing-default-ad-rate') || 15);
  if (!countryCode) {
    setPricingConfigStatus('请先选择我的开店国家。', 'err');
    return;
  }

  syncPricingSellerCurrency();
  const profile = getPricingProfileByCode(countryCode);
  setBusy('save-pricing-config', true, '保存中...');
  try {
    await savePricingLocalDefaultConfig({
      shopId,
      countryCode,
      defaultAdRate
    });

    if (!shopId) {
      state.pricingSellerCountryCode = countryCode;
      state.pricingSellerCurrency = profile?.settlementCurrency || '';
      state.pricingDefaultAdRate = defaultAdRate;
      setInputValue('pricing-seller-currency', state.pricingSellerCurrency);
      setInputValue('pricing-default-ad-rate', roundMoney(state.pricingDefaultAdRate));
      if (!getInputValue('pricing-ad-rate')) {
        setInputValue('pricing-ad-rate', roundMoney(state.pricingDefaultAdRate));
      }
      setPricingConfigStatus(
        `已保存默认国家配置：${countryCode} / ${state.pricingSellerCurrency} / 广告费率 ${formatPercent(defaultAdRate)}。不填店铺 ID 也可继续使用。`,
        'ok'
      );
      return;
    }

    const res = await apiFetch(`${state.apiBase}/api/pricing/shop-config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        shopId,
        displayName: shopId,
        countryCode,
        feeProfileCode: profile?.profileCode || countryCode,
        defaultAdRatePercent: defaultAdRate
      })
    });
    const data = await res.json();
    if (!res.ok || !data?.config) {
      throw new Error(data?.error || 'save pricing config failed');
    }
    state.pricingSellerShopId = data.config.shopId || shopId;
    state.pricingSellerCountryCode = data.config.countryCode || countryCode;
    state.pricingSellerCurrency = data.config.settlementCurrency || profile?.settlementCurrency || '';
    state.pricingDefaultAdRate = Number(data.config.defaultAdRate ?? defaultAdRate);
    setInputValue('pricing-seller-currency', state.pricingSellerCurrency);
    setInputValue('pricing-default-ad-rate', roundMoney(state.pricingDefaultAdRate));
    if (!getInputValue('pricing-ad-rate')) {
      setInputValue('pricing-ad-rate', roundMoney(state.pricingDefaultAdRate));
    }
    setPricingConfigStatus(
      `已保存 ${state.pricingSellerShopId} 的定价配置：${state.pricingSellerCountryCode} / ${state.pricingSellerCurrency} / 广告费率 ${formatPercent(state.pricingDefaultAdRate)}。`,
      'ok'
    );
  } catch (e) {
    setPricingConfigStatus('保存店铺定价配置失败。', 'err');
  } finally {
    setBusy('save-pricing-config', false);
  }
}

async function runReversePricing() {
  const payload = getPricingPagePayload();
  if (!payload.currentPrice || !payload.currency) {
    setPricingStatus('请先读取当前 listing 页面，并确认价格和币种已识别。', 'err');
    return;
  }
  if (!payload.competitorCountryCode) {
    setPricingStatus('请先确认竞对店铺国家。如果自动识别不到，请手动选择。', 'err');
    return;
  }
  if (!payload.costCny && !payload.shipCostCny) {
    setPricingStatus('请先填写产品成本和国际运输成本。', 'err');
    return;
  }

  setBusy('pricing-run-reverse', true, '计算中...');
  setPricingStatus('正在反推竞对毛利结构...', 'neutral');
  try {
    const res = await apiFetch(`${state.apiBase}/api/pricing/reverse-calc`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || !data?.result) {
      throw new Error(data?.error || 'reverse pricing failed');
    }
    state.pricingReverseResult = data.result;
    setInputValue('pricing-target-margin', roundMoney(data.result.marginPercent));
    setInputValue('pricing-inherited-discount', formatPercent(data.result.discountPercent));
    setInputValue('pricing-discount-percent', roundMoney(data.result.discountPercent));
    setInputValue('pricing-inherited-shipping', buildInheritedShippingText(data.result));
    syncForwardTargetInputs();
    renderPricingResults();
    setPricingStatus(`逆向定价完成，竞对毛利率约为 ${formatPercent(data.result.marginPercent)}。`, 'ok');
    persistPricingSnapshot({ force: true, quiet: true }).catch(() => {});
  } catch (e) {
    state.pricingReverseResult = null;
    renderPricingResults();
    setPricingStatus(`逆向定价失败：${e.message || 'unknown error'}`, 'err');
  } finally {
    setBusy('pricing-run-reverse', false);
  }
}

async function runForwardPricing() {
  const payload = getPricingPagePayload();
  const sellerShopId = getInputValue('pricing-seller-shop-id') || state.pricingSellerShopId;
  const sellerCountryCode = getInputValue('pricing-seller-country').toUpperCase() || state.pricingSellerCountryCode;
  const targetDiscountPercent = normalizeNumber(
    getInputValue('pricing-target-discount'),
    normalizeNumber(state.pricingReverseResult?.discountPercent, payload.discountPercent)
  );
  const targetShippingAmount = normalizeNumber(
    getInputValue('pricing-target-shipping-amount'),
    payload.shippingAmount
  );
  const targetShippingCurrency = normalizeCurrency(
    getInputValue('pricing-target-shipping-currency')
    || payload.shippingCurrency
    || state.pricingSellerCurrency
    || state.pricingCurrency
    || ''
  );
  const targetMarginPercent = normalizeNumber(
    getInputValue('pricing-target-margin'),
    normalizeNumber(state.pricingReverseResult?.marginPercent, 0)
  );

  if (!sellerCountryCode) {
    setPricingStatus('请先配置我的店铺国家后再做正向定价。', 'err');
    return;
  }
  if (!payload.currency || !payload.currentPrice) {
    setPricingStatus('请先读取当前 listing 页面。', 'err');
    return;
  }

  setBusy('pricing-run-forward', true, '计算中...');
  setPricingStatus('正在按我的店铺费率计算我的定价...', 'neutral');
  try {
    const res = await apiFetch(`${state.apiBase}/api/pricing/forward-calc`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...payload,
        discountPercent: targetDiscountPercent,
        shippingAmount: targetShippingAmount,
        shippingCurrency: targetShippingCurrency,
        sellerShopId,
        sellerCountryCode,
        targetMarginPercent,
        defaultAdRatePercent: clampPercent(getInputValue('pricing-default-ad-rate') || state.pricingDefaultAdRate || 15)
      })
    });
    const data = await res.json();
    if (!res.ok || !data?.result) {
      throw new Error(data?.error || 'forward pricing failed');
    }
    state.pricingForwardResult = data.result;
    renderPricingResults();
    setPricingStatus(`我的定价已更新，建议标价约为 ${formatMoneyValue(data.result.listingPrice, data.result.currency)}。`, 'ok');
    persistPricingSnapshot({ force: true, quiet: true }).catch(() => {});
  } catch (e) {
    state.pricingForwardResult = null;
    renderPricingResults();
    setPricingStatus(`正向定价失败：${e.message || 'unknown error'}`, 'err');
  } finally {
    setBusy('pricing-run-forward', false);
  }
}

async function loadOrderConfig() {
  if (!state.orderShopId) {
    state.orderFeishuLink = '';
    state.orderConfigReady = false;
    state.orderConfigSource = '';
    state.orderConfigWarnings = [];
    state.orderConfigEditorVisible = false;
    renderOrderConfig();
    return;
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/orders/config?shopId=${encodeURIComponent(state.orderShopId)}`);
    const data = await res.json();
    if (!res.ok || !data?.config) {
      throw new Error(data?.error || 'config unavailable');
    }

    const config = data.config;
    state.orderDisplayName = config.displayName || state.orderShopId;
    state.orderFeishuLink = config.feishuLink || '';
    state.orderConfigReady = !!config.ready;
    state.orderConfigSource = config.source || '';
    state.orderConfigWarnings = Array.isArray(config.warnings) ? config.warnings : [];
    state.orderConfigEditorVisible = !state.orderConfigReady;
    renderOrderConfig();
  } catch (e) {
    state.orderFeishuLink = '';
    state.orderConfigReady = false;
    state.orderConfigSource = '';
    state.orderConfigWarnings = ['飞书配置读取失败。'];
    state.orderConfigEditorVisible = true;
    renderOrderConfig();
  }
}

async function fetchOrderStats() {
  if (!state.orderShopId) {
    renderOrderStats(null);
    return;
  }
  try {
    const res = await apiFetch(`${state.apiBase}/api/orders/stats?shopId=${encodeURIComponent(state.orderShopId)}`);
    if (!res.ok) throw new Error('stats unavailable');
    const data = await res.json();
    renderOrderStats(data);
  } catch (e) {
    renderOrderStats(null);
  }
}

async function compareVisibleOrdersWithBackend(orders = [], options = {}) {
  const { preserveStatus = false } = options;
  const visibleOrderIds = Array.isArray(orders)
    ? Array.from(new Set(
      orders
        .map((order) => normalizeOrderId(order?.orderNumber || order?.order_id || order?.id))
        .filter(Boolean)
    ))
    : [];

  state.orderVisibleOrderIds = visibleOrderIds;
  state.orderKnownOrderIds = [];
  state.orderNewOrderIds = [];
  state.orderCompareState = visibleOrderIds.length > 0 ? 'checking' : 'idle';
  renderOrdersMeta();
  renderOrderSyncButton();

  if (!state.orderShopId || visibleOrderIds.length === 0) {
    if (!preserveStatus && state.orderPageReady) {
      setOrdersStatus(
        visibleOrderIds.length === 0
          ? '当前订单页还没有识别到可比对的订单。'
          : '先识别当前店铺，再进行后台订单比对。',
        'neutral'
      );
    }
    return {
      visibleOrderIds,
      knownOrderIds: [],
      newOrderIds: []
    };
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/orders/feishu-state?shopId=${encodeURIComponent(state.orderShopId)}`);
    if (!res.ok) throw new Error('order comparison unavailable');
    const data = await res.json();
    const knownOrderIds = Array.from(new Set(
      (Array.isArray(data.orderIds) ? data.orderIds : [])
        .map((orderId) => normalizeOrderId(orderId))
        .filter(Boolean)
    ));
    const knownSet = new Set(knownOrderIds);
    const newOrderIds = visibleOrderIds.filter((orderId) => !knownSet.has(orderId));

    state.orderKnownOrderIds = knownOrderIds;
    state.orderNewOrderIds = newOrderIds;
    state.orderCompareState = newOrderIds.length > 0 ? 'has-new' : 'known';
    renderOrdersMeta();
    renderOrderSyncButton();

    if (!preserveStatus) {
      if (newOrderIds.length > 0) {
        setOrdersStatus(
          `当前页共 ${visibleOrderIds.length} 单，其中新订单 ${newOrderIds.length} 单，已入库 ${visibleOrderIds.length - newOrderIds.length} 单。`,
          'neutral'
        );
      } else {
        setOrdersStatus(`当前页共 ${visibleOrderIds.length} 单，已全部入库。`, 'ok');
      }
    }

    return {
      visibleOrderIds,
      knownOrderIds,
      newOrderIds
    };
  } catch (e) {
    state.orderCompareState = 'idle';
    renderOrdersMeta();
    renderOrderSyncButton();
    if (!preserveStatus) {
      setOrdersStatus('已读取当前订单页，但后台订单比对失败。', 'err');
    }
    return {
      visibleOrderIds,
      knownOrderIds: [],
      newOrderIds: []
    };
  }
}

async function saveOrderConfig() {
  if (!state.orderShopId) {
    setOrdersConfigStatus('请先打开 Etsy Sold Orders 页面，让插件识别当前店铺。', 'err');
    return;
  }

  const feishuLink = document.getElementById('orders-feishu-link').value.trim();
  state.orderFeishuLink = feishuLink;
  renderOrderConfig();

  setBusy('save-orders-config', true, '保存中...');
  try {
    const res = await apiFetch(`${state.apiBase}/api/orders/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        shopId: state.orderShopId,
        displayName: state.orderDisplayName || state.orderShopId,
        feishuId: '',
        feishuLink
      })
    });
    const data = await res.json();
    if (!res.ok || !data?.config) {
      setOrdersConfigStatus(data?.error || '保存飞书配置失败。', 'err');
      return;
    }

    const config = data.config;
    state.orderFeishuLink = config.feishuLink || feishuLink;
    state.orderConfigReady = !!config.ready;
    state.orderConfigSource = config.source || '';
    state.orderConfigWarnings = Array.isArray(config.warnings) ? config.warnings : [];
    state.orderConfigEditorVisible = !config.ready;
    state.lastOrderAutoKey = '';
    renderOrderConfig();
    if (data?.feishuState?.total >= 0) {
      setOrdersConfigStatus(`当前店铺配置已保存，飞书表里已识别到 ${data.feishuState.total} 条历史订单。`, 'ok');
    } else if (data?.feishuState?.error) {
      setOrdersConfigStatus(`配置已保存，但读取飞书历史订单失败：${data.feishuState.error}`, 'neutral');
    } else {
    setOrdersConfigStatus(
      config.ready
        ? '当前店铺配置已保存。之后手动同步时，会写入这个飞书表格。'
        : '配置已保存，但飞书表格信息还不完整。手动同步时仍会先进入后台总表。',
      config.ready ? 'ok' : 'neutral'
    );
    }
    queueAutoSync('orders-config-saved', { force: true, delay: 120 });
  } catch (e) {
    setOrdersConfigStatus('保存飞书配置失败。', 'err');
  } finally {
    setBusy('save-orders-config', false);
  }
}

function openOrderFeishuLink() {
  const linkInput = document.getElementById('orders-feishu-link');
  const link = linkInput?.value.trim() || state.orderFeishuLink || '';
  if (!link) {
    setOrdersConfigStatus('先填入飞书链接，再打开。', 'err');
    return;
  }

  try {
    new URL(link);
  } catch (e) {
    setOrdersConfigStatus('飞书链接格式不正确。', 'err');
    return;
  }

  chrome.tabs.create({ url: link }, () => {
    if (chrome.runtime.lastError) {
      setOrdersConfigStatus('打开飞书链接失败。', 'err');
    }
  });
}

function openPricingDashboard() {
  const targetUrl = `${String(state.apiBase || CLOUD_URL).replace(/\/$/, '')}/pricing.html`;
  chrome.tabs.create({ url: targetUrl }, () => {
    if (chrome.runtime.lastError) {
      setPricingCollectionStatus('打开后台定价库失败。请直接访问云端后台。');
    }
  });
}

function openResearchDashboard() {
  const target = new URL(`${String(state.apiBase || CLOUD_URL).replace(/\/$/, '')}/research.html`);
  if (state.researchKeyword) {
    target.searchParams.set('keyword', state.researchKeyword);
  }
  chrome.tabs.create({ url: target.toString() }, () => {
    if (chrome.runtime.lastError) {
      setResearchCollectionStatus('打开后台研究库失败。请直接访问云端后台。');
    }
  });
}

async function refreshOrdersContext(options = {}) {
  const { preserveStatus = false } = options;
  const tab = await getActiveTab();
  if (!tab) {
    resetOrdersState();
    setPill('page-pill', '没有活动标签页', 'err');
    setOrdersStatus('没有活动标签页。', 'err');
    return null;
  }

  state.currentTabId = tab.id;
  state.currentUrl = tab.url || '';
  setText('meta-url', state.currentUrl);

  if (!/^https:\/\/www\.etsy\.com\//.test(state.currentUrl)) {
    resetOrdersState();
    setPill('page-pill', '请先打开 Etsy 页面', 'err');
    setOrdersStatus('先打开 Etsy Sold Orders 页面。', 'err');
    return null;
  }

  if (!isOrdersUrl(state.currentUrl)) {
    resetOrdersState();
    setPill('page-pill', '请先打开 Sold Orders 页面', 'neutral');
    if (!preserveStatus) setOrdersStatus('当前不是 Etsy Sold Orders 页面。', 'neutral');
    return {
      ok: true,
      isOrdersPage: false,
      shopId: '',
      currentUrl: state.currentUrl,
      orderCount: 0
    };
  }

  try {
    const extracted = await extractOrdersFromMainWorld(tab.id, 3);
    const info = {
      ok: !extracted.error,
      safeMode: true,
      isOrdersPage: true,
      shopId: extracted.shopName || '',
      currentUrl: tab.url || '',
      orderCount: Array.isArray(extracted.orders) ? extracted.orders.length : 0,
      orderIds: Array.isArray(extracted.orders)
        ? extracted.orders
          .map((order) => normalizeOrderId(order?.orderNumber || order?.order_id || order?.id))
          .filter(Boolean)
        : [],
      error: extracted.error || null,
      diagnostics: {
        extractor: extracted.extractor || 'main-world-v2',
        shopId: extracted.shopName || '',
        ordersFound: Array.isArray(extracted.orders) ? extracted.orders.length : 0
      }
    };

    state.orderShopId = info.shopId || '';
    state.orderDisplayName = info.shopId || '';
    state.orderCurrentUrl = info.currentUrl || tab.url || '';
    state.orderCount = Number(info.orderCount || 0);
    state.orderVisibleOrderIds = Array.isArray(info.orderIds) ? info.orderIds : [];
    state.orderPageReady = !!info.isOrdersPage;
    renderOrdersMeta();
    renderOrderSyncButton();
    await loadOrderConfig();
    await Promise.all([
      compareVisibleOrdersWithBackend(extracted.orders, { preserveStatus }),
      fetchOrderStats()
    ]);

    if (!info.isOrdersPage) {
      setPill('page-pill', '当前不是订单页', 'neutral');
      if (!preserveStatus) setOrdersStatus('请先进入 Etsy Sold Orders 页面。', 'neutral');
      return info;
    }

    const extractorLabel = info?.diagnostics?.extractor ? ` | ${info.diagnostics.extractor}` : '';
    setPill('page-pill', `订单页就绪 | ${state.orderCount || 0} 单${extractorLabel}`, 'ok');
    if (!preserveStatus) {
      if (info.error && !state.orderCount) {
        setOrdersStatus(`订单页已打开，但当前未解析出订单：${info.error}。`, 'neutral');
      } else {
        if (state.orderCompareState === 'has-new') {
          setOrdersStatus(
            `订单页已就绪。当前页共 ${state.orderCount} 单，其中新订单 ${state.orderNewOrderIds.length} 单，已入库 ${Math.max(state.orderCount - state.orderNewOrderIds.length, 0)} 单。`,
            'neutral'
          );
        } else if (state.orderCompareState === 'known') {
          setOrdersStatus(`订单页已就绪。当前页共 ${state.orderCount} 单，已全部入库。`, 'ok');
        } else {
          setOrdersStatus('订单页已就绪，当前页已完成读取。', 'ok');
        }
      }
    }
    return info;
  } catch (e) {
    resetOrdersState();
    setPill('page-pill', '订单页上下文不可用', 'err');
    setOrdersStatus('当前标签页还没有订单同步上下文，请先打开 Etsy Sold Orders 页面。', 'err');
    return null;
  }
}

async function analyzeCurrentThread() {
  if (!state.convoId) {
    renderBuyerAnalysis();
    return null;
  }

  if (!(await ensureCloudCapabilities('中文理解'))) {
    return null;
  }

  try {
    const res = await apiFetch(`${state.apiBase}/api/messages/analyze-thread`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        convoId: state.convoId,
        shopId: state.shopId,
        buyerName: state.buyerName,
        messages: Array.isArray(state.currentThreadMessages) ? state.currentThreadMessages : []
      })
    });
    const data = await res.json();
    if (!data.ok) {
      setDraftStatus(data.error || '客户消息翻译失败。', 'err');
      return null;
    }
    state.latestBuyerMessage = data.latestBuyerMessage || state.currentPendingBuyerText || '';
    state.latestBuyerMessageZh = data.latestBuyerMessageZh || '';
    state.buyerIntentZh = data.buyerIntentZh || '';
    state.replyFocusZh = data.replyFocusZh || '';
    renderBuyerAnalysis();
    cacheCurrentThreadView();
    return data;
  } catch (e) {
    setDraftStatus('客户消息翻译失败。', 'err');
    return null;
  }
}

async function refreshContext(options = {}) {
  const { preserveDraftStatus = false } = options;
  const previousDraftKey = getCurrentDraftKey();
  const tab = await getActiveTab();
  if (!tab) {
    resetConversationMeta();
    setPill('page-pill', '没有活动标签页', 'err');
    return null;
  }

  state.currentTabId = tab.id;
  state.currentUrl = tab.url || '';
  setText('meta-url', state.currentUrl);

  if (!/^https:\/\/www\.etsy\.com\//.test(state.currentUrl)) {
    resetConversationMeta();
    state.currentUrl = tab.url || '';
    setText('meta-url', state.currentUrl);
    setPill('page-pill', '请先打开 Etsy 页面', 'err');
    setDraftStatus('先打开 Etsy 具体对话，侧边栏会自动同步当前对话。');
    return null;
  }

  try {
    const info = isMessagesUrl(state.currentUrl)
      ? await extractMessagesFromMainWorld(tab.id)
      : await sendToActiveTab({ action: 'getPageState' });
    state.shopId = info.shopId || state.shopId || '';
    state.convoId = info.convoId || '';
    state.messageCount = Number(info.messageCount || 0);
    state.pendingBuyerCount = Number(info.pendingBuyerCount || 0);
    state.currentPendingBuyerText = info.pendingBuyerText || '';
    state.hasMessageAttachments = !!info.hasAttachments;
    state.buyerName = info.buyerName || '';
    state.currentUrl = info.currentUrl || tab.url || '';
    state.lastDirection = info.lastDirection || '';
    const nextDraftKey = `${state.shopId || ''}::${state.convoId || ''}`;
    if (previousDraftKey !== nextDraftKey) {
      clearBaseDraft();
      clearReplyDraft();
      document.getElementById('rewrite-input').value = '';
      state.lastSellerIntent = '';
      state.latestBuyerMessage = '';
      state.latestBuyerMessageZh = '';
      state.buyerIntentZh = '';
      state.replyFocusZh = '';
      state.currentPendingBuyerText = '';
      state.currentThreadMessages = [];
      renderBuyerAnalysis();
    }
    renderConversationMeta();
    hydrateBuyerMessageFromContext({ force: previousDraftKey !== nextDraftKey });

    if (isStaleContentScript(info)) {
      handleStaleContentScript(info);
      return info;
    }

    if (!info.isMessagesPage) {
      setPill('page-pill', '当前不是消息对话页', 'neutral');
      setDraftStatus('先进入 Etsy Messages 并打开一个具体对话，侧边栏会自动同步。');
      return info;
    }

    if (!info.convoId) {
      setPill('page-pill', '已打开消息页，请点开具体对话', 'neutral');
      setDraftStatus('先点开具体对话，侧边栏会自动同步并生成回复。');
      return info;
    }

    const attachmentSuffix = info.hasAttachments ? ' | 含图片/链接' : '';
    setPill(
      'page-pill',
      `对话就绪 | ${info.messageCount || 0} 条记录 | 待回复 ${info.pendingBuyerCount || 0} 条${attachmentSuffix}`,
      'ok'
    );
    if (!preserveDraftStatus) {
      setDraftStatus('');
    }
    await restoreDraftForCurrentThread();
    return info;
  } catch (e) {
    resetConversationMeta();
    state.currentUrl = tab.url || '';
    setText('meta-url', state.currentUrl);
    setPill('page-pill', '当前标签页未注入 Etsy 助手', 'err');
    setDraftStatus('当前标签页还没有 Etsy 消息助手上下文，请先打开 Etsy 对话页。');
    return null;
  }
}

async function generateReply() {
  if (!state.convoId) {
    setDraftStatus('请先同步当前对话。', 'err');
    return false;
  }

  if (!(await ensureCloudCapabilities('AI 回复生成'))) {
    return false;
  }

  setBusy('regenerate', true, '生成中...');
  setDraftStatus('正在生成基础草稿...', 'neutral');
  try {
    const res = await apiFetch(`${state.apiBase}/api/messages/generate-reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        convoId: state.convoId,
        shopId: state.shopId,
        buyerName: state.buyerName,
        messages: Array.isArray(state.currentThreadMessages) ? state.currentThreadMessages : []
      })
    });
    const data = await res.json();
    if (!data.reply) {
      setDraftStatus(data.error || '自动生成草稿失败。', 'err');
      return false;
    }
    setBaseDraftFields(data.reply || '', data.replyZh || '');
    setReplyFields(data.reply || '', data.replyZh || '');
    cacheCurrentThreadView();
    setDraftStatus('基础草稿已生成。下面的“当前最终回复”会在此基础上继续融合你的补充意见。', 'ok');
    return true;
  } catch (e) {
    setDraftStatus('自动生成草稿失败。', 'err');
    return false;
  } finally {
    setBusy('regenerate', false);
  }
}

async function refineReply(instruction) {
  const currentReply = getReplyText();
  if (!state.convoId || !currentReply) {
    setDraftStatus('请先有一个草稿，再做细调。', 'err');
    return;
  }

  if (!(await ensureCloudCapabilities('AI 草稿细调'))) {
    return;
  }

  state.lastSellerIntent = String(instruction || '').trim();
  setDraftStatus('正在根据你的意见细调草稿...', 'neutral');
  try {
    const res = await apiFetch(`${state.apiBase}/api/messages/refine-reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        convoId: state.convoId,
        shopId: state.shopId,
        buyerName: state.buyerName,
        currentReply,
        instruction,
        messages: Array.isArray(state.currentThreadMessages) ? state.currentThreadMessages : []
      })
    });
    const data = await res.json();
    if (!data.reply) {
      setDraftStatus(data.error || '细调草稿失败。', 'err');
      return;
    }
    setReplyFields(data.reply || '', data.replyZh || '');
    cacheCurrentThreadView();
    setDraftStatus('已在基础草稿上融合你的补充意见。', 'ok');
  } catch (e) {
    setDraftStatus('细调草稿失败。', 'err');
  }
}

async function generateFromIntent(intent, currentReply = '') {
  if (!intent) {
    setDraftStatus('请先输入你的中文意思或修改意见。', 'err');
    return false;
  }
  if (!state.convoId) {
    setDraftStatus('请先同步当前对话，再根据你的意思改写。', 'err');
    return false;
  }

  if (!(await ensureCloudCapabilities('按中文意思生成回复'))) {
    return false;
  }

  const hasExistingReply = Boolean(cleanReplyDraftText(currentReply || getReplyText() || state.baseReply, 'en'));
  state.lastSellerIntent = String(intent || '').trim();
  setDraftStatus(
    hasExistingReply
      ? '正在把你的补充意见融合进当前回复...'
      : '正在根据上下文和你的中文意思生成回复...',
    'neutral'
  );
  try {
    const res = await apiFetch(`${state.apiBase}/api/messages/complete-reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        convoId: state.convoId,
        shopId: state.shopId,
        buyerName: state.buyerName,
        intent,
        currentReply: cleanReplyDraftText(currentReply || getReplyText() || state.baseReply, 'en'),
        messages: Array.isArray(state.currentThreadMessages) ? state.currentThreadMessages : []
      })
    });
    const data = await res.json();
    if (!data.reply) {
      setDraftStatus(data.error || '按你的中文意思生成失败。', 'err');
      return false;
    }
    setReplyFields(data.reply || '', data.replyZh || '');
    cacheCurrentThreadView();
    setDraftStatus(
      hasExistingReply
        ? '已重构当前回复，并融合你的补充意见。'
        : '已根据上下文和你的中文意思生成可发送回复。',
      'ok'
    );
    return true;
  } catch (e) {
    setDraftStatus('按你的中文意思生成失败。', 'err');
    return false;
  }
}

async function syncCurrentThread(options = {}) {
  const {
    auto = false,
    preserveRewrite = false,
    preserveDraft = false,
    generateDraft = true,
    busyButtonId = 'sync-current'
  } = options;
  const previousThreadKey = getCurrentDraftKey();
  if (state.threadSyncBusy) return false;
  state.threadSyncBusy = true;
  setBusy(busyButtonId, true, auto ? '自动同步中...' : (generateDraft ? '同步中...' : '刷新中...'));
  if (!preserveRewrite && previousThreadKey) {
    await clearPersistedDraftForCurrentThread();
  }
  if (!preserveDraft) {
    clearBaseDraft();
    clearReplyDraft();
  }
  if (!preserveRewrite) {
    document.getElementById('rewrite-input').value = '';
    state.lastSellerIntent = '';
  }
  if (!preserveDraft || !preserveRewrite) {
    scheduleDraftPersist();
  }
  setDraftStatus(
    auto
      ? '检测到当前对话变化，正在自动同步并理解...'
      : (generateDraft ? '正在同步并理解当前对话...' : '正在刷新当前对话内容...'),
    'neutral'
  );

  try {
    const tab = await getActiveTab();
    const currentUrl = tab?.url || state.currentUrl || '';
    const cloudReady = await refreshLicenseStatus({ silent: true });
    const result = isMessagesUrl(currentUrl)
      ? await (async () => {
          if (!tab?.id) {
            return { ok: false, error: 'No active Etsy tab.' };
          }
          const extracted = await extractMessagesFromMainWorld(tab.id);
          if (!extracted?.isMessagesPage || !extracted?.convoId) {
            return { ok: false, error: 'Open a specific Etsy conversation first.' };
          }
          if (!cloudReady) {
            return {
              ok: true,
              syncOk: false,
              syncError: '当前设备未激活授权，云端同步不可用。',
              safeMode: true,
              extensionVersion: EXTENSION_VERSION,
              buildFingerprint: BUILD_FINGERPRINT,
              convoId: extracted.convoId,
              shopId: extracted.shopId || state.shopId || '',
              buyerName: extracted.buyerName || '',
              messageCount: Number(extracted.messageCount || 0),
              pendingBuyerCount: Number(extracted.pendingBuyerCount || 0),
              pendingBuyerText: extracted.pendingBuyerText || '',
              hasAttachments: !!extracted.hasAttachments,
              lastDirection: extracted.lastDirection || '',
              needsReply: Number(extracted.pendingBuyerCount || 0) > 0,
              messages: Array.isArray(extracted.messages) ? extracted.messages : [],
              notification: null
            };
          }
          const syncRes = await apiFetch(`${state.apiBase}/api/messages/sync`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              convoId: extracted.convoId,
              buyerName: extracted.buyerName || '',
              messages: Array.isArray(extracted.messages) ? extracted.messages : [],
              messageCount: extracted.messageCount || 0,
              lastDirection: extracted.lastDirection || '',
              pendingBuyerCount: extracted.pendingBuyerCount || 0,
              hasAttachments: !!extracted.hasAttachments,
              shopId: extracted.shopId || state.shopId || '',
              url: extracted.currentUrl || currentUrl,
              syncedAt: new Date().toISOString()
            })
          });
          const syncPayload = await syncRes.json().catch(() => ({}));
          return {
            ok: true,
            syncOk: !!(syncRes.ok && syncPayload?.ok),
            syncError: syncRes.ok && syncPayload?.ok ? '' : (syncPayload?.error || '同步失败。'),
            safeMode: true,
            extensionVersion: EXTENSION_VERSION,
            buildFingerprint: BUILD_FINGERPRINT,
            convoId: extracted.convoId,
            shopId: extracted.shopId || state.shopId || '',
            buyerName: extracted.buyerName || '',
            messageCount: Number(extracted.messageCount || 0),
            pendingBuyerCount: Number(extracted.pendingBuyerCount || 0),
            pendingBuyerText: extracted.pendingBuyerText || '',
            hasAttachments: !!extracted.hasAttachments,
            lastDirection: extracted.lastDirection || '',
            needsReply: Number(extracted.pendingBuyerCount || 0) > 0,
            messages: Array.isArray(extracted.messages) ? extracted.messages : [],
            notification: syncPayload?.notification || null
          };
        })()
      : await sendToActiveTab({ action: 'syncCurrentThread' });
    if (!result?.ok) {
      setDraftStatus(result?.error || '同步失败。', 'err');
      return false;
    }

    if (isStaleContentScript(result)) {
      handleStaleContentScript(result);
      return false;
    }

    state.convoId = result.convoId || '';
    state.shopId = result.shopId || '';
    state.buyerName = result.buyerName || '';
    state.messageCount = Number(result.messageCount || 0);
    state.pendingBuyerCount = Number(result.pendingBuyerCount || 0);
    state.currentPendingBuyerText = result.pendingBuyerText || '';
    state.currentThreadMessages = Array.isArray(result.messages) ? result.messages : [];
    state.hasMessageAttachments = !!result.hasAttachments;
    state.lastDirection = result.lastDirection || '';
    const nextThreadKey = buildMessageThreadKey(result);
    if (preserveDraft && previousThreadKey && nextThreadKey && previousThreadKey !== nextThreadKey) {
      clearBaseDraft();
      clearReplyDraft();
      document.getElementById('rewrite-input').value = '';
      state.lastSellerIntent = '';
      scheduleDraftPersist();
    }
    renderConversationMeta();
    if (state.currentPendingBuyerText) {
      state.latestBuyerMessage = state.currentPendingBuyerText;
      renderBuyerAnalysis();
    }
    const analysis = await analyzeCurrentThread();
    const hasBuyerMessage = Boolean(analysis?.latestBuyerMessage || state.latestBuyerMessage || state.currentPendingBuyerText);
    const autoKey = buildMessageAutoKey(result);

    if (!cloudReady) {
      cacheCurrentThreadView(autoKey);
      setSystemPanelOpen(true);
      setMessagesLogOpen(true);
      setDraftStatus('已读取当前对话，但当前设备未激活授权，所以中文理解、AI 回复和飞书同步都不会执行。请先在“设置 / 授权 / 状态”里激活授权。', 'err');
      return true;
    }

    if (!hasBuyerMessage) {
      cacheCurrentThreadView(autoKey);
      setDraftStatus(
        auto
          ? '当前对话已自动同步，但暂时没有需要回复的买家消息。'
          : (generateDraft
            ? '已同步，但当前没有可用于生成回复的买家消息。'
            : '已刷新当前对话内容，当前没有新的待回复买家消息。'),
        'neutral'
      );
      return true;
    }

    if (!generateDraft) {
      cacheCurrentThreadView(autoKey);
      const syncSuffix = result?.syncOk === false ? ` 后台同步失败：${result.syncError || 'unknown error'}` : '';
      const notifySuffix = result?.notification?.ok === false
        ? ` 群提醒失败：${result.notification.error || 'unknown error'}`
        : '';
      setDraftStatus(
        `已刷新当前对话内容。买家原文和中文理解已更新，当前草稿已保留。${syncSuffix}${notifySuffix}`.trim(),
        (syncSuffix || notifySuffix) ? 'neutral' : 'ok'
      );
      return true;
    }

    const generated = await generateReply();
    cacheCurrentThreadView(autoKey);
    const syncSuffix = result?.syncOk === false ? ` 后台同步失败：${result.syncError || 'unknown error'}` : '';
    const notifySuffix = result?.notification?.ok === false
      ? ` 群提醒失败：${result.notification.error || 'unknown error'}`
      : '';
    if (generated && auto) {
      setDraftStatus(
        `当前对话已自动同步，并生成了最新草稿。${syncSuffix}${notifySuffix}`.trim(),
        (syncSuffix || notifySuffix) ? 'neutral' : 'ok'
      );
    } else if (generated) {
      setDraftStatus(
        `基础草稿已生成。${syncSuffix}${notifySuffix}`.trim(),
        (syncSuffix || notifySuffix) ? 'neutral' : 'ok'
      );
    }
    return generated;
  } catch (e) {
    setDraftStatus(
      generateDraft
        ? '同步失败，请确认当前标签页是 Etsy 的具体对话页。'
        : '刷新失败，请确认当前标签页是 Etsy 的具体对话页。',
      'err'
    );
    return false;
  } finally {
    setBusy(busyButtonId, false);
    state.threadSyncBusy = false;
    await refreshContext({ preserveDraftStatus: true });
  }
}

async function refreshCurrentThreadContent() {
  const preserveDraft = Boolean(state.baseReply || getReplyText());
  const preserveRewrite = preserveDraft || Boolean(getRewriteInstruction());
  return syncCurrentThread({
    auto: false,
    preserveDraft,
    preserveRewrite,
    generateDraft: false,
    busyButtonId: 'refresh-context'
  });
}

async function rewriteReplyFromInput() {
  const instruction = getRewriteInstruction();
  if (!instruction) {
    setDraftStatus('请先输入你的中文意思或修改意见。', 'err');
    return;
  }
  if (!state.convoId) {
    setDraftStatus('请先同步当前对话，再继续改写。', 'err');
    return;
  }

  setBusy('rewrite-submit', true, '改写中...');
  try {
    const generated = await generateFromIntent(instruction, getReplyText() || state.baseReply || '');
    if (!generated) return;

    document.getElementById('rewrite-input').value = '';
    scheduleDraftPersist();
  } finally {
    setBusy('rewrite-submit', false);
  }
}

async function fillDraft() {
  const reply = cleanReplyDraftText(getReplyText(), 'en');
  if (!reply) {
    setDraftStatus('还没有可填入的草稿。', 'err');
    return;
  }
  try {
    document.getElementById('reply-en').value = reply;
    const result = await sendToActiveTab({ action: 'fillReplyBox', text: reply });
    if (!result?.ok) {
      setDraftStatus(result?.error || '填入回复框失败。', 'err');
      return;
    }
    setDraftStatus('草稿已填入 Etsy 回复框。请人工检查后再点击 Send。', 'ok');
    saveCurrentMessageCaseMemory('fill_confirm').catch((error) => {
      console.warn('[ASM] save private case failed', error);
    });
  } catch (e) {
    setDraftStatus('填入回复框失败，请先打开 Etsy 对话页。', 'err');
  }
}

async function saveCurrentMessageCaseMemory(sourceEvent = 'fill_confirm') {
  const finalReply = cleanReplyDraftText(getReplyText(), 'en');
  if (!state.convoId || !state.shopId || !finalReply) return false;

  const payload = {
    convoId: state.convoId,
    shopId: state.shopId,
    buyerName: state.buyerName || '',
    sourceUrl: state.currentUrl || '',
    latestBuyerMessage: state.latestBuyerMessage || '',
    latestBuyerMessageZh: state.latestBuyerMessageZh || '',
    buyerIntentZh: state.buyerIntentZh || '',
    replyFocusZh: state.replyFocusZh || '',
    sellerIntent: state.lastSellerIntent || '',
    baseReply: state.baseReply || '',
    baseReplyZh: state.baseReplyZh || '',
    finalReply,
    finalReplyZh: cleanReplyDraftText(getReplyZhText(), 'zh'),
    pendingBuyerCount: Number(state.pendingBuyerCount || 0),
    messageCount: Number(state.messageCount || 0),
    sourceEvent
  };

  const res = await apiFetch(`${state.apiBase}/api/messages/case-library`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  return res.ok;
}

function restoreBaseDraftIntoWorkingDraft() {
  if (!state.baseReply) {
    setDraftStatus('还没有基础草稿可恢复。', 'err');
    return;
  }
  setReplyFields(state.baseReply, state.baseReplyZh);
  setDraftStatus('已恢复基础 AI 草稿。你可以重新补充意见再融合。', 'ok');
}

async function syncCurrentOrders(options = {}) {
  const { auto = false } = options;
  if (state.orderSyncBusy) return false;
  state.orderSyncBusy = true;
  setBusy('sync-orders-current', true, auto ? '自动同步中...' : '同步中...');
  renderOrderSyncButton();
  setOrdersStatus(
    auto ? '正在读取当前订单页并同步...' : '正在读取当前订单页并同步...',
    'neutral'
  );
  try {
    const tab = await getActiveTab();
    const currentUrl = tab?.url || '';
    if (!isOrdersUrl(currentUrl)) {
      setOrdersStatus('请先打开 Etsy Sold Orders 页面。', 'err');
      return false;
    }

    const extracted = await extractOrdersFromMainWorld(tab.id, 3);
    if (extracted.error || !Array.isArray(extracted.orders) || extracted.orders.length === 0) {
      const shopLabel = extracted.shopName ? ` | 店铺 ${extracted.shopName}` : '';
      const extractor = extracted.extractor ? ` | ${extracted.extractor}` : '';
      setOrdersStatus(`${extracted.error || '当前页未提取到订单'}${shopLabel}${extractor}`, 'err');
      return false;
    }

    const result = await apiFetch(`${state.apiBase}/api/orders/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        shopId: extracted.shopName,
        orders: extracted.orders
      })
    }).then(async (res) => {
      const data = await res.json();
      if (!res.ok) {
        return {
          ok: false,
          error: data?.error || '订单同步请求失败',
          diagnostics: {
            extractor: extracted.extractor || 'main-world-v2',
            shopId: extracted.shopName || '',
            ordersFound: extracted.orders.length
          }
        };
      }
      return {
        ...data,
        ok: true,
        diagnostics: {
          extractor: extracted.extractor || 'main-world-v2',
          shopId: extracted.shopName || '',
          ordersFound: extracted.orders.length
        }
      };
    });
    if (!result?.ok) {
      const extractor = result?.diagnostics?.extractor ? ` | ${result.diagnostics.extractor}` : '';
      const shopLabel = result?.diagnostics?.shopId ? ` | 店铺 ${result.diagnostics.shopId}` : '';
      setOrdersStatus(`${result?.error || '订单同步失败。'}${shopLabel}${extractor}`, 'err');
      return false;
    }

    renderOrderSyncResult({
      total: result.total ?? result.ordersCount ?? 0,
      added: result.added ?? 0,
      updated: result.updated ?? 0,
      syncedAt: new Date().toISOString()
    });

    state.orderCount = Number(result.total || state.orderCount || 0);
    renderOrdersMeta();
    const feishuAdded = result.feishu?.added ?? 0;
    const notifySent = result.feishu?.notifications?.sentCount ?? 0;
    const notifySkipped = result.feishu?.notifications?.skippedCount ?? 0;
    const notifyFailed = result.feishu?.notifications?.failedCount ?? 0;
    const notifyMessage = notifySent > 0
      ? `群提醒已发送 ${notifySent} 条。`
      : (notifyFailed > 0
        ? `群提醒失败 ${notifyFailed} 条。`
        : (notifySkipped > 0 ? `群提醒跳过 ${notifySkipped} 条。` : ''));
    const feishuMessage = result.feishu?.ok
      ? `飞书新增 ${feishuAdded} 单。 ${notifyMessage}`.trim()
      : (result.feishu?.error ? `飞书未写入：${result.feishu.error}` : '本次只同步到后台总表。');
    setOrdersStatus(
      `订单同步完成：抓取 ${result.total ?? 0} 单，新增 ${result.added ?? 0} 单，更新 ${result.updated ?? 0} 单。${feishuMessage}`,
      result.feishu?.ok && notifyFailed === 0 ? 'ok' : 'neutral'
    );
    await refreshOrdersContext({ preserveStatus: true });
    return true;
  } catch (e) {
    setOrdersStatus('订单同步失败，请确认当前标签页是 Etsy Sold Orders 页面。', 'err');
    return false;
  } finally {
    setBusy('sync-orders-current', false);
    state.orderSyncBusy = false;
    renderOrderSyncButton();
  }
}

async function autoSyncCurrentThread(options = {}) {
  const { force = false } = options;
  const info = await refreshContext({ preserveDraftStatus: true });
  if (!info?.isMessagesPage || !info?.convoId) return false;

  const threadKey = buildMessageThreadKey(info);
  const nextAutoKey = buildMessageAutoKey(info);
  const cached = state.messageThreadCache[threadKey];
  const livePendingText = String(info.pendingBuyerText || '').trim();
  const cachedPendingText = String(cached?.latestBuyerMessage || '').trim();
  if (!force && cached && cached.autoKey === nextAutoKey && (!livePendingText || cachedPendingText === livePendingText)) {
    restoreCachedThreadView(cached);
    return false;
  }

  const previousAutoKey = state.lastMessageAutoKey;
  state.lastMessageAutoKey = nextAutoKey;
  const preserveRewrite = threadKey === getCurrentDraftKey() && Boolean(getRewriteInstruction());
  const synced = await syncCurrentThread({ auto: true, preserveRewrite });
  if (!synced) {
    state.lastMessageAutoKey = previousAutoKey;
  }
  return synced;
}

async function autoSyncCurrentOrders(options = {}) {
  const { force = false } = options;
  const info = await refreshOrdersContext({ preserveStatus: true });
  if (!info?.isOrdersPage) return false;

  const nextAutoKey = buildOrderAutoKey({
    ...info,
    orderIds: state.orderVisibleOrderIds
  });
  if (!force && nextAutoKey && state.lastOrderAutoKey === nextAutoKey) {
    return false;
  }
  state.lastOrderAutoKey = nextAutoKey;

  if (state.orderCompareState === 'has-new') {
    setOrdersStatus(
      `当前页已自动比对。当前页共 ${state.orderCount} 单，其中新订单 ${state.orderNewOrderIds.length} 单，已入库 ${Math.max(state.orderCount - state.orderNewOrderIds.length, 0)} 单。`,
      'neutral'
    );
  } else if (state.orderCompareState === 'known') {
    setOrdersStatus(`当前页已自动比对。当前页共 ${state.orderCount} 单，已全部入库。`, 'ok');
  }
  return true;
}

async function autoSyncCurrentPricing(options = {}) {
  const { force = false } = options;
  const info = await refreshPricingContext({ preserveStatus: true, forceHydrate: force });
  if (!info?.isPricingPage) return false;

  const nextAutoKey = buildPricingAutoKey(info);
  if (!force && nextAutoKey && state.lastPricingAutoKey === nextAutoKey) {
    return false;
  }
  state.lastPricingAutoKey = nextAutoKey;

  if (info.currentPrice > 0) {
    setPricingStatus(`当前 listing 已自动读取：${info.title || info.listingId}。若你刚切换了商品，旧计算会自动失效。现在可以直接填入成本开始计算。`, 'ok');
  } else {
    setPricingStatus('当前 listing 已读取，但价格尚未完全识别，必要时可手动修正后再计算。', 'neutral');
  }
  return true;
}

async function refreshResearchContext(options = {}) {
  const { preserveStatus = false } = options;
  if (!preserveStatus) {
    setPill('page-pill', '研究页读取中...', 'neutral');
    setResearchStatus('正在读取当前研究页面...', 'neutral');
  }
  const tab = await getActiveTab();
  if (!tab) {
    resetResearchState();
    setPill('page-pill', '没有活动标签页', 'err');
    setResearchStatus('没有活动标签页。', 'err');
    return null;
  }

  state.currentTabId = tab.id;
  state.currentUrl = tab.url || '';
  setText('meta-url', state.currentUrl);

  if (!/^https:\/\/www\.etsy\.com\//.test(state.currentUrl)) {
    resetResearchState();
    setPill('page-pill', '请先打开 Etsy 页面', 'err');
    setResearchStatus('先打开 Etsy 店铺统计页或搜索结果页。', 'err');
    return null;
  }

  const mayBePrivateAnalyticsPage = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?your\//i.test(state.currentUrl) && !isMessagesUrl(state.currentUrl) && !isOrdersUrl(state.currentUrl);
  if (!isMarketResearchUrl(state.currentUrl) && !isShopAnalyticsUrl(state.currentUrl) && !mayBePrivateAnalyticsPage) {
    resetResearchState();
    setPill('page-pill', '请先打开研究页', 'neutral');
    setResearchStatus(
      state.researchMode === 'market'
        ? '当前不是 Etsy 搜索结果页。请先打开搜索结果页。'
        : '当前不是 Etsy 店铺统计页。请先打开店铺后台统计相关页面。',
      'neutral'
    );
    return {
      ok: true,
      isResearchPage: false,
      currentUrl: state.currentUrl
    };
  }

  try {
    const info = await sendToActiveTab({ action: 'getResearchPageState' });
    const pageType = info?.pageType || '';
    if (!info?.ok || !info?.isResearchPage || !pageType) {
      resetResearchState();
      setPill('page-pill', '研究页上下文不可用', 'err');
      setResearchStatus('当前研究页面还没有可用上下文，请稍后重试。', 'err');
      return info || null;
    }

    setResearchMode(pageType === 'market_search' ? 'market' : 'shop');
    state.researchPageReady = true;
    state.researchPageType = pageType;
    state.researchSubPageType = info.subPageType || '';
    state.researchCurrentUrl = info.pageUrl || tab.url || '';
    state.researchPageTitle = info.pageTitle || '';
    state.researchKeyword = info.keyword || '';
    state.researchShopId = info.shopId || '';
    state.researchShopName = info.shopName || '';
    state.researchDateRangeLabel = info.dateRangeLabel || '';
    state.researchSampleCount = Array.isArray(info.cards)
      ? info.cards.length
      : (Array.isArray(info.rows) ? info.rows.length : Number(info.sampleCount || 0));
    state.researchSummaryText = String(info.summaryText || '').trim();
    state.researchExtractor = info.extractor || '';
    state.researchDiagnostics = info.diagnostics || {};

    if (pageType === 'market_search') {
      const topCards = (Array.isArray(info.cards) ? info.cards : [])
        .slice(0, 5)
        .map((card) => {
          const priceText = card?.priceCurrent?.rawText || card?.priceCurrent?.amount || '-';
          return `#${card.position || '-'} ${card.title || card.listingId || 'Untitled'} | ${priceText} | 评价 ${card.reviewCount || '-'}`;
        });
      state.researchRawSignals = [
        `页面类型: 搜索结果页`,
        `关键词: ${state.researchKeyword || '-'}`,
        `结果数: ${info.resultCountHint || '-'}`,
        `排序: ${info.sortModeHint || '-'}`,
        `提取器: ${state.researchExtractor || '-'}`,
        '',
        ...topCards
      ].join('\n');
      setPill('page-pill', `研究页就绪 | 搜索页 | ${state.researchSampleCount || 0} 个样本`, 'ok');
      if (!preserveStatus) {
        setResearchStatus(`已读取当前搜索结果页，先拿到了 ${state.researchSampleCount || 0} 个样本。接下来建议你再打开 3-5 个代表性 listing。`, 'ok');
      }
    } else {
      const metricHints = Object.entries(state.researchDiagnostics.metricHints || {})
        .filter(([, enabled]) => !!enabled)
        .map(([key]) => key);
      state.researchRawSignals = [
        `页面类型: 店铺统计页`,
        `子类型: ${state.researchSubPageType || '-'}`,
        `店铺: ${state.researchShopName || '-'}`,
        `时间范围: ${state.researchDateRangeLabel || '-'}`,
        `提取器: ${state.researchExtractor || '-'}`,
        `识别到的指标线索: ${metricHints.join(', ') || '暂无'}`,
        '',
        state.researchSummaryText || ''
      ].join('\n');
      setPill('page-pill', `研究页就绪 | ${state.researchSubPageType || 'overview'} | ${state.researchExtractor || 'shop-analytics'}`, 'ok');
      if (!preserveStatus) {
        setResearchStatus(`已识别当前店铺统计页。后续继续打开 listing / 流量来源 / 广告页，就能逐步拼成一次完整诊断。`, 'ok');
      }
    }

    renderResearchContext(info);
    return info;
  } catch (e) {
    resetResearchState();
    setPill('page-pill', '研究页上下文不可用', 'err');
    setResearchStatus('当前标签页还没有研究模块上下文，请先打开 Etsy 搜索结果页或店铺统计页。', 'err');
    return null;
  }
}

async function autoSyncCurrentResearch(options = {}) {
  const { force = false } = options;
  const info = await refreshResearchContext({ preserveStatus: true });
  if (!info?.isResearchPage || !info?.pageType) return false;

  const nextAutoKey = buildResearchAutoKey(info);
  if (!force && nextAutoKey && state.lastResearchAutoKey === nextAutoKey) {
    return false;
  }
  state.lastResearchAutoKey = nextAutoKey;

  if (info.pageType === 'market_search') {
    await persistMarketResearchSnapshot(info, { quiet: true });
    setResearchStatus(`当前搜索结果页已自动读取，识别到 ${state.researchSampleCount || 0} 个样本。`, 'ok');
  } else {
    setResearchStatus(`当前店铺统计页已自动读取：${state.researchSubPageType || 'overview'}。`, 'ok');
  }
  return true;
}

async function syncVisibleContext(options = {}) {
  const { force = false, respectSelectedModule = false } = options;
  if (document.hidden && !force) return false;

  const tab = await getActiveTab();
  const detectedModule = detectModuleFromUrl(tab?.url || '');
  if (!respectSelectedModule && detectedModule && detectedModule !== state.activeModule) {
    await setActiveModule(detectedModule);
  }

  const targetModule = respectSelectedModule ? state.activeModule : (detectedModule || state.activeModule);

  if (!respectSelectedModule && detectedModule === 'orders') {
    return autoSyncCurrentOrders({ force });
  }

  if (!respectSelectedModule && detectedModule === 'pricing') {
    return autoSyncCurrentPricing({ force });
  }

  if (!respectSelectedModule && detectedModule === 'research') {
    return autoSyncCurrentResearch({ force });
  }

  if (!respectSelectedModule && detectedModule === 'messages') {
    return autoSyncCurrentThread({ force });
  }

  if (targetModule === 'orders') {
    if (detectedModule === 'orders') {
      return autoSyncCurrentOrders({ force });
    }
    await refreshOrdersContext();
    return false;
  }

  if (targetModule === 'pricing') {
    if (detectedModule === 'pricing') {
      return autoSyncCurrentPricing({ force });
    }
    await refreshPricingContext();
    return false;
  }

  if (targetModule === 'research') {
    if (detectedModule === 'research') {
      return autoSyncCurrentResearch({ force });
    }
    await refreshResearchContext();
    return false;
  }

  if (targetModule === 'messages') {
    if (detectedModule === 'messages') {
      return autoSyncCurrentThread({ force });
    }
    await refreshContext();
    return false;
  }

  await refreshContext();
  return false;
}

function queueAutoSync(reason = 'context', options = {}) {
  const { force = false, delay = AUTO_SYNC_DELAY_MS } = options;
  if (autoSyncTimer) clearTimeout(autoSyncTimer);
  autoSyncTimer = setTimeout(() => {
    autoSyncTimer = null;
    syncVisibleContext({ force, reason }).catch(() => {});
  }, delay);
}

function startTabContextWatcher() {
  if (tabContextWatchTimer) return;
  tabContextWatchTimer = setInterval(async () => {
    try {
      if (document.hidden) return;
      const tab = await getActiveTab();
      const currentUrl = String(tab?.url || '');
      if (!currentUrl || currentUrl === 'chrome://newtab/') return;
      const currentConvoId = extractConvoIdFromUrl(currentUrl);
      const previousConvoId = extractConvoIdFromUrl(lastWatchedTabUrl);
      const urlChanged = currentUrl !== lastWatchedTabUrl;
      const convoChanged = currentConvoId && currentConvoId !== previousConvoId;
      lastWatchedTabUrl = currentUrl;
      if (urlChanged || (state.activeModule === 'messages' && convoChanged && currentConvoId !== state.convoId)) {
        queueAutoSync('tab-context-watch', { force: true, delay: 80 });
      }
    } catch (error) {}
  }, 900);
}

function schedulePricingFollowUpSync(reason = 'pricing-follow-up', delay = 1100) {
  if (pricingFollowUpTimer) clearTimeout(pricingFollowUpTimer);
  pricingFollowUpTimer = setTimeout(() => {
    pricingFollowUpTimer = null;
    syncVisibleContext({ force: true, reason }).catch(() => {});
  }, delay);
}

function editOrderConfig() {
  if (!state.orderShopId) return;
  state.orderConfigEditorVisible = true;
  setOrdersConfigPanelOpen(true);
  renderOrderConfig();
}

async function handlePrimarySync() {
  if (state.activeModule === 'orders') {
    await syncCurrentOrders({ auto: false });
    return;
  }
  if (state.activeModule === 'pricing') {
    setBusy('sync-current', true, '读取中...');
    try {
      await refreshPricingContext({ forceHydrate: true });
    } finally {
      setBusy('sync-current', false);
    }
    return;
  }
  if (state.activeModule === 'research') {
    setBusy('sync-current', true, '读取中...');
    try {
      await refreshResearchContext();
    } finally {
      setBusy('sync-current', false);
    }
    return;
  }
  await syncCurrentThread({ auto: false });
}

function bindPanelVisibilityEvents() {
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) return;
    queueAutoSync('panel-visible', { force: false, delay: 120 });
  });

  window.addEventListener('focus', () => {
    queueAutoSync('panel-focus', { force: false, delay: 120 });
  });
}

function bindAutoContextEvents() {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.action !== 'etsyContextChanged') return false;

    const senderUrl = msg.currentUrl || sender?.tab?.url || '';
    const senderModule = msg.pageType || detectModuleFromUrl(senderUrl);
    if (sender?.tab && sender.tab.active === false) return false;

    if (senderModule === 'shop_analytics' || senderModule === 'market_search') {
      setResearchMode(senderModule === 'market_search' ? 'market' : 'shop');
      setActiveModule('research').catch(() => {});
    }

    const delay = senderModule === 'orders' ? 220 : AUTO_SYNC_DELAY_MS;
    queueAutoSync(`etsy-context-changed:${senderModule || 'other'}`, { force: false, delay });
    if (typeof sendResponse === 'function') {
      sendResponse({ ok: true });
    }
    return false;
  });
}

function bindPricingTabWatchers() {
  chrome.tabs.onActivated.addListener(async () => {
    const tab = await getActiveTab();
    if (!isPricingUrl(tab?.url || '')) return;
    queueAutoSync('pricing-tab-activated', { force: true, delay: 220 });
    schedulePricingFollowUpSync('pricing-tab-activated-follow-up', 950);
  });

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const currentUrl = changeInfo.url || tab?.url || '';
    if (!tab?.active || !isPricingUrl(currentUrl)) return;
    if (changeInfo.status === 'complete' || changeInfo.url) {
      state.lastPricingAutoKey = '';
      queueAutoSync('pricing-tab-updated', { force: true, delay: 260 });
      schedulePricingFollowUpSync('pricing-tab-updated-follow-up', 1200);
    }
  });
}

function bindEvents() {
  document.getElementById('open-system-panel')?.addEventListener('click', () => openSystemPanel({ focusLicense: true }));
  document.getElementById('hero-license-chip')?.addEventListener('click', () => openSystemPanel({ focusLicense: state.licenseStatus !== 'active' && state.licenseStatus !== 'trial' }));
  document.getElementById('toggle-collapse').addEventListener('click', () => {
    setCollapsed(!state.collapsed).catch(() => {});
  });
  document.querySelectorAll('.module-tab').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const module = ['messages', 'orders', 'pricing', 'research'].includes(btn.dataset.module) ? btn.dataset.module : 'messages';
      await setActiveModule(module);
      await syncVisibleContext({ force: true, reason: 'manual-module-switch', respectSelectedModule: true });
    });
  });
  document.querySelectorAll('[data-research-mode]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      setResearchMode(btn.dataset.researchMode);
      if (state.activeModule === 'research') {
        await refreshResearchContext();
      }
    });
  });
  document.getElementById('api-mode')?.addEventListener('change', saveApiMode);
  document.getElementById('save-license')?.addEventListener('click', saveLicenseKey);
  document.getElementById('refresh-license')?.addEventListener('click', () => refreshLicenseStatus());
  document.getElementById('refresh-service')?.addEventListener('click', testConnection);
  document.getElementById('refresh-context').addEventListener('click', refreshCurrentThreadContent);
  document.getElementById('refresh-orders-context').addEventListener('click', () => refreshOrdersContext());
  document.getElementById('refresh-pricing-context')?.addEventListener('click', () => refreshPricingContext({ forceHydrate: true }));
  document.getElementById('refresh-research-context')?.addEventListener('click', () => refreshResearchContext());
  document.getElementById('sync-current').addEventListener('click', handlePrimarySync);
  document.getElementById('save-orders-config').addEventListener('click', saveOrderConfig);
  document.getElementById('edit-orders-config').addEventListener('click', editOrderConfig);
  document.getElementById('open-orders-link').addEventListener('click', openOrderFeishuLink);
  document.getElementById('sync-orders-current').addEventListener('click', () => syncCurrentOrders({ auto: false }));
  document.getElementById('open-pricing-dashboard')?.addEventListener('click', openPricingDashboard);
  document.getElementById('open-research-dashboard')?.addEventListener('click', openResearchDashboard);
  document.getElementById('save-pricing-config').addEventListener('click', savePricingConfig);
  document.getElementById('pricing-run-reverse').addEventListener('click', runReversePricing);
  document.getElementById('pricing-run-forward').addEventListener('click', runForwardPricing);
  document.getElementById('pricing-seller-country').addEventListener('change', syncPricingSellerCurrency);
  document.getElementById('pricing-competitor-country').addEventListener('change', renderPricingTargetMarketField);
  document.getElementById('restore-base').addEventListener('click', restoreBaseDraftIntoWorkingDraft);
  document.getElementById('rewrite-submit').addEventListener('click', rewriteReplyFromInput);
  document.getElementById('fill-draft').addEventListener('click', fillDraft);
  document.getElementById('regenerate').addEventListener('click', generateReply);
  document.getElementById('reply-en').addEventListener('input', scheduleDraftPersist);
  document.getElementById('rewrite-input').addEventListener('input', scheduleDraftPersist);
  document.querySelectorAll('[data-refine]').forEach((btn) => {
    btn.addEventListener('click', () => refineReply(btn.dataset.refine));
  });
}

async function init() {
  bindEvents();
  bindAutoContextEvents();
  bindPricingTabWatchers();
  bindPanelVisibilityEvents();
  startTabContextWatcher();
  updateResearchModeUi();
  updateBaseDraftActions();
  renderOrderSyncResult(null);
  renderOrderStats(null);
  resetOrdersState();
  resetPricingState();
  resetResearchState();
  await Promise.all([loadApiMode(), loadCollapseState(), loadActiveModuleState(), loadLicenseKey()]);
  await testConnection();
  await syncVisibleContext({ force: true, reason: 'init' });
  await refreshLicenseStatus({ silent: true });
}

init().catch(() => {
  setStatus('connection-status', '侧边栏初始化失败。', 'err');
});
