// Etsy Message Assistant - Content Script
// 注入到 https://www.etsy.com/messages* 页面

// API_BASE: cloud by default, can override via extension storage
let API_BASE = 'https://etsy-msg-hub.bangyinchao.workers.dev';
const EXTENSION_LICENSE_KEY = 'emaExtensionLicenseKey';
const EXTENSION_INSTALL_ID_KEY = 'emaExtensionInstallId';
const EXTENSION_SESSION_TOKEN_KEY = 'emaExtensionSessionToken';
const EXTENSION_SESSION_EXPIRES_AT_KEY = 'emaExtensionSessionExpiresAt';
const EXTENSION_VERSION = chrome.runtime?.getManifest?.()?.version || '0.0.0';
const BUILD_FINGERPRINT = typeof __ASM_BUILD_FINGERPRINT__ !== 'undefined' ? __ASM_BUILD_FINGERPRINT__ : 'dev-generic';
const SESSION_EXPIRY_BUFFER_MS = 90 * 1000;
let LICENSE_KEY = '';
let INSTALL_ID = '';
let SESSION_TOKEN = '';
let SESSION_EXPIRES_AT = '';
// Load saved API_BASE from storage
try {
  chrome.storage.local.get(['apiBase', EXTENSION_LICENSE_KEY, EXTENSION_INSTALL_ID_KEY, EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY], (d) => {
    if (d.apiBase) API_BASE = d.apiBase;
    if (d[EXTENSION_LICENSE_KEY]) LICENSE_KEY = String(d[EXTENSION_LICENSE_KEY]).trim();
    if (d[EXTENSION_INSTALL_ID_KEY]) INSTALL_ID = String(d[EXTENSION_INSTALL_ID_KEY]).trim();
    if (d[EXTENSION_SESSION_TOKEN_KEY]) SESSION_TOKEN = String(d[EXTENSION_SESSION_TOKEN_KEY]).trim();
    if (d[EXTENSION_SESSION_EXPIRES_AT_KEY]) SESSION_EXPIRES_AT = String(d[EXTENSION_SESSION_EXPIRES_AT_KEY]).trim();
  });
} catch(e) {}
try {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.apiBase?.newValue) {
      API_BASE = changes.apiBase.newValue;
    }
    if (areaName === 'local' && changes[EXTENSION_LICENSE_KEY]) {
      LICENSE_KEY = String(changes[EXTENSION_LICENSE_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_INSTALL_ID_KEY]) {
      INSTALL_ID = String(changes[EXTENSION_INSTALL_ID_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_SESSION_TOKEN_KEY]) {
      SESSION_TOKEN = String(changes[EXTENSION_SESSION_TOKEN_KEY].newValue || '').trim();
    }
    if (areaName === 'local' && changes[EXTENSION_SESSION_EXPIRES_AT_KEY]) {
      SESSION_EXPIRES_AT = String(changes[EXTENSION_SESSION_EXPIRES_AT_KEY].newValue || '').trim();
    }
  });
} catch (e) {}
let currentConvoId = null;
let panel = null;
let SHOP_ID = 'default';
let urlObserverInstalled = false;
let contextSignalTimer = null;
let lastContextSignalKey = '';
let panelCollapsed = false;
let sidebarLayoutInstalled = false;

// ========== 0. Auto-detect shop name ==========

function extractShopInfo() {
  return new Promise((resolve) => {
    // Inject into page world to read Etsy.Context.data (content script is isolated)
    const script = document.createElement('script');
    script.textContent = `
      (function() {
        try {
          var data = window.Etsy && window.Etsy.Context && window.Etsy.Context.data;
          var shopName = data ? data.shop_name : null;
          var shopId = data ? data.shop_id : null;
          document.dispatchEvent(new CustomEvent('__ema_shop_info', {
            detail: JSON.stringify({ shopName: shopName, shopId: shopId })
          }));
        } catch(e) {
          document.dispatchEvent(new CustomEvent('__ema_shop_info', {
            detail: JSON.stringify({ shopName: null, shopId: null })
          }));
        }
      })();
    `;

    document.addEventListener('__ema_shop_info', function handler(e) {
      document.removeEventListener('__ema_shop_info', handler);
      try {
        var info = JSON.parse(e.detail);
        if (info.shopName) {
          SHOP_ID = info.shopName;
          console.log('[EMA] Shop: ' + info.shopName + ' (id: ' + info.shopId + ')');
        }
      } catch(err) {}
      resolve();
    }, { once: true });

    document.documentElement.appendChild(script);
    script.remove();
    setTimeout(function() { resolve(); }, 2000);
  });
}

// ========== 1. Message extraction ==========

function generateInstallId() {
  if (typeof crypto?.randomUUID === 'function') {
    return `asm_${crypto.randomUUID().replace(/-/g, '')}`;
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return `asm_${Array.from(bytes).map((byte) => byte.toString(16).padStart(2, '0')).join('')}`;
}

async function ensureInstallId() {
  if (INSTALL_ID) return INSTALL_ID;
  try {
    const data = await chrome.storage.local.get(EXTENSION_INSTALL_ID_KEY);
    const saved = String(data[EXTENSION_INSTALL_ID_KEY] || '').trim();
    if (saved) {
      INSTALL_ID = saved;
      return INSTALL_ID;
    }
  } catch (e) {}

  INSTALL_ID = generateInstallId();
  try {
    await chrome.storage.local.set({ [EXTENSION_INSTALL_ID_KEY]: INSTALL_ID });
  } catch (e) {}
  return INSTALL_ID;
}

function hasUsableSessionToken() {
  if (!SESSION_TOKEN || !SESSION_EXPIRES_AT) return false;
  const expiresAtMs = Date.parse(String(SESSION_EXPIRES_AT || ''));
  return Number.isFinite(expiresAtMs) && expiresAtMs > Date.now() + SESSION_EXPIRY_BUFFER_MS;
}

async function saveSessionState(token = '', expiresAt = '') {
  SESSION_TOKEN = String(token || '').trim();
  SESSION_EXPIRES_AT = String(expiresAt || '').trim();
  try {
    await chrome.storage.local.set({
      [EXTENSION_SESSION_TOKEN_KEY]: SESSION_TOKEN,
      [EXTENSION_SESSION_EXPIRES_AT_KEY]: SESSION_EXPIRES_AT
    });
  } catch (e) {}
}

async function clearSessionState() {
  SESSION_TOKEN = '';
  SESSION_EXPIRES_AT = '';
  try {
    await chrome.storage.local.remove([EXTENSION_SESSION_TOKEN_KEY, EXTENSION_SESSION_EXPIRES_AT_KEY]);
  } catch (e) {}
}

async function getApiBase() {
  try {
    const data = await chrome.storage.local.get([
      'apiBase',
      EXTENSION_LICENSE_KEY,
      EXTENSION_INSTALL_ID_KEY,
      EXTENSION_SESSION_TOKEN_KEY,
      EXTENSION_SESSION_EXPIRES_AT_KEY
    ]);
    API_BASE = data.apiBase || API_BASE;
    LICENSE_KEY = String(data[EXTENSION_LICENSE_KEY] || LICENSE_KEY || '').trim();
    INSTALL_ID = String(data[EXTENSION_INSTALL_ID_KEY] || INSTALL_ID || '').trim();
    SESSION_TOKEN = String(data[EXTENSION_SESSION_TOKEN_KEY] || SESSION_TOKEN || '').trim();
    SESSION_EXPIRES_AT = String(data[EXTENSION_SESSION_EXPIRES_AT_KEY] || SESSION_EXPIRES_AT || '').trim();
  } catch (e) {}
  return API_BASE;
}

async function activateLicenseSession() {
  await getApiBase();
  await ensureInstallId();
  if (!LICENSE_KEY) return false;
  try {
    const res = await fetch(`${API_BASE}/api/extension/license/activate`, {
      method: 'POST',
      headers: {
        'X-ASM-License-Key': LICENSE_KEY,
        'X-ASM-Install-Id': INSTALL_ID,
        'X-ASM-Extension-Version': EXTENSION_VERSION,
        'X-ASM-Build-Fingerprint': BUILD_FINGERPRINT,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data?.ok || !data?.accessToken) {
      await clearSessionState();
      return false;
    }
    await saveSessionState(data.accessToken, data.sessionExpiresAt || '');
    return true;
  } catch (e) {
    await clearSessionState();
    return false;
  }
}

async function ensureSessionToken(options = {}) {
  const { force = false } = options;
  await getApiBase();
  await ensureInstallId();
  if (!force && hasUsableSessionToken()) return true;
  return activateLicenseSession();
}

async function apiFetch(input, init = {}) {
  const retrying = !!init.__retrying;
  await ensureSessionToken({ force: false });
  await ensureInstallId();
  const headers = new Headers(init.headers || {});
  headers.set('X-ASM-Install-Id', INSTALL_ID);
  headers.set('X-ASM-Extension-Version', EXTENSION_VERSION);
  headers.set('X-ASM-Build-Fingerprint', BUILD_FINGERPRINT);
  if (SESSION_TOKEN) {
    headers.set('X-ASM-Session-Token', SESSION_TOKEN);
  }
  const nextInit = { ...init };
  delete nextInit.__retrying;
  const response = await fetch(input, {
    ...nextInit,
    headers
  });
  if (response.status === 401 || response.status === 403) {
    try {
      const payload = await response.clone().json();
      if (!retrying && (payload?.sessionRequired || payload?.sessionInvalid || payload?.sessionExpired || payload?.installMismatch || payload?.installInvalid)) {
        await clearSessionState();
        const refreshed = await activateLicenseSession();
        if (refreshed) {
          return apiFetch(input, { ...nextInit, __retrying: true });
        }
      }
    } catch (e) {}
  }
  return response;
}

function extractConvoId() {
  const match = window.location.href.match(/\/messages\/(\d+)/);
  return match ? match[1] : null;
}

function normalizeInlineText(value) {
  return String(value || '')
    .replace(/\u00a0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function toAbsoluteUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    return new URL(raw, window.location.href).href;
  } catch (e) {
    return raw;
  }
}

function parseBestSrcFromSrcset(srcset) {
  const entries = String(srcset || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
  if (entries.length === 0) return '';
  const last = entries[entries.length - 1].split(/\s+/)[0];
  return toAbsoluteUrl(last);
}

function dedupeBy(items, keyFn) {
  const seen = new Set();
  const result = [];
  (items || []).forEach((item) => {
    const key = keyFn(item);
    if (!key || seen.has(key)) return;
    seen.add(key);
    result.push(item);
  });
  return result;
}

function getMessageListRoot() {
  return document.querySelector('.scrolling-message-list')
    || document.querySelector('[data-message-list]')
    || document.querySelector('[data-test-id="messages-list"]');
}

function isLikelyMessageImage(img) {
  if (!(img instanceof HTMLImageElement)) return false;
  if (img.closest('[aria-label*="emoji" i], [data-selector*="emoji"]')) return false;

  const marker = `${img.className || ''} ${img.alt || ''} ${img.src || ''} ${img.currentSrc || ''}`.toLowerCase();
  if (marker.includes('avatar') || marker.includes('icon') || marker.includes('emoji') || marker.includes('spinner')) {
    return false;
  }

  const width = Number(img.naturalWidth || img.width || 0);
  const height = Number(img.naturalHeight || img.height || 0);
  if (width > 0 && height > 0 && Math.max(width, height) < 48 && !img.closest('a[href]')) {
    return false;
  }

  return true;
}

function extractImagePayloads(scope) {
  const images = [];
  scope.querySelectorAll('img').forEach((img) => {
    if (!isLikelyMessageImage(img)) return;

    const anchorHref = toAbsoluteUrl(img.closest('a[href]')?.getAttribute('href') || img.closest('a[href]')?.href);
    const datasetHref = toAbsoluteUrl(
      img.dataset.fullsize
      || img.dataset.fullSrc
      || img.dataset.zoomSrc
      || img.dataset.src
      || img.dataset.imageUrl
    );
    const pictureSrc = parseBestSrcFromSrcset(img.closest('picture')?.querySelector('source[srcset]')?.getAttribute('srcset') || '');
    const directSrc = toAbsoluteUrl(img.currentSrc || img.src);
    const bestSrc = [anchorHref, datasetHref, pictureSrc, parseBestSrcFromSrcset(img.srcset), directSrc]
      .find((value) => value && !value.startsWith('data:')) || '';

    if (!bestSrc) return;

    images.push({
      src: bestSrc,
      alt: normalizeInlineText(img.alt || '')
    });
  });

  return dedupeBy(images, (image) => image.src);
}

function extractLinkPayloads(scope, knownImageUrls = []) {
  const imageUrlSet = new Set((knownImageUrls || []).map((url) => toAbsoluteUrl(url)));
  const links = [];

  scope.querySelectorAll('a[href]').forEach((anchor) => {
    const href = toAbsoluteUrl(anchor.getAttribute('href') || anchor.href);
    if (!href || href.startsWith('javascript:') || imageUrlSet.has(href)) return;
    if (anchor.querySelector('img') && imageUrlSet.has(toAbsoluteUrl(anchor.getAttribute('href') || anchor.href))) return;

    const text = normalizeInlineText(anchor.textContent || '');
    links.push({
      href,
      text: text || href
    });
  });

  return dedupeBy(links, (link) => link.href);
}

function extractTextSegments(scope, timestamp = '') {
  const segments = [];
  const candidates = scope.querySelectorAll(
    '.wt-rounded.wt-text-body-01, .wt-rounded[class*="wt-text-body"], [data-message-text], [data-test-id="message-body"], p'
  );

  candidates.forEach((node) => {
    if (!(node instanceof HTMLElement)) return;
    if (node.querySelector('img') && !normalizeInlineText(node.innerText || node.textContent || '')) return;

    const clone = node.cloneNode(true);
    clone.querySelectorAll('script, style, button, svg, img, video, audio, .screen-reader-only').forEach((el) => el.remove());
    const text = normalizeInlineText(clone.innerText || clone.textContent || '');
    if (!text) return;
    if (timestamp && text === timestamp) return;
    if (/^(private note|labels?|mark unread|mark read|trash)$/i.test(text)) return;
    segments.push(text);
  });

  if (segments.length === 0) {
    scope.querySelectorAll('p, div, span, li').forEach((node) => {
      if (!(node instanceof HTMLElement)) return;
      if (node.children.length > 0 && !Array.from(node.children).every((child) => child.tagName === 'BR')) return;
      const text = normalizeInlineText(node.innerText || node.textContent || '');
      if (!text) return;
      if (timestamp && text === timestamp) return;
      if (/^(private note|labels?|mark unread|mark read|trash)$/i.test(text)) return;
      segments.push(text);
    });
  }

  if (segments.length === 0) {
    const fallback = normalizeInlineText(scope.innerText || scope.textContent || '');
    if (fallback && (!timestamp || fallback !== timestamp)) {
      segments.push(fallback);
    }
  }

  const unique = [];
  segments.forEach((text) => {
    if (unique.some((existing) => existing === text || existing.includes(text) || text.includes(existing))) return;
    unique.push(text);
  });
  return unique;
}

function extractBuyerName() {
  const selectors = [
    '.scrolling-message-list p.wt-text-title',
    '.scrolling-message-list h1',
    '.scrolling-message-list h2',
    '[data-test-id="conversation-header"] h1',
    '[data-test-id="conversation-header"] h2',
    'aside p.wt-text-title',
    'aside h2'
  ];
  for (const selector of selectors) {
    const text = normalizeInlineText(document.querySelector(selector)?.textContent || '');
    if (text && !/^(messages|private note|labels?)$/i.test(text)) return text;
  }
  return 'Unknown';
}

function getPendingBuyerCount(messages) {
  const list = Array.isArray(messages) ? messages : [];
  let count = 0;
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const message = list[i];
    if (!message) continue;
    const hasContent = Boolean(
      normalizeInlineText(message.text || '')
      || (Array.isArray(message.links) && message.links.length > 0)
      || (Array.isArray(message.images) && message.images.length > 0)
    );
    if (!hasContent) continue;
    if (message.direction === 'out') break;
    if (message.direction === 'in') count += 1;
  }
  return count;
}

function getPendingBuyerMessages(messages) {
  const list = Array.isArray(messages) ? messages : [];
  const pending = [];

  for (let i = list.length - 1; i >= 0; i -= 1) {
    const message = list[i];
    if (!message) continue;
    const hasContent = Boolean(
      normalizeInlineText(message.text || '')
      || (Array.isArray(message.links) && message.links.length > 0)
      || (Array.isArray(message.images) && message.images.length > 0)
    );
    if (!hasContent) continue;
    if (message.direction === 'out') break;
    if (message.direction === 'in') pending.push(message);
  }

  return pending.reverse();
}

function formatMessageForDrafting(message) {
  const parts = [];
  const text = normalizeInlineText(message?.text || '');
  if (text) parts.push(text);

  const linkUrls = Array.isArray(message?.links)
    ? message.links.map((item) => toAbsoluteUrl(item?.href || item?.text || '')).filter(Boolean)
    : [];
  const imageUrls = Array.isArray(message?.images)
    ? message.images.map((item) => toAbsoluteUrl(item?.src || '')).filter(Boolean)
    : [];

  if (linkUrls.length > 0) {
    parts.push(`Links: ${linkUrls.join(' | ')}`);
  }
  if (imageUrls.length > 0) {
    parts.push(`Images: ${imageUrls.join(' | ')}`);
  }

  return parts.join('\n').trim();
}

function getPendingBuyerText(messages) {
  const pending = getPendingBuyerMessages(messages);
  if (pending.length > 0) {
    return pending
      .map((message) => formatMessageForDrafting(message))
      .filter(Boolean)
      .join('\n\n');
  }

  const latestBuyer = [...(messages || [])].reverse().find((message) => {
    if (message?.direction !== 'in') return false;
    return Boolean(
      normalizeInlineText(message.text || '')
      || (Array.isArray(message.links) && message.links.length > 0)
      || (Array.isArray(message.images) && message.images.length > 0)
    );
  });

  return latestBuyer ? formatMessageForDrafting(latestBuyer) : '';
}

function extractMessages() {
  const list = getMessageListRoot();
  if (!list) return [];

  return [...list.children].map((child) => {
    if (!(child instanceof HTMLElement)) return null;

    const isFromMe = child.matches('.wt-justify-content-flex-end')
      || !!child.querySelector('.wt-justify-content-flex-end, [class*="justify-content-flex-end"], [data-message-owner="seller"]');
    const timestamp = normalizeInlineText(
      child.querySelector('time')?.textContent
      || child.querySelector('.wt-text-caption.wt-sem-text-secondary')?.textContent
      || child.querySelector('.timestamp-color')?.textContent
      || ''
    );
    const images = extractImagePayloads(child);
    const links = extractLinkPayloads(child, images.map((image) => image.src));
    const text = extractTextSegments(child, timestamp).join('\n\n');

    if (!text && links.length === 0 && images.length === 0) return null;
    return {
      direction: isFromMe ? 'out' : 'in',
      text,
      links: links.length > 0 ? links : undefined,
      images: images.length > 0 ? images : undefined,
      timestamp
    };
  }).filter(Boolean);
}

// ========== 2. Current thread sync ==========

// Sync the currently open conversation only, and only when the user clicks.
async function syncCurrentConversation() {
  const convoId = extractConvoId();
  if (!convoId) return null;
  const apiBase = await getApiBase();
  const messages = extractMessages();

  const data = {
    convoId,
    buyerName: extractBuyerName(),
    messages,
    messageCount: messages.length,
    lastDirection: messages.length > 0 ? messages[messages.length - 1].direction : '',
    pendingBuyerCount: getPendingBuyerCount(messages),
    pendingBuyerText: getPendingBuyerText(messages),
    hasAttachments: messages.some((message) => (message.links && message.links.length > 0) || (message.images && message.images.length > 0)),
    shopId: SHOP_ID,
    url: window.location.href,
    syncedAt: new Date().toISOString()
  };

  try {
    const res = await apiFetch(apiBase + '/api/messages/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await res.json();
    console.log('[EMA] Synced current thread:', result);
    return result;
  } catch (e) {
    console.error('[EMA] Sync failed:', e);
    return null;
  }
}

// ========== 3. AI 回复生成 ==========

async function generateReply(convoId) {
  try {
    updatePanelStatus('Generating...');
    const apiBase = await getApiBase();
    const res = await apiFetch(`${apiBase}/api/messages/generate-reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ convoId, shopId: SHOP_ID })
    });
    const result = await res.json();
    if (result.reply) {
      showReply(result.reply, result.replyZh);
    } else {
      updatePanelStatus('Generation failed: ' + (result.error || 'unknown'));
    }
    return result;
  } catch (e) {
    updatePanelStatus('Connection failed. Check the message hub service.');
    return null;
  }
}

async function refineReply(convoId, instruction) {
  try {
    updatePanelStatus('Refining...');
    const currentReply = panel?.querySelector('.ema-reply-text')?.textContent || '';
    const apiBase = await getApiBase();
    const res = await apiFetch(`${apiBase}/api/messages/refine-reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ convoId, shopId: SHOP_ID, currentReply, instruction })
    });
    const result = await res.json();
    if (result.reply) {
      showReply(result.reply, result.replyZh);
    }
    return result;
  } catch (e) {
    updatePanelStatus('Refine failed');
    return null;
  }
}

// ========== 4. 填入回复框（不发送） ==========

function fillReplyBox(text) {
  const textarea = document.querySelector('textarea[placeholder="Type your reply"]')
    || document.querySelector('.new-message-textarea-min-height')
    || document.querySelector('textarea[id^="message"]');

  if (!textarea) {
    console.error('[EMA] Reply textarea not found');
    return false;
  }

  const nativeSetter = Object.getOwnPropertyDescriptor(
    window.HTMLTextAreaElement.prototype, 'value'
  ).set;
  nativeSetter.call(textarea, text);
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
  textarea.dispatchEvent(new Event('change', { bubbles: true }));
  textarea.focus();
  return true;
}

function applyPanelLayout() {
  if (!panel) return;

  panel.classList.toggle('ema-collapsed', panelCollapsed);

  const toggleBtn = panel.querySelector('#ema-toggle');
  if (toggleBtn) {
    toggleBtn.textContent = panelCollapsed ? '<' : '>';
    toggleBtn.title = panelCollapsed ? 'Expand sidebar' : 'Collapse sidebar';
  }

  const root = document.documentElement;
  const reserveSpace = !panelCollapsed && window.innerWidth >= 1180;
  root.classList.toggle('ema-sidebar-open', reserveSpace);
}

function setPanelCollapsed(collapsed, persist = true) {
  panelCollapsed = !!collapsed;
  applyPanelLayout();
  if (!persist) return;

  try {
    chrome.storage.local.set({ emaSidebarCollapsed: panelCollapsed });
  } catch (e) {}
}

function installSidebarLayout() {
  if (sidebarLayoutInstalled) return;
  sidebarLayoutInstalled = true;
  window.addEventListener('resize', applyPanelLayout);
}

function restorePanelLayoutPreference() {
  applyPanelLayout();
  try {
    chrome.storage.local.get('emaSidebarCollapsed', (data) => {
      if (typeof data.emaSidebarCollapsed === 'boolean') {
        panelCollapsed = data.emaSidebarCollapsed;
      }
      applyPanelLayout();
    });
  } catch (e) {}
}

// ========== 5. 悬浮面板 UI ==========

function createPanel() {
  if (panel) return panel;

  panel = document.createElement('div');
  panel.id = 'ema-panel';
  panel.innerHTML = `
    <div class="ema-header">
      <div class="ema-brand">
        <span class="ema-brand-mark">AI</span>
        <div class="ema-brand-copy">
          <span class="ema-title">Message Copilot</span>
          <span class="ema-shop" id="ema-shop-label">${SHOP_ID}</span>
        </div>
      </div>
      <button class="ema-btn-close" id="ema-toggle" title="Collapse sidebar">></button>
    </div>
    <div class="ema-body" id="ema-body">
      <div class="ema-status" id="ema-status">Safe mode: open a conversation, then click Sync Current Thread.</div>
      <div class="ema-actions" style="margin-top:0;margin-bottom:10px;">
        <button class="ema-btn ema-btn-primary" id="ema-sync-current">Sync Current Thread</button>
        <button class="ema-btn" id="ema-copy">Copy Draft</button>
      </div>
      <div class="ema-reply-section" id="ema-reply-section" style="display:block">
        <div class="ema-label">EN Reply:</div>
        <div class="ema-reply-text" id="ema-reply-en" style="cursor:text;user-select:text;"></div>
        <div class="ema-label" style="margin-top:8px">CN Translation:</div>
        <div class="ema-reply-zh" id="ema-reply-zh" style="cursor:text;user-select:text;"></div>
        <div class="ema-actions">
          <button class="ema-btn" id="ema-fill">Fill Reply Box</button>
          <button class="ema-btn" id="ema-regen">Regenerate</button>
        </div>
        <div class="ema-quick-actions">
          <button class="ema-btn-sm" data-instruction="more friendly and warm tone">Warmer</button>
          <button class="ema-btn-sm" data-instruction="make it shorter, 2-3 sentences max">Shorter</button>
          <button class="ema-btn-sm" data-instruction="add more details and be more helpful">Detailed</button>
          <button class="ema-btn-sm" data-instruction="more professional and formal">Formal</button>
        </div>
        <div style="margin-top:8px;">
          <textarea id="ema-feedback" style="width:100%;min-height:40px;padding:6px 8px;border:1px solid #ddd;border-radius:6px;font-size:12px;font-family:inherit;resize:vertical;" placeholder="Your feedback / revision instructions..."></textarea>
          <button class="ema-btn" id="ema-refine-feedback" style="width:100%;margin-top:4px;">Refine with feedback</button>
        </div>
      </div>
      <div class="ema-poll-status" id="ema-poll-status" style="margin-top:8px;font-size:11px;color:#aaa;">
        Safe mode: no background refresh, no auto-sync, no auto-send.
      </div>
    </div>
  `;

  document.body.appendChild(panel);
  installSidebarLayout();
  bindPanelEvents();
  restorePanelLayoutPreference();
  return panel;
}

function bindPanelEvents() {
  panel.querySelector('#ema-toggle').addEventListener('click', () => {
    setPanelCollapsed(!panelCollapsed);
  });

  panel.querySelector('#ema-sync-current').addEventListener('click', () => {
    syncAndGenerateCurrentThread();
  });

  panel.querySelector('#ema-copy').addEventListener('click', async () => {
    const text = panel.querySelector('#ema-reply-en').textContent.trim();
    if (!text) {
      updatePanelStatus('No draft to copy yet.');
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      updatePanelStatus('Draft copied. Paste it manually or use Fill Reply Box.');
    } catch (e) {
      updatePanelStatus('Copy failed. Browser blocked clipboard access.');
    }
  });

  // Fill reply box (no send)
  panel.querySelector('#ema-fill').addEventListener('click', () => {
    const text = panel.querySelector('#ema-reply-en').textContent;
    if (!text.trim()) {
      updatePanelStatus('No draft to fill yet.');
      return;
    }
    if (fillReplyBox(text)) {
      updatePanelStatus('Filled reply box, check and send manually');
    }
  });

  // Regenerate
  panel.querySelector('#ema-regen').addEventListener('click', () => {
    const convoId = extractConvoId();
    if (convoId) generateReply(convoId);
  });

  // Quick refine
  panel.querySelectorAll('.ema-btn-sm').forEach(btn => {
    btn.addEventListener('click', () => {
      const convoId = extractConvoId();
      if (convoId) refineReply(convoId, btn.dataset.instruction);
    });
  });

  // Feedback refine
  panel.querySelector('#ema-refine-feedback').addEventListener('click', () => {
    const convoId = extractConvoId();
    const feedback = panel.querySelector('#ema-feedback').value.trim();
    if (convoId && feedback) {
      refineReply(convoId, feedback);
      panel.querySelector('#ema-feedback').value = '';
    }
  });
}

function showReply(replyEn, replyZh) {
  const section = panel.querySelector('#ema-reply-section');
  section.style.display = 'block';
  panel.querySelector('#ema-reply-en').textContent = replyEn;
  panel.querySelector('#ema-reply-zh').textContent = replyZh || '';
  updatePanelStatus('Draft generated. Review, refine, then Copy or Fill Reply Box.');
}

function updatePanelStatus(msg) {
  const el = panel?.querySelector('#ema-status');
  if (el) el.textContent = msg;
}

function notifyContextChanged(reason = 'context', options = {}) {
  const { force = false } = options;
  const convoId = extractConvoId() || '';
  const currentUrl = window.location.href;
  const pageType = /^https:\/\/www\.etsy\.com\/(?:your\/)?messages(?:\/|$|\?)/.test(currentUrl) ? 'messages' : '';
  const signalKey = `${currentUrl}::${SHOP_ID}::${convoId}`;
  if (!force && signalKey === lastContextSignalKey) return;
  lastContextSignalKey = signalKey;
  try {
    chrome.runtime.sendMessage({
      action: 'etsyContextChanged',
      pageType,
      shopId: SHOP_ID,
      convoId,
      currentUrl,
      reason
    });
  } catch (e) {}
}

function scheduleContextSignal(reason = 'context', delay = 600) {
  if (contextSignalTimer) clearTimeout(contextSignalTimer);
  contextSignalTimer = setTimeout(() => {
    contextSignalTimer = null;
    resetPanelForCurrentConversation();
    try {
      chrome.runtime.sendMessage({
        action: 'shopDetected',
        shopId: SHOP_ID,
        currentUrl: window.location.href
      });
    } catch (e) {}
    notifyContextChanged(reason, { force: true });
  }, delay);
}

function resetPanelForCurrentConversation() {
  if (!panel) return;

  currentConvoId = extractConvoId();
  const syncBtn = panel.querySelector('#ema-sync-current');
  const replyEn = panel.querySelector('#ema-reply-en');
  const replyZh = panel.querySelector('#ema-reply-zh');
  const feedback = panel.querySelector('#ema-feedback');
  const shopLabel = panel.querySelector('#ema-shop-label');

  replyEn.textContent = '';
  replyZh.textContent = '';
  feedback.value = '';
  if (shopLabel) shopLabel.textContent = SHOP_ID;

  if (!currentConvoId) {
    syncBtn.disabled = true;
    updatePanelStatus('Safe mode: open a conversation, then click Sync Current Thread.');
    return;
  }

  syncBtn.disabled = false;
  updatePanelStatus('Conversation detected. Click Sync Current Thread to sync and generate a draft.');
}

async function syncAndGenerateCurrentThread() {
  const convoId = extractConvoId();
  if (!convoId) {
    updatePanelStatus('Open a specific conversation first.');
    return;
  }

  currentConvoId = convoId;
  updatePanelStatus('Syncing current thread...');
  const syncResult = await syncCurrentConversation();
  if (!syncResult?.ok) {
    updatePanelStatus('Sync failed.');
    return;
  }

  const msgs = extractMessages();
  const pendingBuyerCount = getPendingBuyerCount(msgs);
  if (msgs.length === 0) {
    updatePanelStatus('No messages found in current thread.');
    return;
  }

  if (pendingBuyerCount <= 0) {
    updatePanelStatus('Current thread synced. Latest message is yours, so no draft was generated.');
    return;
  }

  updatePanelStatus('Current thread synced. Generating draft...');
  await generateReply(convoId);
}

function installUrlObserver() {
  if (urlObserverInstalled) return;
  urlObserverInstalled = true;

  let lastUrl = window.location.href;
  const handlePossibleRouteChange = (reason = 'url-change') => {
    if (window.location.href === lastUrl) return;
    lastUrl = window.location.href;
    scheduleContextSignal(reason);
  };

  const observer = new MutationObserver(() => {
    handlePossibleRouteChange('mutation');
  });
  observer.observe(document.body, { childList: true, subtree: true });

  window.addEventListener('popstate', () => handlePossibleRouteChange('popstate'));

  if (!window.__emaHistoryPatched) {
    window.__emaHistoryPatched = true;
    const rawPushState = history.pushState.bind(history);
    const rawReplaceState = history.replaceState.bind(history);

    history.pushState = function pushStatePatched(...args) {
      const result = rawPushState(...args);
      handlePossibleRouteChange('pushstate');
      return result;
    };

    history.replaceState = function replaceStatePatched(...args) {
      const result = rawReplaceState(...args);
      handlePossibleRouteChange('replacestate');
      return result;
    };
  }
}

// ========== 6. 主流程 ==========

async function init() {
  console.log('[EMA] Etsy Message Assistant loaded');

  // Get real shop name first
  await extractShopInfo();
  // Notify background of shop name
  try { chrome.runtime.sendMessage({ action: 'shopDetected', shopId: SHOP_ID, currentUrl: window.location.href }); } catch(e) {}

  installUrlObserver();
  scheduleContextSignal('init', 0);
}

// Wait for page load
if (document.readyState === 'complete') {
  setTimeout(init, 1000);
} else {
  window.addEventListener('load', () => setTimeout(init, 1000));
}

// ========== Listen for commands from background service worker ==========

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getStatus' || msg.action === 'getPageState') {
    const messages = extractMessages();
    sendResponse({
      ok: true,
      safeMode: true,
      extensionVersion: EXTENSION_VERSION,
      buildFingerprint: BUILD_FINGERPRINT,
      shopId: SHOP_ID,
      convoId: extractConvoId(),
      buyerName: extractBuyerName(),
      currentUrl: window.location.href,
      isMessagesPage: /\/messages(\/|$)/.test(window.location.pathname),
      messageCount: messages.length,
      pendingBuyerCount: getPendingBuyerCount(messages),
      pendingBuyerText: getPendingBuyerText(messages),
      hasAttachments: messages.some((message) => (message.links && message.links.length > 0) || (message.images && message.images.length > 0)),
      lastDirection: messages.length > 0 ? messages[messages.length - 1].direction : null,
      panelExists: false
    });
    return true;
  }

  if (msg.action === 'syncCurrentThread') {
    (async () => {
      const convoId = extractConvoId();
      if (!convoId) {
        sendResponse({ ok: false, error: 'Open a specific Etsy conversation first.' });
        return;
      }

      const syncResult = await syncCurrentConversation();
      if (!syncResult?.ok) {
        sendResponse({ ok: false, error: 'Sync failed.' });
        return;
      }

      const messages = extractMessages();
      const lastMsg = messages[messages.length - 1] || null;
      sendResponse({
        ok: true,
        safeMode: true,
        extensionVersion: EXTENSION_VERSION,
        buildFingerprint: BUILD_FINGERPRINT,
        convoId,
        shopId: SHOP_ID,
        buyerName: extractBuyerName(),
        messageCount: messages.length,
        pendingBuyerCount: getPendingBuyerCount(messages),
        pendingBuyerText: getPendingBuyerText(messages),
        hasAttachments: messages.some((message) => (message.links && message.links.length > 0) || (message.images && message.images.length > 0)),
        lastDirection: lastMsg?.direction || null,
        needsReply: getPendingBuyerCount(messages) > 0,
        messages
      });
    })();
    return true;
  }

  if (msg.action === 'fillReplyBox') {
    const text = String(msg.text || '').trim();
    if (!text) {
      sendResponse({ ok: false, error: 'Missing draft text.' });
      return true;
    }
    const filled = fillReplyBox(text);
    sendResponse({ ok: filled, error: filled ? null : 'Reply textarea not found.' });
    return true;
  }

  if (msg.action === 'batchSync' || msg.action === 'fillDraft' || msg.action === 'getConvoList') {
    sendResponse({ ok: false, error: 'disabled in safe mode' });
    return true;
  }
});
