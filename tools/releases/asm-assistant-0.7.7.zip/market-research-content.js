const MARKET_SEARCH_URL_RE = /^https:\/\/www\.etsy\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:search(?:\/|$|\?)|market\/)/i;

let marketObserverInstalled = false;
let marketSignalTimer = null;
let lastMarketSignalKey = '';

function normalizeMarketText(text) {
  return String(text || '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isMarketSearchPage() {
  return MARKET_SEARCH_URL_RE.test(window.location.href);
}

function extractKeyword() {
  const params = new URLSearchParams(window.location.search || '');
  const q = normalizeMarketText(params.get('q'));
  if (q) return q;
  const heading = normalizeMarketText(document.querySelector('h1')?.textContent || '');
  if (heading) return heading;
  return normalizeMarketText(document.title.replace(/\s*\|\s*Etsy.*$/i, ''));
}

function extractResultCountHint() {
  const bodyText = normalizeMarketText(document.body?.innerText || '');
  const match = bodyText.match(/\b([\d,]+\+?)\s+items?\b/i);
  return match ? match[0] : '';
}

function extractSortModeHint() {
  const bodyText = normalizeMarketText(document.body?.innerText || '');
  const match = bodyText.match(/Sort by[:\s]+([A-Za-z ]{3,40})/i);
  return match ? normalizeMarketText(match[1]) : '';
}

function extractListingIdFromHref(href) {
  const match = String(href || '').match(/\/listing\/(\d+)/i);
  return match ? match[1] : '';
}

function deriveCardRoot(anchor, listingId) {
  for (let node = anchor; node && node !== document.body; node = node.parentElement) {
    if (!(node instanceof HTMLElement)) continue;
    const text = normalizeMarketText(node.innerText || '');
    if (!text) continue;
    if (!text.includes('$') && !/sale price|original price|off|download|shipping/i.test(text)) continue;
    const linkCount = node.querySelectorAll('a[href*="/listing/"]').length;
    if (linkCount > 0 && text.length > 30 && text.length < 1800) {
      return node;
    }
  }
  return anchor.closest('article, li, div') || anchor.parentElement;
}

function parseMoneyParts(text) {
  const raw = String(text || '');
  const matches = Array.from(raw.matchAll(/(HK\$|US\$|CA\$|AU\$|NZ\$|SG\$|€|£|\$)\s*([\d,]+(?:\.\d{2})?)/gi));
  return matches.map((match) => {
    const symbol = String(match[1] || '').toUpperCase();
    const amount = Number(String(match[2] || '').replace(/,/g, ''));
    const currencyMap = {
      'HK$': 'HKD',
      'US$': 'USD',
      'CA$': 'CAD',
      'AU$': 'AUD',
      'NZ$': 'NZD',
      'SG$': 'SGD',
      '€': 'EUR',
      '£': 'GBP',
      '$': 'USD'
    };
    return {
      amount: Number.isFinite(amount) ? amount : 0,
      currency: currencyMap[symbol] || 'USD',
      rawText: `${match[1]}${match[2]}`
    };
  });
}

function extractShopNameFromCardText(text) {
  const raw = normalizeMarketText(text);
  if (!raw) return '';
  const matched = raw.match(/\b(?:Ad by|by)\s+([A-Za-z0-9][A-Za-z0-9 _.'-]{1,48})/i);
  return matched ? normalizeMarketText(matched[1]) : '';
}

function buildCardPayload(anchor, position) {
  const href = anchor.getAttribute('href') || anchor.href || '';
  const listingId = extractListingIdFromHref(href);
  const card = deriveCardRoot(anchor, listingId);
  const rawCardText = normalizeMarketText(card?.innerText || anchor?.innerText || '');
  const title = normalizeMarketText(anchor.textContent || '');
  const moneyParts = parseMoneyParts(rawCardText);
  const priceCurrent = moneyParts[0] || { amount: 0, currency: '', rawText: '' };
  const priceOriginal = moneyParts[1] || { amount: 0, currency: '', rawText: '' };
  const discountMatch = rawCardText.match(/\((\d{1,2}(?:\.\d+)?)%\s+off\)/i);
  const reviewMatch = rawCardText.match(/\(([\d,.kK]+)\)/);
  const shippingMatch = rawCardText.match(/\b(FREE shipping|free delivery|digital download|download)\b/i);

  return {
    position,
    listingId,
    title,
    listingUrl: href.startsWith('http') ? href : `https://www.etsy.com${href}`,
    shopName: extractShopNameFromCardText(rawCardText),
    priceCurrent,
    priceOriginal,
    discountPercent: discountMatch ? Number(discountMatch[1]) : 0,
    shippingText: shippingMatch ? shippingMatch[0] : '',
    badgeTexts: Array.from(new Set(
      (rawCardText.match(/\b(FREE shipping|Digital Download|Bestseller|Star Seller|Popular now)\b/gi) || [])
        .map((value) => normalizeMarketText(value))
        .filter(Boolean)
    )),
    reviewCount: reviewMatch ? reviewMatch[1] : '',
    isAd: /sponsored|ad by/i.test(rawCardText),
    rawCardText
  };
}

function extractMarketCards(limit = 16) {
  const seen = new Set();
  const cards = [];
  const anchors = Array.from(document.querySelectorAll('a[href*="/listing/"]'));
  for (const anchor of anchors) {
    const listingId = extractListingIdFromHref(anchor.getAttribute('href') || anchor.href || '');
    if (!listingId || seen.has(listingId)) continue;
    const payload = buildCardPayload(anchor, cards.length + 1);
    if (!payload.title && !payload.rawCardText) continue;
    seen.add(listingId);
    cards.push(payload);
    if (cards.length >= limit) break;
  }
  return cards;
}

function extractMarketSignalSignature() {
  const cards = extractMarketCards(6);
  return [
    window.location.href,
    extractKeyword(),
    extractSortModeHint(),
    cards.map((card) => `${card.listingId}:${card.priceCurrent.amount || 0}`).join('|')
  ].join(' ### ');
}

function notifyMarketContextChanged(reason = 'context', options = {}) {
  if (!isMarketSearchPage()) return;
  const { force = false } = options;
  const signalKey = extractMarketSignalSignature();
  if (!force && signalKey === lastMarketSignalKey) return;
  lastMarketSignalKey = signalKey;
  try {
    chrome.runtime.sendMessage({
      action: 'etsyContextChanged',
      pageType: 'market_search',
      currentUrl: window.location.href,
      reason
    });
  } catch (e) {}
}

function scheduleMarketContextSignal(reason = 'context', delay = 260, force = false) {
  if (marketSignalTimer) clearTimeout(marketSignalTimer);
  marketSignalTimer = setTimeout(() => {
    marketSignalTimer = null;
    notifyMarketContextChanged(reason, { force });
  }, delay);
}

function installMarketObserver() {
  if (marketObserverInstalled) return;
  marketObserverInstalled = true;

  let lastUrl = window.location.href;
  const handlePossibleRouteChange = (reason = 'url-change') => {
    if (window.location.href === lastUrl) return;
    lastUrl = window.location.href;
    lastMarketSignalKey = '';
    scheduleMarketContextSignal(reason, 220, true);
  };

  const observer = new MutationObserver(() => {
    if (isMarketSearchPage()) {
      scheduleMarketContextSignal('market-mutation', 320, false);
    }
    handlePossibleRouteChange('mutation');
  });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true });

  window.addEventListener('popstate', () => handlePossibleRouteChange('popstate'));
}

function buildMarketPayload() {
  const isPage = isMarketSearchPage();
  const cards = isPage ? extractMarketCards() : [];
  return {
    ok: true,
    isResearchPage: isPage,
    pageType: isPage ? 'market_search' : '',
    pageUrl: window.location.href,
    pageTitle: normalizeMarketText(document.title),
    keyword: isPage ? extractKeyword() : '',
    resultCountHint: isPage ? extractResultCountHint() : '',
    sortModeHint: isPage ? extractSortModeHint() : '',
    cards,
    summaryText: cards.slice(0, 5).map((card) => card.rawCardText).join('\n\n'),
    extractor: 'market-search-v0',
    diagnostics: {
      cardsFound: cards.length,
      listingLinksFound: document.querySelectorAll('a[href*="/listing/"]').length
    }
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'getResearchPageState') return false;
  sendResponse(buildMarketPayload());
  return true;
});

function initMarketObserver() {
  installMarketObserver();
  if (isMarketSearchPage()) {
    scheduleMarketContextSignal('market-init', 0, true);
  }
}

if (document.readyState === 'complete') {
  setTimeout(initMarketObserver, 700);
} else {
  window.addEventListener('load', () => setTimeout(initMarketObserver, 700));
}
